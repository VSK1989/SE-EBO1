# EBO Edge01 Agent - Ubuntu workspace edition

## Paths
Project workspace: `~/EBO_Edge01_Agent` (extract ZIP into your Ubuntu home directory and rename extracted folder if needed). Diagnostic output: `~/EBO_Edge01_Agent_Logs` by default. These are **Linux paths**, not Windows paths. Override output with `EBO_AGENT_OUTPUT_DIR=/absolute/linux/path`. The workspace is resolved by VS Code `${workspaceFolder}` and is not hard-coded in Python.

## Install and run in Ubuntu
1. Make sure `python3`, `python3-venv`, Docker CLI and access to the Docker daemon are available. If Ubuntu is in WSL, enable Docker Desktop WSL integration. Run `docker version` and `docker ps -a` from the same Ubuntu terminal.
2. Extract ZIP to Ubuntu home, then: `cd ~/EBO_Edge01_Agent && code .`. If the extracted folder is `EBO_Edge01_Agent_Ubuntu`, rename it: `mv ~/EBO_Edge01_Agent_Ubuntu ~/EBO_Edge01_Agent`.
3. `bash scripts/setup_ubuntu.sh`; choose `.venv/bin/python` in VS Code.
4. `.venv/bin/python run_agent.py validate` then `.venv/bin/python run_agent.py collect`.
5. Optional SDK: `.venv/bin/python -m pip install -r requirements-sdk.txt`. CLI works without SDK.
6. Auto collection: `.venv/bin/python run_agent.py auto-on` then `.venv/bin/python run_agent.py monitor`; Ctrl+C stops. `auto-off` disables future collections. Monitor must remain running.

## Commands
`validate`, `status`, `diagnostics`, `health`, `collect`, `report`, `errors`, `config`, `connect`, `auto-on`, `auto-off`, `monitor`. Add `--config /absolute/linux/path/agent.json` before the command to use another JSON file.

## Configuration
`config/agent.json` contains Edge01, expected IP 192.168.10.1, requested Enterprise Server image, output_dir, backend (`auto`, `sdk`, `cli`), auto_collect, interval_seconds, log_tail, max_sessions, max_log_bytes, trace_paths. Expected IP is checked against Docker inspect, not a connectivity test. Default output expands `~` for the current Ubuntu user. All reports, execution logs and session folders remain in `~/EBO_Edge01_Agent_Logs`. No YAML or PyYAML.

## Diagnostics and privacy
The agent is read-only with optional `docker exec tail` for trace retrieval. Each collection writes `container_logs.txt`, `container_inspect.json`, `container_status.json`, `network_inspect.json`, `resources.json`, `diagnostics.txt`, `errors.log`, `summary.txt`. Rotating `agent.log` and `latest_summary.txt` are in the output root. Session count is capped, but total disk usage is not guaranteed. Logs may contain sensitive data. Docker `running` does not prove EBO application readiness. No image pull, EBO configuration, container restart, upgrade or LLM integration is included.

## Troubleshooting
- `python3 -m venv` fails: install the Ubuntu `python3-venv` package using your approved package source.
- `docker not on PATH` or daemon failure: check `docker version`, active Docker context, Docker Desktop WSL integration or your Ubuntu Docker Engine.
- Edge01 missing: run `docker ps -a` in the same Ubuntu terminal and check context.
- IP mismatch: inspect network assignment; no network changes are made by this agent.
- Output unwritable: check Ubuntu permissions and free space; override `EBO_AGENT_OUTPUT_DIR` with an absolute Linux path.
- SDK unavailable: `auto` uses CLI fallback; `cli` disables SDK checks.

## Sources and assumptions
Internal: attached start.py, getLogs.sh, servers.yml and Bash4Edge readme. The older inventory's Edge01 image and IP differ from the user's new target; explicit new target is used. A credential present in an attached management script is not copied. External reference addresses: https://github.com/SchneiderElectricBuildings/EBO-Edge-Server and https://docs.docker.com/desktop/features/wsl/ . Actual live Docker connectivity cannot be tested in the build environment.
