"""Project entry point."""
from ebo_agent.cli import main
if __name__=='__main__':raise SystemExit(main())
