#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m venv .venv
.venv/bin/python -m unittest discover -s tests -v
printf '%s\n' 'Run: .venv/bin/python run_agent.py validate' 'Optional SDK: .venv/bin/python -m pip install -r requirements-sdk.txt'
