# Source file explanation
- `run_agent.py`: CLI entry point; returns process exit code.
- `ebo_agent/config.py`: `load` validates JSON; `output_path` creates and tests Ubuntu output directory; raises ConfigError for invalid or Windows-style paths.
- `ebo_agent/docker_ops.py`: `run` invokes Docker without shell; DockerOps uses optional SDK and CLI fallback. `ping`, `inspect`, `logs`, `networks`, `stats`, `trace` are bounded read operations; DockerError describes failures.
- `ebo_agent/diagnostics.py`: `assess` creates PASS/WARN/FAIL results and corrective actions; `safe_inspect` removes environment variables and command arguments before export.
- `ebo_agent/collector.py`: `collect` creates unique session folders, saves available evidence and errors, updates summary and prunes old sessions.
- `ebo_agent/cli.py`: `main` parses commands, manages monitor and rotating log; 0 means no failed checks, 1 means failed checks, 2 means configuration failure.
- `tests/test_agent.py`: eight offline tests for config, Linux paths, IP, redaction, collection and missing container.
- `config/agent.json`: editable non-secret defaults; no YAML.
- `scripts/setup_ubuntu.sh`: creates venv and runs offline tests; no privileged changes.
- `.vscode/settings.json`, `launch.json`, `tasks.json`, `extensions.json`: Linux interpreter, debugging, tasks and recommendations.
- `requirements.txt`, `requirements-sdk.txt`: core no third-party dependency; SDK optional.

Flow: run_agent -> CLI -> configuration -> diagnostics -> Docker operations -> collector. Add further read-only checks in DockerOps and assess; add tests before deployment. Existing EBO container is never modified.
