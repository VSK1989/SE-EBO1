"""Offline regression tests."""
import json
import tempfile
import unittest
from pathlib import Path
from ebo_agent.config import load,output_path,ConfigError
from ebo_agent.collector import collect
from ebo_agent.diagnostics import assess,safe_inspect
class Fake:
    warnings=[]
    def ping(self):return True
    def inspect(self,n):return {'Name':n,'State':{'Status':'running','Health':{'Status':'healthy'}},'Config':{'Image':'image','Env':['SECRET=hidden']},'NetworkSettings':{'Networks':{'test':{'IPAddress':'192.168.10.1'}}},'Mounts':[]}
    def networks(self,n):return {'test':{'Name':'test'}}
    def stats(self,n):return {'memory':1}
    def logs(self,n,t):return 'hello'
    def trace(self,n,p,b):return 'trace'
class Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.c={'container':'Edge01','expected_ip':'192.168.10.1','expected_image':'image','output_dir':self.tmp.name,'backend':'cli','auto_collect':False,'interval_seconds':2,'log_tail':10,'max_sessions':2,'max_log_bytes':1000,'trace_paths':[]}
    def test_json(self):
        f=Path(self.tmp.name)/'config.json';f.write_text(json.dumps(self.c));self.assertEqual(load(f)['container'],'Edge01')
    def test_bad_json(self):
        f=Path(self.tmp.name)/'bad.json';f.write_text('{');self.assertRaises(ConfigError,load,f)
    def test_linux_path(self):self.assertEqual(output_path(self.c),Path(self.tmp.name))
    def test_reject_windows_path(self):
        self.c['output_dir']=r'C:\Users\test';self.assertRaises(ConfigError,load,self._write())
    def _write(self):
        f=Path(self.tmp.name)/'config.json';f.write_text(json.dumps(self.c));return f
    def test_ip(self):self.assertEqual(assess(Fake(),self.c)['checks']['ip']['result'],'PASS')
    def test_secret(self):self.assertNotIn('SECRET',json.dumps(safe_inspect(Fake().inspect('Edge01'))))
    def test_collect(self):
        for _ in range(3):collect(Fake(),self.c,Path(self.tmp.name))
        self.assertEqual(len(list((Path(self.tmp.name)/'collections').iterdir())),2)
        self.assertIn('EBO diagnostic report',(Path(self.tmp.name)/'latest_summary.txt').read_text())
    def test_missing(self):
        class Missing(Fake):
            def inspect(self,n):raise RuntimeError('missing')
        self.assertEqual(assess(Missing(),self.c)['checks']['container']['result'],'FAIL')
if __name__=='__main__':unittest.main()
