"""Ubuntu command-line entry points."""
import argparse
import json
import logging
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path
from .config import load,output_path,ConfigError
from .docker_ops import DockerOps
from .diagnostics import assess
from .collector import collect
def display(r):
    for key,v in r['checks'].items():print(f'{v["result"]}: {key}: {v["detail"]}')
    for line in r['recommendations']:print('ACTION:',line)
    for line in r['errors']:logging.warning('%s',line)
def main(argv=None):
    parser=argparse.ArgumentParser(description='EBO Docker read-only diagnostics')
    parser.add_argument('--config',default=str(Path(__file__).resolve().parent.parent/'config'/'agent.json'))
    sub=parser.add_subparsers(dest='command',required=True)
    for command in ('validate','status','diagnostics','health','collect','report','errors','config','connect','auto-on','auto-off','monitor'):sub.add_parser(command)
    args=parser.parse_args(argv)
    try:c=load(args.config);root=output_path(c)
    except ConfigError as exc:print('FAIL:',exc,file=sys.stderr);return 2
    handler=RotatingFileHandler(root/'agent.log',maxBytes=1000000,backupCount=3,encoding='utf8');handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));logging.getLogger().addHandler(handler);logging.getLogger().setLevel(logging.INFO)
    if args.command=='config':print(json.dumps({**c,'resolved_output_dir':str(root)},indent=2));return 0
    if args.command in ('auto-on','auto-off'):
        c['auto_collect']=args.command=='auto-on'
        try:Path(args.config).write_text(json.dumps(c,indent=2)+'\n',encoding='utf8')
        except OSError as exc:print('FAIL: Cannot update config:',exc);return 2
        print('Automatic collection:',c['auto_collect'],'(run monitor in foreground)');return 0
    if args.command=='errors':
        for f in [root/'agent.log',*sorted((root/'collections').glob('*/errors.log'))[-3:]]:
            if f.exists():print(f'[{f}]\n'+f.read_text(encoding='utf8',errors='replace')[-4000:])
        return 0
    ops=DockerOps(c['backend'])
    if args.command=='connect':
        try:print('PASS: Docker daemon' if ops.ping() else 'FAIL: Docker daemon');return 0
        except Exception as exc:print('FAIL:',exc);return 1
    if args.command=='monitor':
        print('Monitoring; Ctrl+C to stop')
        try:
            while True:
                c=load(args.config);r=assess(ops,c);display(r)
                if c['auto_collect']:print('Collection:',collect(ops,c,root)[0])
                time.sleep(c['interval_seconds'])
        except KeyboardInterrupt:return 0
    if args.command in ('collect','report'):
        folder,r=collect(ops,c,root);print('Report:',folder/'summary.txt')
    else:r=assess(ops,c)
    display(r)
    if args.command=='validate':
        print('PASS: Python environment',sys.version.split()[0]);print('PASS: JSON configuration');print('PASS: Linux log directory writable',root)
        if r['checks']['docker_daemon']['result']=='PASS':
            folder,r=collect(ops,c,root);print('PASS: Log collection completed',folder);print('PASS: Diagnostic report generated',folder/'summary.txt')
        else:print('WARN: Live log collection unavailable without Docker daemon')
    for warning in ops.warnings:print('WARN:',warning)
    return 1 if any(v['result']=='FAIL' for v in r['checks'].values()) else 0
