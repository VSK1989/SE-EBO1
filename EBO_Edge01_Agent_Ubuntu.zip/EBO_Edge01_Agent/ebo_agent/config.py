"""Validate JSON settings and Linux output directory."""
import ipaddress
import json
import os
from pathlib import Path
class ConfigError(ValueError): pass
def load(path):
    try:
        c=json.loads(Path(path).read_text(encoding='utf8'))
        if not isinstance(c,dict) or not isinstance(c['container'],str) or not c['container'].strip():raise ValueError('container name required')
        ipaddress.ip_address(c['expected_ip'])
        if c['backend'] not in ('auto','sdk','cli'):raise ValueError('backend must be auto/sdk/cli')
        if not isinstance(c['output_dir'],str) or not c['output_dir'].startswith('~/') and not c['output_dir'].startswith('/'):raise ValueError('output_dir must be an absolute Linux path or ~/path')
        for key in ('interval_seconds','log_tail','max_sessions','max_log_bytes'):
            if type(c[key]) is not int or c[key]<1:raise ValueError(key+' must be a positive integer')
        if type(c['auto_collect']) is not bool:raise ValueError('auto_collect must be boolean')
        if not isinstance(c['trace_paths'],list) or any(not isinstance(x,str) or not x.startswith('/var/sbo/db/logs/') or '..' in x for x in c['trace_paths']):raise ValueError('invalid trace_paths')
        return c
    except (OSError,KeyError,ValueError,TypeError) as exc:raise ConfigError(f'Invalid configuration: {exc}') from exc
def output_path(c):
    raw=os.environ.get('EBO_AGENT_OUTPUT_DIR',c['output_dir'])
    if not raw.startswith('/') and not raw.startswith('~/'):raise ConfigError('Set EBO_AGENT_OUTPUT_DIR to an absolute Linux path or ~/path')
    root=Path(raw).expanduser()
    try:
        root.mkdir(parents=True,exist_ok=True)
        probe=root/'.ebo_write_probe';probe.write_text('ok');probe.unlink()
    except OSError as exc:raise ConfigError(f'Log directory {root} is not writable: {exc}') from exc
    return root
