"""Best-effort bounded log and diagnostic collection."""
import json
import logging
import shutil
from datetime import datetime
from pathlib import Path
from uuid import uuid4
from .diagnostics import assess,safe_inspect
def collect(ops,c,root):
    folder=root/'collections'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:8]);folder.mkdir(parents=True)
    r=assess(ops,c);errors=list(r['errors'])
    def save(name,obj):
        try:(folder/name).write_text(json.dumps(obj,indent=2,default=str),encoding='utf8')
        except OSError as exc:errors.append(f'{name}: {exc}')
    save('container_inspect.json',safe_inspect(r['inspect']));save('container_status.json',r['checks']);save('network_inspect.json',r['networks']);save('resources.json',r['stats'])
    try:(folder/'container_logs.txt').write_text(ops.logs(c['container'],c['log_tail'])[-c['max_log_bytes']:],encoding='utf8')
    except Exception as exc:errors.append('logs: '+str(exc))
    if r['inspect'] and (r['inspect'].get('State') or {}).get('Status')=='running':
        for path in c['trace_paths']:
            try:(folder/('trace_'+Path(path).name+'.txt')).write_text(ops.trace(c['container'],path,c['max_log_bytes']),encoding='utf8')
            except Exception as exc:errors.append(f'optional trace {path}: {exc}')
    errors.extend(ops.warnings)
    summary='EBO diagnostic report\n'+'\n'.join(f'{k}: {v["result"]} | {v["detail"]}' for k,v in r['checks'].items())+'\nActions:\n'+'\n'.join(r['recommendations'])+'\nErrors and warnings:\n'+'\n'.join(errors)+'\n'
    for name,text in [('diagnostics.txt',summary),('summary.txt',summary),('errors.log','\n'.join(errors)+'\n')]:
        try:(folder/name).write_text(text,encoding='utf8')
        except OSError as exc:logging.error('Could not write %s: %s',name,exc)
    (root/'latest_summary.txt').write_text(summary,encoding='utf8')
    sessions=sorted((root/'collections').iterdir(),key=lambda x:x.stat().st_mtime,reverse=True)
    for old in sessions[c['max_sessions']:]:
        if old.is_dir() and old.name[:8].isdigit():shutil.rmtree(old)
    return folder,r
