"""Collect Docker evidence and recommendations without changing container."""
import shutil
def assess(ops,c):
    r={'checks':{},'errors':[],'recommendations':[],'inspect':None,'networks':{},'stats':None}
    def check(k,fn):
        try:r['checks'][k]={'result':'PASS','detail':fn()}
        except Exception as exc:r['checks'][k]={'result':'FAIL','detail':str(exc)};r['errors'].append(f'{k}: {exc}')
    check('docker_cli',lambda:shutil.which('docker') or (_ for _ in ()).throw(RuntimeError('docker not on PATH')))
    check('docker_daemon',ops.ping)
    if r['checks']['docker_daemon']['result']=='FAIL':r['recommendations'].append('Start Docker Desktop and enable WSL integration, or start your Ubuntu Docker Engine. Check docker version.');return r
    try:
        info=ops.inspect(c['container']);r['inspect']=info
        state=info.get('State') or {};status=state.get('Status','unknown');health=(state.get('Health') or {}).get('Status','not configured')
        r['checks']['container']={'result':'PASS' if status=='running' else 'WARN','detail':status}
        r['checks']['health']={'result':'WARN' if health=='unhealthy' else 'PASS','detail':health}
        nets=(info.get('NetworkSettings') or {}).get('Networks') or {};ips={n:v.get('IPAddress','') for n,v in nets.items()}
        r['checks']['ip']={'result':'PASS' if c['expected_ip'] in ips.values() else 'WARN','detail':ips}
        image=(info.get('Config') or {}).get('Image','')
        r['checks']['image']={'result':'PASS' if image==c['expected_image'] else 'WARN','detail':image}
        if c['expected_ip'] not in ips.values():r['recommendations'].append('Inspect Docker network configuration; expected IP differs from assigned IP.')
        if status!='running':r['recommendations'].append('Inspect exit code and container logs before starting the container.')
        if health=='unhealthy':r['recommendations'].append('Inspect Docker healthcheck output and EBO trace logs.')
        r['networks']=ops.networks(nets)
        if status=='running':check('resources',lambda:ops.stats(c['container']))
    except Exception as exc:r['checks']['container']={'result':'FAIL','detail':str(exc)};r['errors'].append(str(exc));r['recommendations'].append('Check docker ps -a and the active Docker context.')
    return r
def safe_inspect(info):
    if not info:return {}
    config=info.get('Config') or {}
    state=info.get('State') or {}
    return {'Id':info.get('Id'),'Name':info.get('Name'),'Created':info.get('Created'),'State':{'Status':state.get('Status'),'ExitCode':state.get('ExitCode'),'Health':{'Status':(state.get('Health') or {}).get('Status')}},'Config':{'Image':config.get('Image'),'Hostname':config.get('Hostname')},'NetworkSettings':{'Networks':(info.get('NetworkSettings') or {}).get('Networks')},'Mounts':[{'Type':x.get('Type'),'Destination':x.get('Destination')} for x in info.get('Mounts',[])]}
