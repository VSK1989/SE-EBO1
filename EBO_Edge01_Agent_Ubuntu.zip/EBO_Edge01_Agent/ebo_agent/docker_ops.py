"""Docker SDK adapter with shell-free CLI fallback."""
import json
import subprocess
class DockerError(RuntimeError):pass
def run(args,timeout=30):
    try:r=subprocess.run(['docker',*args],capture_output=True,text=True,encoding='utf8',errors='replace',timeout=timeout)
    except (OSError,subprocess.TimeoutExpired) as exc:raise DockerError(str(exc)) from exc
    if r.returncode:raise DockerError((r.stderr or r.stdout).strip()[:1500])
    return r.stdout+r.stderr if args and args[0]=='logs' else r.stdout
class DockerOps:
    def __init__(self,backend='auto'):
        self.backend=backend;self.client=None;self.warnings=[]
        if backend!='cli':
            try:
                import docker
                self.client=docker.from_env(timeout=12);self.client.ping()
            except Exception as exc:self.warnings.append('SDK unavailable: '+str(exc));self.client=None
    def call(self,sdk,cli):
        if self.client:
            try:return sdk()
            except Exception as exc:
                self.warnings.append('SDK failed: '+str(exc))
                if self.backend=='sdk':raise DockerError(str(exc)) from exc
        if self.backend=='sdk':raise DockerError('SDK unavailable; use auto or cli')
        return cli()
    def ping(self):return self.call(lambda:self.client.ping(),lambda:bool(run(['info','--format','{{.ServerVersion}}']).strip()))
    def inspect(self,name):return self.call(lambda:self.client.containers.get(name).attrs,lambda:json.loads(run(['inspect','--type','container',name]))[0])
    def logs(self,name,tail):return self.call(lambda:self.client.containers.get(name).logs(tail=tail,stdout=True,stderr=True).decode('utf8','replace'),lambda:run(['logs','--tail',str(tail),name],45))
    def networks(self,names):
        out={}
        for name in names:
            try:out[name]=self.call(lambda n=name:self.client.networks.get(n).attrs,lambda n=name:json.loads(run(['network','inspect',n]))[0])
            except Exception as exc:self.warnings.append(f'Network {name}: {exc}')
        return out
    def stats(self,name):return self.call(lambda:self.client.containers.get(name).stats(stream=False),lambda:json.loads(run(['stats','--no-stream','--format','{{json .}}',name],45)))
    def trace(self,name,path,limit):
        if not path.startswith('/var/sbo/db/logs/') or '..' in path:raise DockerError('Trace path denied')
        return run(['exec',name,'tail','-c',str(limit),path])
