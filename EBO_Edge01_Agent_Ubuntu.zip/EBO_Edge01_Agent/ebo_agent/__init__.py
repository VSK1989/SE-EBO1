"""EBO read-only Docker diagnostic package."""
