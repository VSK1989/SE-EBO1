"""
agent/trace_tools.py -- PORTED, VERIFIED from get-trace.log: pulls
trace.log/trace.log.old directly out of a server's named DB volume via a
disposable ubuntu:focal container (works even if the server container
isn't running).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from . import container_manager as cm
from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)
TRACE_IMAGE = "ubuntu:focal"


def get_trace(cfg: AgentConfig, name_or_ip: str, destination: str, dry_run: bool = False) -> Optional[List[str]]:
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")
    dest_path = Path(destination)
    if not dry_run:
        try:
            dest_path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.error("Could not create destination '%s': %s", destination, exc)
            return None
    rc, _o, err = dt.run_ephemeral_against_volume(
        image=TRACE_IMAGE, volume=db_vol, volume_target=db_folder,
        bind_source=str(dest_path), bind_target="/mnt",
        shell_command=f"cp {db_folder}/db/logs/trace* /mnt/", dry_run=dry_run,
    )
    if rc != 0:
        logger.error("Failed to extract trace logs for '%s': %s", name, err)
        return None
    if dry_run:
        return []
    found = sorted(str(p) for p in dest_path.glob("trace*"))
    if not found:
        logger.warning("No trace* files found in %s.", destination)
    return found
