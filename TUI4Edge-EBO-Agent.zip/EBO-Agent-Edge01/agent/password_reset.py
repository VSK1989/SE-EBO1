"""
agent/password_reset.py -- PORTED, VERIFIED from Bash4Edge's
manageServers.sh "Password Reset": touches a marker file inside the DB
volume via an ephemeral container. No stop/restart of the live server.
"""
from __future__ import annotations

import logging

from . import container_manager as cm
from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def set_password_reset_mode(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False) -> bool:
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"
    rc, out, err = dt.run_ephemeral_against_volume(
        image=image, volume=db_vol, volume_target=db_folder, bind_source=None, bind_target=None,
        shell_command=f"mkdir -p {db_folder}/db/reset && touch {db_folder}/db/reset/r0.txt", dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to set password reset mode for '%s': %s", name, err)
        return False
    logger.info("'%s' should now be in password reset mode.", name)
    return True
