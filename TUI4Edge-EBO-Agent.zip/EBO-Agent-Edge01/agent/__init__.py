"""
agent package
==============
The EBO Docker Agent: cross-platform (Windows Docker Desktop / native
Linux / WSL) management for EBO server containers defined in
config/servers.yml, plus TUI4Edge -- a BIOS-style, full-screen text user
interface launcher (agent/tui/) that wraps every CLI command in an
arrow-key-navigable menu system, modelled visually on classic BIOS setup
utilities (blue background, double-line borders, item-help panel, reverse
-video key legend bar).

See docs/SOURCE_FILES_REVIEW.md for full lineage of every module, and
docs/TUI4EDGE.md for the TUI's screen map and key bindings.
"""

__version__ = "1.3.0"
