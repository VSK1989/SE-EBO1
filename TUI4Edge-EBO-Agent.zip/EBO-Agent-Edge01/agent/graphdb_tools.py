"""
agent/graphdb_tools.py -- PORTED, VERIFIED command shape from Bash4Edge's
manageGraphDb.sh (no volume mount, no EULA env var).
"""
from __future__ import annotations

import logging

from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def create(cfg: AgentConfig, name: str, dry_run: bool = False) -> bool:
    gdb = cfg.get_graphdb_server(name)
    image = f"{gdb.repository}:{gdb.version}"
    dt.pull_image(image, dry_run=dry_run)
    cmd = ["docker", "run", "-d", f"--name={gdb.name}", "-h", gdb.name, "--restart", "always",
           "--network", gdb.network, "--ip", gdb.ip, image]
    rc, _o, err = dt.run_container(cmd, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to create GraphDB '%s': %s", name, err)
        return False
    logger.info("Created '%s'. Access at http://%s:%s", name, gdb.ip, gdb.port)
    return True


def status(name: str, dry_run: bool = False) -> dict:
    if not dt.container_exists(name, dry_run=dry_run):
        return {"name": name, "exists": False}
    info = dt.inspect_container(name, dry_run=dry_run) or {}
    state = info.get("State", {})
    return {"name": name, "exists": True, "running": state.get("Running", False), "status": state.get("Status", "unknown")}


def start(name: str, dry_run: bool = False) -> bool:
    rc, _o, err = dt.start_existing_container(name, dry_run=dry_run)
    return rc == 0


def stop(name: str, dry_run: bool = False) -> bool:
    rc, _o, err = dt.stop_container(name, dry_run=dry_run)
    return rc == 0


def remove(name: str, dry_run: bool = False) -> bool:
    dt.stop_container(name, dry_run=dry_run)
    rc, _o, err = dt.remove_container(name, dry_run=dry_run)
    return rc == 0
