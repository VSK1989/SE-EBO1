r"""
agent/platform_utils.py
==========================
Purpose
-------
The single place that knows "what OS am I running on, and what does that
mean for Docker networking and file paths." Every other module asks THIS
module instead of checking platform.system() itself.

Why: Docker Desktop for Windows runs its daemon inside a hidden WSL2 VM,
where a real host NIC usually isn't available for IPVLAN/MACVLAN binding.
Native Linux Docker Engine (and Bash4Edge, which targets it) can bind an
IPVLAN network straight to a host adapter, giving a container its own LAN
IP. This module lets the agent pick the right strategy automatically.

Functionality
-------------
- detect_os() -> "windows" | "wsl" | "linux" | "macos"
- is_windows() / is_wsl() / is_linux_like()
- default_downloads_dir() -- this host's real Downloads folder
- to_host_path(path) / normalize_bind_source(path) -- Windows<->WSL path translation
- network_strategy(force=None) -> "ipvlan" | "bridge_ports"
- get_local_adapter_info() -- cross-platform adapter/gateway/subnet autodetect
"""
from __future__ import annotations

import logging
import os
import platform
import re
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def detect_os() -> str:
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    if system == "darwin":
        return "macos"
    if system == "linux":
        release = platform.release().lower()
        if "microsoft" in release or "WSL_DISTRO_NAME" in os.environ or "WSL_INTEROP" in os.environ:
            return "wsl"
        return "linux"
    return system or "unknown"


def is_windows() -> bool:
    return detect_os() == "windows"


def is_wsl() -> bool:
    return detect_os() == "wsl"


def is_linux_like() -> bool:
    return detect_os() in ("linux", "wsl", "macos")


def default_downloads_dir() -> str:
    if is_windows():
        userprofile = os.environ.get("USERPROFILE")
        if userprofile:
            return str(Path(userprofile) / "Downloads")
    return str(Path.home() / "Downloads")


_WINDOWS_PATH_RE = re.compile(r"^([A-Za-z]):[\\/](.*)$")


def to_host_path(path: str) -> str:
    m = _WINDOWS_PATH_RE.match(path)
    if m and is_wsl():
        drive, rest = m.group(1).lower(), m.group(2).replace("\\", "/")
        return f"/mnt/{drive}/{rest}"
    return path


def normalize_bind_source(path: str) -> str:
    return to_host_path(path)


def network_strategy(force: Optional[str] = None) -> str:
    if force in ("ipvlan", "bridge_ports"):
        return force
    return "bridge_ports" if is_windows() else "ipvlan"


def _run(cmd, timeout):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def _cidr_to_network(ip_cidr: str) -> Optional[str]:
    try:
        ip_str, prefix_str = ip_cidr.split("/")
        prefix = int(prefix_str)
        octets = [int(o) for o in ip_str.split(".")]
        ip_int = (octets[0] << 24) | (octets[1] << 16) | (octets[2] << 8) | octets[3]
        mask = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF
        net_int = ip_int & mask
        net_octets = [(net_int >> shift) & 0xFF for shift in (24, 16, 8, 0)]
        return f"{'.'.join(str(o) for o in net_octets)}/{prefix}"
    except (ValueError, IndexError):
        return None


def get_local_adapter_info(timeout: float = 5.0) -> dict:
    result = {"interface": None, "gateway": None, "subnet": None, "error": None}
    try:
        if is_windows():
            _get_adapter_info_windows(result, timeout)
        else:
            _get_adapter_info_linux(result, timeout)
    except Exception as exc:  # noqa: BLE001
        result["error"] = str(exc)
        logger.warning("Could not auto-detect local network adapter: %s", exc)
    return result


def _get_adapter_info_linux(result: dict, timeout: float) -> None:
    r = _run(["ip", "route", "get", "8.8.8.8"], timeout)
    if r.returncode != 0:
        result["error"] = r.stderr.strip() or "ip route get failed"
        return
    parts = r.stdout.split()
    if "dev" in parts:
        result["interface"] = parts[parts.index("dev") + 1]
    if result["interface"]:
        r2 = _run(["ip", "route", "show", "dev", result["interface"]], timeout)
        for line in r2.stdout.splitlines():
            fields = line.split()
            if fields and fields[0] == "default" and "via" in fields:
                result["gateway"] = fields[fields.index("via") + 1]
        r3 = _run(["ip", "addr", "show", "dev", result["interface"]], timeout)
        for line in r3.stdout.splitlines():
            fields = line.split()
            if fields and fields[0] == "inet":
                result["subnet"] = _cidr_to_network(fields[1])


def _get_adapter_info_windows(result: dict, timeout: float) -> None:
    ps_script = (
        "$r = Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Sort-Object RouteMetric | Select-Object -First 1; "
        "$ifIndex = $r.InterfaceIndex; "
        "$ipcfg = Get-NetIPAddress -InterfaceIndex $ifIndex -AddressFamily IPv4 | Select-Object -First 1; "
        "$alias = (Get-NetAdapter -InterfaceIndex $ifIndex).Name; "
        "Write-Output (\"$alias|$($r.NextHop)|$($ipcfg.IPAddress)/$($ipcfg.PrefixLength)\")"
    )
    r = _run(["powershell", "-NoProfile", "-Command", ps_script], timeout)
    if r.returncode != 0 or "|" not in r.stdout:
        result["error"] = r.stderr.strip() or "PowerShell adapter query failed"
        return
    alias, gateway, ip_cidr = r.stdout.strip().split("|")
    result["interface"] = alias or None
    result["gateway"] = gateway or None
    result["subnet"] = _cidr_to_network(ip_cidr) if ip_cidr and "/" in ip_cidr else None
