"""
agent/config.py
================
Purpose
-------
Loads config/servers.yml (the real YAML file, shared with Bash4Edge) via
yaml_mini.py, resolving per-server values against serverSettings' shared
defaults (same pattern as Bash4Edge's own checkDefaultSettings()).

Functionality
-------------
AgentConfig.get_server(name) / get_graphdb_server(name) / network /
defaults / log_collection / monitor -- see docstrings below.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

from . import platform_utils as pf
from .yaml_mini import YamlMiniError, load_yaml_file


class ConfigError(Exception):
    pass


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config" / "servers.yml"


def _eula_str(value) -> str:
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if value is None:
        return "Yes"
    return str(value)


@dataclass
class ServerConfig:
    name: str
    repo: str
    type: str
    version: str
    ip: str
    accept_eula: str = "Yes"
    network: str = "bridged-net"
    dns: Optional[str] = None
    http_proxy: Optional[str] = None
    https_proxy: Optional[str] = None
    no_proxy: Optional[str] = None
    ca_bundle: Optional[str] = None
    ca_folder: Optional[str] = None
    graphdb: str = ""


@dataclass
class GraphDbServerConfig:
    name: str
    repository: str
    version: str
    port: int
    network: str
    ip: str


@dataclass
class AgentConfig:
    raw: Dict[str, Any] = field(repr=False)
    path: Path

    def _server_raw(self, name: str) -> Dict[str, Any]:
        servers = self.raw.get("servers", {})
        if name not in servers:
            raise ConfigError(f"Server '{name}' not found in {self.path}. Configured: {list(servers.keys())}")
        return servers[name] or {}

    def _resolve(self, server_raw: Dict[str, Any], field_name: str, fallback=None):
        if field_name in server_raw and server_raw[field_name] is not None:
            return server_raw[field_name]
        settings = self.raw.get("serverSettings", {}) or {}
        if field_name in settings and settings[field_name] is not None:
            return settings[field_name]
        return fallback

    @property
    def network(self) -> Dict[str, Any]:
        networks = self.raw.get("networks", {}) or {}
        if not networks:
            return {}
        name, body = next(iter(networks.items()))
        out = {"name": name, **(body or {})}
        extra = ((self.raw.get("agentSettings") or {}).get("network") or {})
        out.update({k: v for k, v in extra.items() if k not in out or k == "force_strategy"})
        return out

    @property
    def defaults(self) -> Dict[str, Any]:
        s = self.raw.get("serverSettings", {}) or {}
        return {
            "accept_eula": _eula_str(s.get("accept_eula", "Yes")),
            "db_folder": s.get("db_folder", "/var/sbo"),
            "db_vol_suffix": s.get("db_vol_suffix", "-db"),
            "crash_folder": s.get("crash_folder", "/var/crash"),
            "dns": s.get("dns_ip"),
            "http_proxy": s.get("http_proxy"),
            "https_proxy": s.get("https_proxy"),
            "no_proxy": s.get("no_proxy"),
            "ca_bundle": s.get("ca_bundle"),
            "ca_folder": s.get("ca_folder"),
            "graphdb": s.get("graphdb_URL", "") or "",
            "working_dir": s.get("working_dir", "~/Edge"),
        }

    @property
    def log_collection(self) -> Dict[str, Any]:
        lc = dict(((self.raw.get("agentSettings") or {}).get("log_collection")) or {})
        lc.setdefault("enabled", True)
        lc.setdefault("output_dir", pf.default_downloads_dir() + os.sep + "DOCKER" + os.sep + "CONTAINER1")
        lc.setdefault("tail_lines", 500)
        lc.setdefault("interval_seconds", 300)
        lc.setdefault("keep_last_n_collections", 20)
        return lc

    @property
    def monitor(self) -> Dict[str, Any]:
        mon = dict(((self.raw.get("agentSettings") or {}).get("monitor")) or {})
        mon.setdefault("poll_interval_seconds", 60)
        mon.setdefault("auto_restart", False)
        mon.setdefault("max_auto_restart_attempts", 3)
        mon.setdefault("connectivity_check_enabled", True)
        mon.setdefault("connectivity_check_port", 443)
        mon.setdefault("connectivity_timeout_seconds", 3)
        return mon

    def repo_image(self, repo_name: str) -> str:
        repos = self.raw.get("repos", {}) or {}
        if repo_name not in repos:
            raise ConfigError(f"repos.{repo_name} not found in {self.path}.")
        return repos[repo_name]["repository"]

    def list_server_names(self):
        return list((self.raw.get("servers") or {}).keys())

    def get_server(self, name: str) -> ServerConfig:
        s = self._server_raw(name)
        try:
            repo_ref = s["repo"]
        except KeyError as exc:
            raise ConfigError(f"Server '{name}' missing required field 'repo'.") from exc
        repos = self.raw.get("repos", {}) or {}
        if repo_ref not in repos:
            raise ConfigError(f"Server '{name}' references unknown repo '{repo_ref}'.")
        repo_url = repos[repo_ref]["repository"]
        type_suffix = repo_url.rsplit("/", 1)[-1]
        try:
            version = s["version"]
            ip = s["ip"]
        except KeyError as exc:
            raise ConfigError(f"Server '{name}' missing required field {exc}.") from exc

        return ServerConfig(
            name=name, repo=repo_ref, type=type_suffix, version=version, ip=ip,
            accept_eula=_eula_str(self._resolve(s, "accept_eula", "Yes")),
            network=self._resolve(s, "network", self.network.get("name", "bridged-net")),
            dns=self._resolve(s, "dns_ip"),
            http_proxy=self._resolve(s, "http_proxy"),
            https_proxy=self._resolve(s, "https_proxy"),
            no_proxy=self._resolve(s, "no_proxy"),
            ca_bundle=self._resolve(s, "ca_bundle"),
            ca_folder=self._resolve(s, "ca_folder"),
            graphdb=self._resolve(s, "graphdb_URL", "") or "",
        )

    def list_graphdb_server_names(self):
        return list((self.raw.get("semanticsDbs") or {}).keys())

    def get_graphdb_server(self, name: str) -> GraphDbServerConfig:
        gds = self.raw.get("semanticsDbs", {}) or {}
        if name not in gds:
            raise ConfigError(f"GraphDB server '{name}' not found. Configured: {self.list_graphdb_server_names()}")
        g = gds[name]
        try:
            return GraphDbServerConfig(
                name=name, repository=g["repository"], version=str(g["version"]),
                port=int(g["port"]), network=g.get("network", self.network.get("name", "bridged-net")),
                ip=g["ip"],
            )
        except KeyError as exc:
            raise ConfigError(f"GraphDB server '{name}' missing required field {exc}.") from exc


def load_config(path: Optional[os.PathLike] = None) -> AgentConfig:
    cfg_path = Path(path) if path else DEFAULT_CONFIG_PATH
    if not cfg_path.exists():
        raise ConfigError(f"Configuration file not found: {cfg_path}")
    try:
        raw = load_yaml_file(cfg_path)
    except YamlMiniError as exc:
        raise ConfigError(f"Could not parse {cfg_path}: {exc}") from exc
    if not raw.get("servers"):
        raise ConfigError(f"No 'servers' defined in {cfg_path}.")
    return AgentConfig(raw=raw, path=cfg_path)
