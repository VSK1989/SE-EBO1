"""
agent/agent.py -- CLI orchestrator. Adds a `tui` subcommand that launches
TUI4Edge (agent/tui/), alongside the existing plain-text commands.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time

from . import backup_tools as bt
from . import container_manager as cm
from . import decision_engine as de
from . import discovery
from . import graphdb_tools as gdt
from . import log_collector as lc
from . import password_reset as pr
from . import platform_utils as pf
from . import trace_tools as tt
from .config import ConfigError, load_config
from .logging_setup import configure_logging

logger = logging.getLogger(__name__)


def _print_discovery(results) -> None:
    for d in results:
        print(f"\n{d.name}:")
        print(f"  Exists:        {d.exists}")
        print(f"  Running:       {d.running}")
        print(f"  Configured IP: {d.configured_ip}")
        print(f"  Runtime IP:    {d.runtime_ip or '(not running)'}")
        if d.ip_drifted:
            print("  WARNING: IP DRIFT DETECTED -- run 'sync-ip' to correct config/servers.yml")
        if d.reachable is not None or d.reachable_detail:
            print(f"  Connectivity:  {d.reachable_detail}")


def cmd_list(args, cfg):
    print(f"Host OS detected: {pf.detect_os()}  (network strategy: {pf.network_strategy()})")
    print("Configured servers:")
    for n in cfg.list_server_names():
        s = cfg.get_server(n)
        print(f"  - {n}: type={s.type} version={s.version} ip={s.ip}")


def cmd_tui(args, cfg):
    from .tui.app import run_tui
    run_tui(cfg)


def cmd_status(args, cfg):
    status = cm.status(args.name, cfg=cfg, dry_run=args.dry_run)
    decision = de.evaluate(cfg, args.name, dry_run=args.dry_run)
    print(status)
    print(decision.summary())


def cmd_start(args, cfg):
    sys.exit(0 if cm.start(cfg, args.name, dry_run=args.dry_run, test_mode=args.test_mode) else 1)


def cmd_discover(args, cfg):
    _print_discovery(discovery.discover_servers(cfg, dry_run=args.dry_run, force=True))


def cmd_validate(args, cfg):
    _print_discovery(discovery.validate_all(cfg, dry_run=args.dry_run))


def cmd_sync_ip(args, cfg):
    messages = discovery.sync_ip_drift(cfg, auto_fix=not args.report_only, dry_run=args.dry_run)
    print("\n".join(messages) if messages else "No IP drift detected.")


def cmd_monitor(args, cfg):
    interval = cfg.monitor.get("poll_interval_seconds", 60)
    attempt_counters: dict = {}
    try:
        while True:
            for name in cfg.list_server_names():
                de.decide_and_act(cfg, name, attempt_counters, dry_run=args.dry_run)
                lc.collect_one(cfg, name, dry_run=args.dry_run)
            if args.once:
                break
            time.sleep(interval)
    except KeyboardInterrupt:
        logger.info("Monitor loop stopped by user.")


def cmd_auto(args, cfg):
    _print_discovery(discovery.discover_servers(cfg, dry_run=args.dry_run, force=True))
    if args.sync_ip:
        for m in discovery.sync_ip_drift(cfg, auto_fix=True, dry_run=args.dry_run):
            logger.info(m)
    _print_discovery(discovery.validate_all(cfg, dry_run=args.dry_run))
    cmd_monitor(args, cfg)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ebo-agent")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    parser.add_argument("--config", default=None)
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list").set_defaults(func=cmd_list)
    sub.add_parser("tui", help="Launch TUI4Edge (BIOS-style full-screen interface).").set_defaults(func=cmd_tui)

    p = sub.add_parser("status"); p.add_argument("name"); p.set_defaults(func=cmd_status)
    p = sub.add_parser("start"); p.add_argument("name"); p.add_argument("--test-mode", action="store_true")
    p.set_defaults(func=cmd_start)
    p = sub.add_parser("discover"); p.set_defaults(func=cmd_discover)
    p = sub.add_parser("validate"); p.set_defaults(func=cmd_validate)
    p = sub.add_parser("sync-ip"); p.add_argument("--report-only", action="store_true"); p.set_defaults(func=cmd_sync_ip)
    p = sub.add_parser("monitor"); p.add_argument("--once", action="store_true"); p.set_defaults(func=cmd_monitor)
    p = sub.add_parser("auto"); p.add_argument("--once", action="store_true"); p.add_argument("--sync-ip", action="store_true")
    p.set_defaults(func=cmd_auto)

    return parser


def main(argv=None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    configure_logging(verbose=args.verbose)
    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        logger.error(str(exc))
        sys.exit(2)
    args.func(args, cfg)


if __name__ == "__main__":
    main()
