"""
agent/log_collector.py -- timestamped diagnostic snapshots (docker logs +
inspect + health report + trace files) into the cross-platform Downloads
folder.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from . import container_manager as cm
from . import decision_engine as de
from . import docker_tools as dt
from . import trace_tools as tt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def collect_one(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False) -> Optional[Path]:
    lc = cfg.log_collection
    if not lc.get("enabled", True):
        return None
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    output_root = Path(lc.get("output_dir"))
    snapshot_dir = output_root / name / _timestamp()
    try:
        snapshot_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.warning("Could not create '%s': %s", snapshot_dir, exc)
        return None
    tail = lc.get("tail_lines", 500)
    (snapshot_dir / f"{name}_docker.log").write_text(dt.get_logs(name, tail=tail, dry_run=dry_run) or "", encoding="utf-8")
    info = dt.inspect_container(name, dry_run=dry_run)
    (snapshot_dir / f"{name}_inspect.json").write_text(json.dumps(info or {}, indent=2), encoding="utf-8")
    decision = de.evaluate(cfg, name, dry_run=dry_run)
    (snapshot_dir / f"{name}_health_report.txt").write_text(
        f"Collected at: {datetime.now().isoformat()}\n\n{decision.summary()}\n", encoding="utf-8")
    try:
        tt.get_trace(cfg, name, str(snapshot_dir / f"{name}_trace"), dry_run=dry_run)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Trace extraction skipped: %s", exc)
    _prune_old_collections(output_root / name, keep=lc.get("keep_last_n_collections", 20))
    return snapshot_dir


def _prune_old_collections(container_dir: Path, keep: int) -> None:
    if not container_dir.exists():
        return
    try:
        snapshots = sorted([p for p in container_dir.iterdir() if p.is_dir()], key=lambda p: p.name)
    except OSError:
        return
    for old_dir in snapshots[:max(0, len(snapshots) - keep)]:
        try:
            for f in old_dir.rglob("*"):
                if f.is_file():
                    f.unlink(missing_ok=True)
            for d in sorted(old_dir.rglob("*"), key=lambda p: len(p.parts), reverse=True):
                if d.is_dir():
                    d.rmdir()
            old_dir.rmdir()
        except OSError:
            pass


def collect_all(cfg: AgentConfig, dry_run: bool = False) -> None:
    for name in cfg.list_server_names():
        collect_one(cfg, name, dry_run=dry_run)
