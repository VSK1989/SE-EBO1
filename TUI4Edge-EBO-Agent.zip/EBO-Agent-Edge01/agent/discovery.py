"""
agent/discovery.py
=====================
Purpose
-------
Cached container discovery, runtime-IP lookup, IP-drift detection/sync,
and TCP connectivity validation. A 5-second in-process cache avoids
repeated `docker ps -a` / `docker inspect` subprocess launches within a
single CLI run or TUI refresh (performance).
"""
from __future__ import annotations

import logging
import socket
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from . import docker_tools as dt
from . import yaml_mini
from .config import AgentConfig

logger = logging.getLogger(__name__)
CACHE_TTL_SECONDS = 5.0
_cache: Dict[str, tuple] = {}


def _cached(key: str, producer, force: bool = False):
    now = time.monotonic()
    if not force and key in _cache:
        ts, value = _cache[key]
        if now - ts < CACHE_TTL_SECONDS:
            return value
    value = producer()
    _cache[key] = (now, value)
    return value


def clear_cache() -> None:
    _cache.clear()


def list_all_containers(dry_run: bool = False, force: bool = False) -> List[dict]:
    def _producer():
        rc, out, _e = dt.exe(["docker", "ps", "-a", "--format", "{{.Names}}\t{{.ID}}\t{{.Status}}\t{{.Image}}"], dry_run=dry_run)
        if dry_run or rc != 0:
            return []
        rows = []
        for line in out.splitlines():
            parts = line.split("\t")
            if len(parts) >= 4:
                rows.append({"name": parts[0], "id": parts[1], "status": parts[2], "image": parts[3]})
        return rows
    return _cached(f"ps_all:{dry_run}", _producer, force=force)


def container_exists_cached(name: str, dry_run: bool = False, force: bool = False) -> bool:
    return any(row["name"] == name for row in list_all_containers(dry_run=dry_run, force=force))


def get_runtime_ip(name: str, dry_run: bool = False, force: bool = False) -> Optional[str]:
    def _producer():
        info = dt.inspect_container(name, dry_run=dry_run)
        if not info:
            return None
        networks = info.get("NetworkSettings", {}).get("Networks", {}) or {}
        for _n, net_info in networks.items():
            ip = net_info.get("IPAddress")
            if ip:
                return ip
        return info.get("NetworkSettings", {}).get("IPAddress") or None
    return _cached(f"ip:{name}:{dry_run}", _producer, force=force)


@dataclass
class ServerDiscovery:
    name: str
    exists: bool
    running: bool
    configured_ip: str
    runtime_ip: Optional[str]
    ip_drifted: bool
    reachable: Optional[bool] = None
    reachable_detail: str = ""


def discover_servers(cfg: AgentConfig, dry_run: bool = False, force: bool = False) -> List[ServerDiscovery]:
    results = []
    for name in cfg.list_server_names():
        server = cfg.get_server(name)
        exists = container_exists_cached(name, dry_run=dry_run, force=force)
        running = dt.is_running(name, dry_run=dry_run) if exists else False
        runtime_ip = get_runtime_ip(name, dry_run=dry_run, force=force) if running else None
        drifted = bool(runtime_ip and runtime_ip != server.ip)
        results.append(ServerDiscovery(name=name, exists=exists, running=running,
                                        configured_ip=server.ip, runtime_ip=runtime_ip, ip_drifted=drifted))
    return results


def sync_ip_drift(cfg: AgentConfig, auto_fix: bool = False, dry_run: bool = False) -> List[str]:
    messages = []
    for disc in discover_servers(cfg, dry_run=dry_run):
        if not disc.ip_drifted:
            continue
        msg = f"{disc.name}: configured IP {disc.configured_ip} != runtime IP ({disc.runtime_ip})."
        if auto_fix and not dry_run:
            ok = yaml_mini.update_scalar_in_file(cfg.path, f"servers.{disc.name}.ip", disc.runtime_ip)
            msg += f" Corrected servers.yml to {disc.runtime_ip}." if ok else " Could not locate the line to patch."
        else:
            msg += " Run sync-ip to correct automatically."
        messages.append(msg)
    return messages


def validate_connectivity(ip: str, port: int = 443, timeout: float = 3.0) -> bool:
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except OSError:
        return False


def validate_all(cfg: AgentConfig, dry_run: bool = False) -> List[ServerDiscovery]:
    mon = cfg.monitor
    if not mon.get("connectivity_check_enabled", True):
        return discover_servers(cfg, dry_run=dry_run)
    port = int(mon.get("connectivity_check_port", 443))
    timeout = float(mon.get("connectivity_timeout_seconds", 3))
    results = discover_servers(cfg, dry_run=dry_run)
    for disc in results:
        if dry_run:
            disc.reachable_detail = "skipped (dry-run)"
            continue
        if not disc.exists:
            disc.reachable = False
            disc.reachable_detail = "container does not exist"
            continue
        target_ip = disc.runtime_ip or disc.configured_ip
        ok = validate_connectivity(target_ip, port=port, timeout=timeout)
        disc.reachable = ok
        disc.reachable_detail = f"TCP {target_ip}:{port} {'reachable' if ok else 'UNREACHABLE'}"
    return results
