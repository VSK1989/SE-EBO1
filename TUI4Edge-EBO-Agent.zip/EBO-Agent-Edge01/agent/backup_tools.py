"""
agent/backup_tools.py -- list-backups/copy-backups/restore-backup,
corrected against Bash4Edge's verified manageBackups.sh (ephemeral
bind+volume-mount copy-in, no stop before restore -- only a restart at
the end).
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from . import container_manager as cm
from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)
BACKUP_SUBPATH = "db_backup/LocalBackup"


def list_backups(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False) -> List[str]:
    server = cm.resolve_target(cfg, name_or_ip)
    db_folder = cfg.defaults.get("db_folder", "/var/sbo")
    backup_dir = f"{db_folder}/{BACKUP_SUBPATH}"
    rc, out, err = dt.docker_exec(server.name, ["ls", backup_dir], dry_run=dry_run)
    if dry_run:
        return []
    if rc != 0:
        logger.error("Failed to list backups for '%s': %s", server.name, err)
        return []
    return [line.strip().strip('"') for line in out.splitlines() if line.strip()]


def copy_backups(cfg: AgentConfig, name_or_ip: str, destination: str, dry_run: bool = False) -> bool:
    server = cm.resolve_target(cfg, name_or_ip)
    db_folder = cfg.defaults.get("db_folder", "/var/sbo")
    backup_dir = f"{db_folder}/{BACKUP_SUBPATH}/."
    rc, _o, err = dt.copy_from_container(server.name, backup_dir, destination, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to copy backups: %s", err)
        return False
    logger.info("Copied backups from '%s' to '%s'.", server.name, destination)
    return True


def restore_backup(cfg: AgentConfig, name_or_ip: str, version: str, backup: str,
                    mode: str = "ConfigurationOnly", from_host_path: Optional[str] = None,
                    dry_run: bool = False) -> bool:
    if mode not in ("ConfigurationOnly", "AllData"):
        logger.error("Invalid restore mode '%s'.", mode)
        return False
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"

    if from_host_path:
        host_folder = str(Path(from_host_path).parent)
        filename = Path(from_host_path).name
        rc, _o, err = dt.run_ephemeral_against_volume(
            image=image, volume=db_vol, volume_target=db_folder,
            bind_source=host_folder, bind_target="/mnt",
            shell_command=f"cp '/mnt/{filename}' {db_folder}/{BACKUP_SUBPATH}/", dry_run=dry_run)
        if rc != 0:
            logger.error("Failed to copy host backup in: %s", err)
            return False
        backup = filename

    rc, out, err = dt.exe(["docker", "run", "--rm", "--mount", f"source={db_vol},target={db_folder}",
                           image, "/opt/sbo/bin/prepare-restore", backup, mode], dry_run=dry_run)
    if rc != 0:
        logger.error("Restore failed for '%s': %s", name, err)
        return False
    dt.restart_container(name, dry_run=dry_run)
    logger.info("Restore of '%s' (%s, mode=%s) complete.", name, backup, mode)
    return True
