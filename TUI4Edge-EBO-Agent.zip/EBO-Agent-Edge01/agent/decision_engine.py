"""
agent/decision_engine.py -- rule-based health evaluation (missing/stopped/
running/unreachable/restart_loop), including TCP-reachability awareness.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import List

from . import container_manager as cm
from . import discovery
from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)

KNOWN_LOG_PATTERNS = [
    (re.compile(r"accept.*eula|EULA", re.IGNORECASE), "warning", "Server waiting for EULA acceptance."),
    (re.compile(r"license|activation", re.IGNORECASE), "warning", "Possible licensing issue."),
    (re.compile(r"out of memory|oom", re.IGNORECASE), "critical", "Out-of-memory condition detected."),
    (re.compile(r"connection refused|network is unreachable|dns", re.IGNORECASE), "warning", "Network/DNS issue."),
    (re.compile(r"database.*(error|corrupt)|db.*(error|corrupt)", re.IGNORECASE), "critical", "Possible DB error."),
    (re.compile(r"traceback|unhandled exception|fatal", re.IGNORECASE), "critical", "Unhandled exception/fatal error."),
]
RESTART_LOOP_THRESHOLD = 5


@dataclass
class Decision:
    name: str
    state: str
    action: str
    reasons: List[str] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"[{self.name}] state={self.state} action={self.action}"]
        lines += [f"  reason: {r}" for r in self.reasons] + [f"  finding: {f}" for f in self.findings]
        return "\n".join(lines)


def _scan_logs(text: str) -> List[str]:
    return [f"({sev}) {adv}" for pat, sev, adv in KNOWN_LOG_PATTERNS if pat.search(text or "")]


def evaluate(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False) -> Decision:
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    if not discovery.container_exists_cached(name, dry_run=dry_run):
        return Decision(name=name, state="missing", action="create", reasons=["Container does not exist yet."])
    info = dt.inspect_container(name, dry_run=dry_run) or {}
    running = info.get("State", {}).get("Running", False)
    restart_count = info.get("RestartCount", 0)
    logs_tail = dt.get_logs(name, tail=cfg.log_collection.get("tail_lines", 500), dry_run=dry_run)
    findings = _scan_logs(logs_tail)

    if restart_count >= RESTART_LOOP_THRESHOLD:
        return Decision(name=name, state="restart_loop", action="alert",
                         reasons=[f"RestartCount={restart_count} >= {RESTART_LOOP_THRESHOLD}."], findings=findings)
    if not running:
        return Decision(name=name, state="stopped", action="restart",
                         reasons=["Container exists but is not running."], findings=findings)

    mon = cfg.monitor
    if mon.get("connectivity_check_enabled", True) and not dry_run:
        runtime_ip = discovery.get_runtime_ip(name) or server.ip
        reachable = discovery.validate_connectivity(runtime_ip, port=int(mon.get("connectivity_check_port", 443)),
                                                      timeout=float(mon.get("connectivity_timeout_seconds", 3)))
        if not reachable:
            return Decision(name=name, state="unreachable", action="alert",
                             reasons=[f"Running per Docker, but not responding on {runtime_ip}."], findings=findings)
    if findings:
        return Decision(name=name, state="running", action="alert",
                         reasons=["Running, but potential issues found in logs."], findings=findings)
    return Decision(name=name, state="running", action="none", reasons=["Healthy."])


def decide_and_act(cfg: AgentConfig, name_or_ip: str, attempt_counters: dict, dry_run: bool = False) -> Decision:
    decision = evaluate(cfg, name_or_ip, dry_run=dry_run)
    mon = cfg.monitor
    auto_restart = mon.get("auto_restart", False)
    max_attempts = mon.get("max_auto_restart_attempts", 3)
    name = decision.name
    if decision.action in ("restart", "create") and auto_restart:
        attempts = attempt_counters.get(name, 0)
        if attempts >= max_attempts:
            decision.action = "alert"
            decision.reasons.append("Auto-restart attempt budget exhausted.")
            logger.warning(decision.summary())
            return decision
        attempt_counters[name] = attempts + 1
        if decision.action == "create":
            cm.start(cfg, name, dry_run=dry_run)
        else:
            cm.restart(name, cfg=cfg, dry_run=dry_run)
    else:
        (logger.warning if decision.action != "none" else logger.info)(decision.summary())
    return decision
