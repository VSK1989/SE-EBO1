"""
agent/tui/widgets.py
=======================
Purpose
-------
Reusable BIOS-style widgets, each a small piece of STATE plus a draw(canvas,
...) method. None of these call term_io directly -- they only draw into a
theme.Canvas -- which is what keeps their layout/navigation logic testable
without a real terminal (see tests/test_tui_widgets.py).

Widgets
-------
- MenuItem / Menu: a vertical list of selectable items, each with its own
  "item help" text shown in a side panel -- the single most recognisable
  BIOS UI element.
- TabBar: a row of top-level category tabs (Main | Servers | Network |
  Diagnostics | About), Left/Right-arrow navigable.
- ToggleField: a "Label:   < value >" field whose value cycles through a
  fixed list with Left/Right -- exactly how a real BIOS lets you change a
  setting in place.
- LegendBar: the reverse-video key-hint bar pinned to the bottom row.
- wrap_text(text, width): simple word-wrap helper shared by several widgets.

Modal helpers (confirm / prompt_text / show_scrollable_text) are blocking
functions, not classes: each runs its own tiny draw+read_key loop and
returns a value, which is the simplest honest way to implement a modal
dialog without a more elaborate screen-stack-of-stacks design.

How it interacts with other modules
------------------------------------
agent/tui/screens.py builds Menu/TabBar/ToggleField instances and calls
the confirm()/prompt_text()/show_scrollable_text() helpers from inside its
action handlers. agent/tui/app.py never touches widgets directly.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, List, Optional, Sequence

from . import term_io
from .theme import (
    Canvas, DEFAULT_FG, DEFAULT_BG, TITLE_FG, SELECTED_FG, SELECTED_BG,
    HELP_FG, LEGEND_FG, LEGEND_BG, ERROR_FG, OK_FG, WARN_FG, SGL_H, SGL_V,
)


def wrap_text(text: str, width: int) -> List[str]:
    """Simple word-wrap: splits on whitespace, greedily fills lines of at
    most `width` characters. Pre-existing newlines are respected."""
    lines: List[str] = []
    for paragraph in text.split("\n"):
        words = paragraph.split(" ")
        current = ""
        for word in words:
            candidate = f"{current} {word}".strip()
            if len(candidate) > width and current:
                lines.append(current)
                current = word
            else:
                current = candidate
        lines.append(current)
    return lines


@dataclass
class MenuItem:
    label: str
    help_text: str = ""
    disabled: bool = False
    tag: Optional[str] = None  # arbitrary payload the screen can use


class Menu:
    """A vertical list of MenuItems with an optional side "item help" panel."""

    def __init__(self, items: Sequence[MenuItem]):
        self.items = list(items)
        self.index = 0
        self._clamp()

    def _clamp(self) -> None:
        if not self.items:
            self.index = 0
            return
        self.index = max(0, min(self.index, len(self.items) - 1))

    def move_up(self) -> None:
        if self.items:
            self.index = (self.index - 1) % len(self.items)

    def move_down(self) -> None:
        if self.items:
            self.index = (self.index + 1) % len(self.items)

    def current(self) -> Optional[MenuItem]:
        return self.items[self.index] if self.items else None

    def draw(self, canvas: Canvas, x: int, y: int, w: int, h: int, help_panel: bool = True) -> None:
        list_w = w if not help_panel else int(w * 0.55)
        canvas.box(x, y, list_w, h, double=False, title="Menu")
        visible_h = h - 2
        start = max(0, self.index - visible_h + 1) if self.index >= visible_h else 0
        for row, item in enumerate(self.items[start:start + visible_h]):
            idx = start + row
            is_sel = idx == self.index
            fg = SELECTED_FG if is_sel else (DEFAULT_FG if not item.disabled else 90)
            bg = SELECTED_BG if is_sel else DEFAULT_BG
            label = item.label[: list_w - 4].ljust(list_w - 4)
            prefix = "> " if is_sel else "  "
            canvas.put(x + 1, y + 1 + row, f"{prefix}{label}", fg, bg)

        if help_panel:
            help_x = x + list_w
            help_w = w - list_w
            canvas.box(help_x, y, help_w, h, double=False, title="Item Help")
            current = self.current()
            if current and current.help_text:
                for i, line in enumerate(wrap_text(current.help_text, help_w - 4)):
                    if i >= h - 2:
                        break
                    canvas.put(help_x + 2, y + 1 + i, line, HELP_FG, DEFAULT_BG)


class TabBar:
    def __init__(self, labels: Sequence[str]):
        self.labels = list(labels)
        self.index = 0

    def move_left(self) -> None:
        self.index = (self.index - 1) % len(self.labels)

    def move_right(self) -> None:
        self.index = (self.index + 1) % len(self.labels)

    def current(self) -> str:
        return self.labels[self.index]

    def draw(self, canvas: Canvas, x: int, y: int, w: int) -> None:
        canvas.fill_rect(x, y, w, 1, DEFAULT_FG, DEFAULT_BG)
        cursor = x + 2
        for i, label in enumerate(self.labels):
            text = f" {label} "
            fg = SELECTED_FG if i == self.index else TITLE_FG
            bg = SELECTED_BG if i == self.index else DEFAULT_BG
            canvas.put(cursor, y, text, fg, bg)
            cursor += len(text) + 2


class ToggleField:
    """A 'Label:   < value >' field; Left/Right cycles through `options`."""

    def __init__(self, label: str, options: Sequence[str], index: int = 0, help_text: str = ""):
        self.label = label
        self.options = list(options)
        self.index = index
        self.help_text = help_text

    def value(self) -> str:
        return self.options[self.index] if self.options else ""

    def move_left(self) -> None:
        if self.options:
            self.index = (self.index - 1) % len(self.options)

    def move_right(self) -> None:
        if self.options:
            self.index = (self.index + 1) % len(self.options)

    def draw(self, canvas: Canvas, x: int, y: int, w: int, selected: bool = False) -> None:
        fg = TITLE_FG if selected else DEFAULT_FG
        canvas.put(x, y, self.label.ljust(26), fg, DEFAULT_BG)
        val = f"<  {self.value()}  >"
        canvas.put(x + 26, y, val, SELECTED_FG if selected else DEFAULT_FG,
                   SELECTED_BG if selected else DEFAULT_BG)


class LegendBar:
    def __init__(self, hints: Sequence[str]):
        self.hints = list(hints)

    def draw(self, canvas: Canvas, y: int) -> None:
        canvas.fill_rect(0, y, canvas.cols, 1, LEGEND_FG, LEGEND_BG)
        text = "  ".join(self.hints)
        canvas.put(1, y, text[: canvas.cols - 2], LEGEND_FG, LEGEND_BG)


# --- Blocking modal helpers ----------------------------------------------

def _frame(draw_background: Callable[[Canvas], None]) -> Canvas:
    cols, rows = term_io.get_terminal_size()
    canvas = Canvas(cols, rows)
    draw_background(canvas)
    return canvas


def confirm(draw_background: Callable[[Canvas], None], title: str, message: str, default_yes: bool = False) -> bool:
    """Blocking Y/N confirmation dialog, BIOS-style, centred on screen."""
    choice = 1 if default_yes else 0  # 0 = No, 1 = Yes (matches typical BIOS "safe default")
    options = ["No", "Yes"]
    while True:
        canvas = _frame(draw_background)
        w, h = min(56, canvas.cols - 4), 9
        x, y = (canvas.cols - w) // 2, (canvas.rows - h) // 2
        canvas.fill_rect(x, y, w, h, DEFAULT_FG, DEFAULT_BG)
        canvas.box(x, y, w, h, double=True, title=title)
        for i, line in enumerate(wrap_text(message, w - 4)[:3]):
            canvas.put(x + 2, y + 2 + i, line, DEFAULT_FG, DEFAULT_BG)
        for i, label in enumerate(options):
            is_sel = i == choice
            fg = SELECTED_FG if is_sel else DEFAULT_FG
            bg = SELECTED_BG if is_sel else DEFAULT_BG
            canvas.put(x + 10 + i * 14, y + h - 3, f"  {label}  ", fg, bg)
        term_io.write(canvas.render())
        key = term_io.read_key()
        if key in ("LEFT", "RIGHT", "TAB"):
            choice = 1 - choice
        elif key in ("y", "Y"):
            return True
        elif key in ("n", "N"):
            return False
        elif key == "ENTER":
            return choice == 1
        elif key == "ESC":
            return False


def prompt_text(draw_background: Callable[[Canvas], None], title: str, prompt: str,
                 initial: str = "") -> Optional[str]:
    """Blocking single-line text input dialog. ENTER confirms, ESC cancels."""
    value = initial
    while True:
        canvas = _frame(draw_background)
        w, h = min(64, canvas.cols - 4), 8
        x, y = (canvas.cols - w) // 2, (canvas.rows - h) // 2
        canvas.fill_rect(x, y, w, h, DEFAULT_FG, DEFAULT_BG)
        canvas.box(x, y, w, h, double=True, title=title)
        for i, line in enumerate(wrap_text(prompt, w - 4)[:2]):
            canvas.put(x + 2, y + 2 + i, line, DEFAULT_FG, DEFAULT_BG)
        field_y = y + h - 3
        canvas.hline(x + 2, field_y, w - 4, SGL_H, DEFAULT_FG, DEFAULT_BG)
        canvas.put(x + 2, field_y + 1, (value + "_")[: w - 4], TITLE_FG, DEFAULT_BG)
        term_io.write(canvas.render())
        key = term_io.read_key()
        if key == "ENTER":
            return value
        if key == "ESC":
            return None
        if key == "BACKSPACE":
            value = value[:-1]
        elif key and len(key) == 1 and key.isprintable():
            value += key


def show_scrollable_text(draw_background: Callable[[Canvas], None], title: str, lines: List[str]) -> None:
    """Blocking scrollable text viewer. Up/Down/PgUp/PgDn scroll, ESC/ENTER closes."""
    offset = 0
    while True:
        canvas = _frame(draw_background)
        w, h = canvas.cols - 8, canvas.rows - 6
        x, y = 4, 3
        canvas.fill_rect(x, y, w, h, DEFAULT_FG, DEFAULT_BG)
        canvas.box(x, y, w, h, double=True, title=title)
        visible_h = h - 2
        for i, line in enumerate(lines[offset:offset + visible_h]):
            canvas.put(x + 2, y + 1 + i, line[: w - 4], DEFAULT_FG, DEFAULT_BG)
        if len(lines) > visible_h:
            canvas.put(x + w - 14, y + h - 1, f" {offset+1}-{min(offset+visible_h,len(lines))}/{len(lines)} ",
                       DEFAULT_FG, DEFAULT_BG)
        term_io.write(canvas.render())
        key = term_io.read_key()
        if key in ("ESC", "ENTER"):
            return
        if key == "DOWN":
            offset = min(max(0, len(lines) - visible_h), offset + 1)
        elif key == "UP":
            offset = max(0, offset - 1)
        elif key == "PGDN":
            offset = min(max(0, len(lines) - visible_h), offset + visible_h)
        elif key == "PGUP":
            offset = max(0, offset - visible_h)
