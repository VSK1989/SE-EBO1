"""
agent/tui/app.py
===================
Purpose
-------
TuiApp: the screen stack + main event loop that ties term_io (real
terminal), theme.Canvas (drawing surface), and screens.py (application
logic) together.

Functionality
-------------
- A simple stack of Screen objects: the current screen is always
  stack[-1]. A screen's handle_key() can return None (stay put), 'POP'
  (go back one level, or confirm-exit if already at the root), 'EXIT'
  (confirm and quit), or a new Screen instance to push.
- F1 is intercepted globally to show the About/Help screen from anywhere.
- F5 is intercepted globally as "refresh" where a screen doesn't already
  use it for something else.
- Catches any unexpected exception from a screen's draw()/handle_key() and
  shows it in a plain error screen instead of crashing the whole terminal
  session back out to a raw traceback -- the same "must never crash the
  interactive session" principle used throughout agent/tui/screens.py.

How it interacts with other modules
------------------------------------
Called by tui4edge.py (standalone launcher) and by agent/agent.py's `tui`
CLI subcommand, both of which load the AgentConfig first and pass it in.
"""
from __future__ import annotations

import logging

from . import term_io
from .screens import MainMenuScreen, Screen
from .theme import Canvas
from .widgets import confirm

logger = logging.getLogger(__name__)


class TuiApp:
    def __init__(self, cfg):
        self.cfg = cfg
        self.stack = [MainMenuScreen(cfg)]
        self.running = True

    def _draw_current(self, canvas: Canvas) -> None:
        self.stack[-1].draw(canvas)

    def _confirm_exit(self) -> None:
        if confirm(self._draw_current, "Exit TUI4Edge", "Exit and return to your shell?"):
            self.running = False

    def run(self) -> None:
        with term_io.raw_terminal():
            while self.running:
                cols, rows = term_io.get_terminal_size()
                canvas = Canvas(cols, rows)
                try:
                    self._draw_current(canvas)
                except Exception as exc:  # noqa: BLE001
                    canvas = Canvas(cols, rows)
                    canvas.put(2, 2, f"Internal display error: {exc}")
                    canvas.put(2, 4, "Press ESC to go back.")
                term_io.write(canvas.render())

                key = term_io.read_key()
                if key is None:
                    continue
                self._dispatch(key)

    def _dispatch(self, key: str) -> None:
        if key == "F1":
            from .screens import AboutScreen
            if not isinstance(self.stack[-1], AboutScreen):
                self.stack.append(AboutScreen(self.cfg))
            return
        try:
            result = self.stack[-1].handle_key(key)
        except Exception as exc:  # noqa: BLE001
            logger.exception("Unhandled error in screen.handle_key")
            result = None
        if result == "POP":
            if len(self.stack) > 1:
                self.stack.pop()
            else:
                self._confirm_exit()
        elif result == "EXIT":
            self._confirm_exit()
        elif isinstance(result, Screen):
            self.stack.append(result)


def run_tui(cfg) -> None:
    TuiApp(cfg).run()
