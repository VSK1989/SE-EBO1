"""
agent/tui package -- TUI4Edge
===============================
A full-screen, keyboard-only, BIOS-style Text User Interface launcher for
the EBO Docker Agent: blue background, double-line borders, an
item-specific help panel (exactly like classic Award/AMI BIOS setup
screens), and a reverse-video key-legend bar at the bottom.

Why a BIOS look, specifically
-------------------------------
It's instantly recognisable, works identically over SSH/Remote-SSH/VS
Code's integrated terminal, needs no mouse, and -- just as importantly for
this project's zero-dependency philosophy -- it can be built entirely from
the Python standard library (ANSI escape codes + os.name-specific raw key
reading), with no curses/windows-curses/urwid/textual package required on
either Windows or Linux.

Modules
-------
- term_io.py  -- cross-platform raw terminal control: ANSI enable on
  Windows (via ctypes, no pip install), alternate-screen buffer, cursor
  hide/show, terminal size, and a single read_key() that returns the same
  symbolic names ('UP','DOWN','ENTER','ESC','F1', etc.) on both Windows
  (msvcrt) and POSIX (termios/tty + escape-sequence parsing).
- theme.py    -- the BIOS colour palette, box-drawing characters, and a
  Canvas class: a 2D grid of (char, fg, bg) cells that every widget draws
  into. Canvas is intentionally plain data (no direct terminal writes),
  which is what makes every widget's LAYOUT fully unit-testable without a
  real terminal (see tests/test_tui_*.py).
- widgets.py  -- reusable BIOS-style widgets: Menu (list + item-help
  panel), TabBar, ConfirmDialog (Y/N), TextInputDialog, ScrollableText,
  ToggleField (left/right cycles a value, exactly like a BIOS setting).
- screens.py  -- the actual application screens (Main, Servers, Server
  Detail, Network, Diagnostics, About), each wired to the real agent.*
  modules (config, discovery, container_manager, decision_engine,
  backup_tools, trace_tools, password_reset, graphdb_tools, log_collector).
- app.py      -- TuiApp: the screen stack + main event loop.

Entry points
------------
    python tui4edge.py            (standalone launcher at the project root)
    python run_agent.py tui        (same thing, via the existing CLI)

See docs/TUI4EDGE.md for the full screen map, key bindings, and ASCII
mock-ups of every screen.
"""
