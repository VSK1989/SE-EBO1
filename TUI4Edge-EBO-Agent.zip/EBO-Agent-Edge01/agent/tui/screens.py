r"""
agent/tui/screens.py
=======================
Purpose
-------
The actual TUI4Edge screens, each wired to the real agent.* modules --
this file is where the BIOS-style widgets meet the agent's genuine
functionality (discovery, container lifecycle, backups, trace logs,
password reset, GraphDB, diagnostics). Every action is wrapped so a Docker
error becomes a readable on-screen message, never a crash.

Screen map (see docs/TUI4EDGE.md for ASCII mock-ups of each)
-------------------------------------------------------------
    MainMenuScreen        -- top-level categories + live system summary
      -> ServersListScreen      -- configured servers + live status badges
           -> ServerDetailScreen -- per-server actions (start/stop/backup/...)
      -> NetworkScreen           -- network settings + strategy override
      -> DiagnosticsScreen       -- discover / validate / sync-ip / collect-logs
      -> AboutScreen             -- version, key legend, lineage note

How it interacts with other modules
------------------------------------
Each screen holds a reference to the shared AgentConfig (cfg) and calls
straight into agent.discovery / agent.container_manager / agent.backup_tools
/ agent.trace_tools / agent.password_reset / agent.graphdb_tools /
agent.decision_engine / agent.log_collector -- the exact same functions the
plain CLI (agent/agent.py) uses, so the TUI and the CLI are always
behaviourally identical; the TUI is purely an alternative front-end.

Configuration requirements
---------------------------
None beyond the already-loaded AgentConfig passed in at construction time.
"""
from __future__ import annotations

import logging
from typing import List, Optional

from .. import backup_tools as bt
from .. import container_manager as cm
from .. import decision_engine as de
from .. import discovery
from .. import graphdb_tools as gdt
from .. import log_collector as lc
from .. import password_reset as pr
from .. import platform_utils as pf
from .. import trace_tools as tt
from ..config import AgentConfig, ConfigError
from .theme import Canvas, TITLE_FG, DEFAULT_FG, DEFAULT_BG, OK_FG, WARN_FG, ERROR_FG
from .widgets import Menu, MenuItem, LegendBar, ToggleField, confirm, prompt_text, show_scrollable_text

logger = logging.getLogger(__name__)

APP_TITLE = "TUI4Edge -- EBO Docker Agent Setup Utility"


class Screen:
    """Base class. handle_key() returns: None (stay), 'POP' (go back), or a
    new Screen instance (push)."""

    title = "TUI4Edge"

    def __init__(self, cfg: AgentConfig):
        self.cfg = cfg

    def draw(self, canvas: Canvas) -> None:
        raise NotImplementedError

    def handle_key(self, key: str):
        raise NotImplementedError

    # Shared chrome -------------------------------------------------------
    def draw_title_bar(self, canvas: Canvas) -> None:
        canvas.box(0, 0, canvas.cols, 3, double=True)
        canvas.put_centered(1, APP_TITLE, TITLE_FG, DEFAULT_BG)

    def draw_legend(self, canvas: Canvas, hints: List[str]) -> None:
        LegendBar(hints).draw(canvas, canvas.rows - 1)


class AboutScreen(Screen):
    title = "About"

    def draw(self, canvas: Canvas) -> None:
        self.draw_title_bar(canvas)
        canvas.box(2, 4, canvas.cols - 4, canvas.rows - 7, title="About TUI4Edge")
        lines = [
            "TUI4Edge -- a BIOS-style launcher for the EBO Docker Agent.",
            "",
            "Companion to Bash4Edge (the Ubuntu/Linux shell toolkit) and the",
            "plain python run_agent.py CLI -- all three drive the exact same",
            "config/servers.yml and the same underlying agent.* modules.",
            "",
            f"Detected host OS:      {pf.detect_os()}",
            f"Network strategy:      {pf.network_strategy()}",
            f"Configuration file:    {self.cfg.path}",
            "",
            "Key bindings (global):",
            "  Up/Down      move selection     Enter   choose / confirm",
            "  Left/Right   change tabs/value  Esc     back / cancel",
            "  F1           this help screen   F5      refresh",
        ]
        for i, line in enumerate(lines):
            canvas.put(5, 6 + i, line, DEFAULT_FG, DEFAULT_BG)
        self.draw_legend(canvas, ["ESC: Back"])

    def handle_key(self, key: str):
        if key == "ESC":
            return "POP"
        return None


class ServerDetailScreen(Screen):
    def __init__(self, cfg: AgentConfig, server_name: str):
        super().__init__(cfg)
        self.server_name = server_name
        self.title = f"Server: {server_name}"
        self.menu = Menu([
            MenuItem("View Status", "Show the container's current state and the agent's health assessment."),
            MenuItem("Start", "Create (if needed) and start this container using the host-appropriate network strategy."),
            MenuItem("Stop", "Stop the running container (does not remove it)."),
            MenuItem("Restart", "Restart the container."),
            MenuItem("Remove", "Stop and remove the container. The database volume is kept unless you choose otherwise."),
            MenuItem("Upgrade", "Stop, prepare, and restart this server on a different image version."),
            MenuItem("Password Reset Mode", "Touch a marker file in the server's volume so it enters password-reset mode (no restart)."),
            MenuItem("List Backups", "List backup files currently stored inside the container."),
            MenuItem("Copy Backups", "Copy all backup files from the container to a folder on this host."),
            MenuItem("Restore Backup", "Restore a backup already in the container's backup folder."),
            MenuItem("Get Trace Logs", "Pull trace.log/trace.log.old directly from the server's database volume."),
            MenuItem("Collect Diagnostics Snapshot", "Save logs + inspect + health report + trace into the Downloads folder."),
            MenuItem("Back", "Return to the server list."),
        ])

    def draw(self, canvas: Canvas) -> None:
        self.draw_title_bar(canvas)
        self.menu.draw(canvas, 2, 4, canvas.cols - 4, canvas.rows - 7)
        self.draw_legend(canvas, ["\u2191\u2193: Move", "Enter: Select", "ESC: Back"])

    def _bg(self, canvas: Canvas) -> None:
        self.draw(canvas)

    def handle_key(self, key: str):
        if key == "UP":
            self.menu.move_up(); return None
        if key == "DOWN":
            self.menu.move_down(); return None
        if key == "ESC":
            return "POP"
        if key != "ENTER":
            return None

        label = self.menu.current().label
        try:
            if label == "Back":
                return "POP"
            if label == "View Status":
                status = cm.status(self.server_name, cfg=self.cfg)
                decision = de.evaluate(self.cfg, self.server_name)
                lines = [f"{k}: {v}" for k, v in status.items()] + ["", decision.summary()]
                show_scrollable_text(self._bg, "Status", lines)
            elif label == "Start":
                ok = cm.start(self.cfg, self.server_name)
                show_scrollable_text(self._bg, "Start", [f"Result: {'OK' if ok else 'FAILED'}"])
            elif label == "Stop":
                if confirm(self._bg, "Confirm", f"Stop {self.server_name}?"):
                    ok = cm.stop(self.server_name, cfg=self.cfg)
                    show_scrollable_text(self._bg, "Stop", [f"Result: {'OK' if ok else 'FAILED'}"])
            elif label == "Restart":
                if confirm(self._bg, "Confirm", f"Restart {self.server_name}?"):
                    ok = cm.restart(self.server_name, cfg=self.cfg)
                    show_scrollable_text(self._bg, "Restart", [f"Result: {'OK' if ok else 'FAILED'}"])
            elif label == "Remove":
                if confirm(self._bg, "WARNING", f"Remove {self.server_name}? The volume is kept."):
                    ok = cm.remove(self.server_name, cfg=self.cfg)
                    show_scrollable_text(self._bg, "Remove", [f"Result: {'OK' if ok else 'FAILED'}"])
            elif label == "Upgrade":
                version = prompt_text(self._bg, "Upgrade", "Enter the target version tag:")
                if version:
                    ok = cm.upgrade(self.cfg, self.server_name, version)
                    show_scrollable_text(self._bg, "Upgrade", [f"Result: {'OK' if ok else 'FAILED'}"])
            elif label == "Password Reset Mode":
                if confirm(self._bg, "Confirm", "Put this server into password reset mode? It will NOT be restarted."):
                    ok = pr.set_password_reset_mode(self.cfg, self.server_name)
                    show_scrollable_text(self._bg, "Password Reset", [f"Result: {'OK' if ok else 'FAILED'}"])
            elif label == "List Backups":
                files = bt.list_backups(self.cfg, self.server_name)
                show_scrollable_text(self._bg, "Backups", files or ["(no backups found)"])
            elif label == "Copy Backups":
                dest = prompt_text(self._bg, "Copy Backups", "Destination folder on this host:")
                if dest:
                    ok = bt.copy_backups(self.cfg, self.server_name, dest)
                    show_scrollable_text(self._bg, "Copy Backups", [f"Result: {'OK' if ok else 'FAILED'}"])
            elif label == "Restore Backup":
                backup = prompt_text(self._bg, "Restore Backup", "Backup filename (already in the container):")
                if backup:
                    all_data = confirm(self._bg, "Restore Mode", "Restore ALL DATA? (No = Configuration Only)")
                    mode = "AllData" if all_data else "ConfigurationOnly"
                    server = self.cfg.get_server(self.server_name)
                    ok = bt.restore_backup(self.cfg, self.server_name, server.version, backup, mode)
                    show_scrollable_text(self._bg, "Restore Backup", [f"Result: {'OK' if ok else 'FAILED'}"])
            elif label == "Get Trace Logs":
                dest = prompt_text(self._bg, "Get Trace Logs", "Destination folder on this host:")
                if dest:
                    found = tt.get_trace(self.cfg, self.server_name, dest)
                    show_scrollable_text(self._bg, "Trace Logs", found or ["(no trace files found)"])
            elif label == "Collect Diagnostics Snapshot":
                snap = lc.collect_one(self.cfg, self.server_name)
                show_scrollable_text(self._bg, "Diagnostics Snapshot", [str(snap) if snap else "FAILED"])
        except ConfigError as exc:
            show_scrollable_text(self._bg, "Error", [str(exc)])
        except Exception as exc:  # noqa: BLE001 -- the TUI must never crash on an action error
            show_scrollable_text(self._bg, "Unexpected Error", [str(exc)])
        return None


class ServersListScreen(Screen):
    title = "Servers"

    def __init__(self, cfg: AgentConfig):
        super().__init__(cfg)
        self.menu = Menu([])
        self._refresh()

    def _refresh(self) -> None:
        items = []
        try:
            results = discovery.discover_servers(self.cfg, force=True)
        except Exception:  # noqa: BLE001
            results = []
        by_name = {d.name: d for d in results}
        for name in self.cfg.list_server_names():
            d = by_name.get(name)
            if d is None:
                badge = "UNKNOWN"
            elif not d.exists:
                badge = "MISSING"
            elif d.running:
                badge = "RUNNING" + (" (IP DRIFT)" if d.ip_drifted else "")
            else:
                badge = "STOPPED"
            items.append(MenuItem(f"{name:<20} [{badge}]",
                                   f"Server '{name}'. Press Enter to view its action menu "
                                   f"(start/stop/backup/password-reset/trace logs/...)."))
        items.append(MenuItem("Refresh", "Re-check every server's existence/running state/IP (forces a fresh Docker query)."))
        items.append(MenuItem("Back", "Return to the Main Menu."))
        self.menu = Menu(items)

    def draw(self, canvas: Canvas) -> None:
        self.draw_title_bar(canvas)
        self.menu.draw(canvas, 2, 4, canvas.cols - 4, canvas.rows - 7)
        self.draw_legend(canvas, ["\u2191\u2193: Move", "Enter: Select", "F5: Refresh", "ESC: Back"])

    def handle_key(self, key: str):
        if key == "UP":
            self.menu.move_up(); return None
        if key == "DOWN":
            self.menu.move_down(); return None
        if key in ("ESC",):
            return "POP"
        if key == "F5":
            self._refresh(); return None
        if key != "ENTER":
            return None
        label = self.menu.current().label
        if label == "Back":
            return "POP"
        if label == "Refresh":
            self._refresh()
            return None
        server_name = label.split()[0]
        return ServerDetailScreen(self.cfg, server_name)


class NetworkScreen(Screen):
    title = "Network"

    def __init__(self, cfg: AgentConfig):
        super().__init__(cfg)
        forced = ((cfg.raw.get("agentSettings") or {}).get("network") or {}).get("force_strategy")
        options = ["Auto-detect", "ipvlan", "bridge_ports"]
        idx = options.index(forced) if forced in options else 0
        self.toggle = ToggleField("Network Strategy Override:", options, index=idx)
        self.field_selected = True  # only one field on this screen for now

    def draw(self, canvas: Canvas) -> None:
        self.draw_title_bar(canvas)
        net = self.cfg.network
        canvas.box(2, 4, canvas.cols - 4, canvas.rows - 7, title="Network Settings")
        lines = [
            f"Network name:        {net.get('name', '(none)')}",
            f"Type:                {net.get('type', '-')}",
            f"Subnet:              {net.get('subnet', '-')}",
            f"Gateway:             {net.get('gateway', '-')}",
            f"Interface:           {net.get('interface', '-')}",
            f"Auto-detected strategy for this host: {pf.network_strategy()}",
            "",
        ]
        for i, line in enumerate(lines):
            canvas.put(5, 6 + i, line, DEFAULT_FG, DEFAULT_BG)
        self.toggle.draw(canvas, 5, 6 + len(lines), canvas.cols - 10, selected=True)
        canvas.put(5, canvas.rows - 4,
                   "Enter: Detect Local Adapter   F10: Save Override to servers.yml",
                   DEFAULT_FG, DEFAULT_BG)
        self.draw_legend(canvas, ["\u2190\u2192: Change", "Enter: Detect Adapter", "F10: Save", "ESC: Back"])

    def _bg(self, canvas: Canvas) -> None:
        self.draw(canvas)

    def handle_key(self, key: str):
        if key == "LEFT":
            self.toggle.move_left(); return None
        if key == "RIGHT":
            self.toggle.move_right(); return None
        if key == "ESC":
            return "POP"
        if key == "ENTER":
            info = pf.get_local_adapter_info()
            lines = [f"interface: {info['interface']}", f"gateway:   {info['gateway']}",
                     f"subnet:    {info['subnet']}"]
            if info["error"]:
                lines.append(f"error: {info['error']}")
            show_scrollable_text(self._bg, "Detected Local Adapter", lines)
            return None
        if key == "F10":
            value = self.toggle.value()
            if value == "Auto-detect":
                show_scrollable_text(self._bg, "Save",
                                      ["Leaving 'force_strategy' unset -- the agent will keep auto-detecting per host."])
            else:
                from .. import yaml_mini
                ok = yaml_mini.update_scalar_in_file(self.cfg.path, "agentSettings.network.force_strategy", value)
                msg = "Saved." if ok else "Could not find that line in servers.yml -- add 'force_strategy:' under agentSettings.network manually."
                show_scrollable_text(self._bg, "Save", [msg])
            return None
        return None


class DiagnosticsScreen(Screen):
    title = "Diagnostics"

    def __init__(self, cfg: AgentConfig):
        super().__init__(cfg)
        self.menu = Menu([
            MenuItem("Discover", "Check every configured server's existence/running state/IP drift."),
            MenuItem("Validate Connectivity", "Discover, plus a live TCP reachability check on each running server."),
            MenuItem("Sync IP Drift", "Automatically correct any drifted IP addresses directly in servers.yml."),
            MenuItem("Collect All Logs", "Save a diagnostics snapshot for every configured server."),
            MenuItem("Back", "Return to the Main Menu."),
        ])

    def draw(self, canvas: Canvas) -> None:
        self.draw_title_bar(canvas)
        self.menu.draw(canvas, 2, 4, canvas.cols - 4, canvas.rows - 7)
        self.draw_legend(canvas, ["\u2191\u2193: Move", "Enter: Run", "ESC: Back"])

    def _bg(self, canvas: Canvas) -> None:
        self.draw(canvas)

    def handle_key(self, key: str):
        if key == "UP":
            self.menu.move_up(); return None
        if key == "DOWN":
            self.menu.move_down(); return None
        if key == "ESC":
            return "POP"
        if key != "ENTER":
            return None
        label = self.menu.current().label
        if label == "Back":
            return "POP"
        try:
            if label == "Discover":
                results = discovery.discover_servers(self.cfg, force=True)
                lines = [f"{d.name}: exists={d.exists} running={d.running} "
                         f"configured_ip={d.configured_ip} runtime_ip={d.runtime_ip} drift={d.ip_drifted}"
                         for d in results]
                show_scrollable_text(self._bg, "Discover", lines or ["(no servers configured)"])
            elif label == "Validate Connectivity":
                results = discovery.validate_all(self.cfg)
                lines = [f"{d.name}: {d.reachable_detail}" for d in results]
                show_scrollable_text(self._bg, "Validate Connectivity", lines or ["(no servers configured)"])
            elif label == "Sync IP Drift":
                messages = discovery.sync_ip_drift(self.cfg, auto_fix=True)
                show_scrollable_text(self._bg, "Sync IP Drift", messages or ["No IP drift detected."])
            elif label == "Collect All Logs":
                lc.collect_all(self.cfg)
                show_scrollable_text(self._bg, "Collect All Logs", ["Done -- see your Downloads folder."])
        except Exception as exc:  # noqa: BLE001
            show_scrollable_text(self._bg, "Unexpected Error", [str(exc)])
        return None


class MainMenuScreen(Screen):
    title = "Main"

    def __init__(self, cfg: AgentConfig):
        super().__init__(cfg)
        self.menu = Menu([
            MenuItem("Servers", "View and manage every container defined in servers.yml."),
            MenuItem("Network", "View network settings, override the strategy, or auto-detect your adapter."),
            MenuItem("Diagnostics", "Discover containers, validate connectivity, sync IP drift, collect logs."),
            MenuItem("About / Help", "Version info, key bindings, and where to find the full documentation."),
            MenuItem("Exit", "Leave TUI4Edge and return to your shell."),
        ])

    def draw(self, canvas: Canvas) -> None:
        self.draw_title_bar(canvas)
        canvas.box(2, 4, canvas.cols - 4, 6, title="System Summary")
        docker_ok = _docker_status_safe()
        canvas.put(5, 6, f"Host OS:          {pf.detect_os()}", DEFAULT_FG, DEFAULT_BG)
        canvas.put(5, 7, f"Network strategy: {pf.network_strategy()}", DEFAULT_FG, DEFAULT_BG)
        canvas.put(canvas.cols // 2, 6, f"Docker daemon:    {docker_ok}",
                   OK_FG if docker_ok == "available" else ERROR_FG, DEFAULT_BG)
        canvas.put(canvas.cols // 2, 7, f"Configured servers: {len(self.cfg.list_server_names())}", DEFAULT_FG, DEFAULT_BG)
        self.menu.draw(canvas, 2, 11, canvas.cols - 4, canvas.rows - 14)
        self.draw_legend(canvas, ["\u2191\u2193: Move", "Enter: Select", "F1: Help", "ESC: Exit"])

    def handle_key(self, key: str):
        if key == "UP":
            self.menu.move_up(); return None
        if key == "DOWN":
            self.menu.move_down(); return None
        if key != "ENTER":
            if key == "ESC":
                return "EXIT"
            return None
        label = self.menu.current().label
        if label == "Servers":
            return ServersListScreen(self.cfg)
        if label == "Network":
            return NetworkScreen(self.cfg)
        if label == "Diagnostics":
            return DiagnosticsScreen(self.cfg)
        if label == "About / Help":
            return AboutScreen(self.cfg)
        if label == "Exit":
            return "EXIT"
        return None


def _docker_status_safe() -> str:
    try:
        from .. import docker_tools as dt
        return "available" if dt.docker_available() else "NOT RESPONDING"
    except Exception:  # noqa: BLE001
        return "NOT RESPONDING"
