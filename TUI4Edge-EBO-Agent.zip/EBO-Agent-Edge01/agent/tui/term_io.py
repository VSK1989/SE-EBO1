r"""
agent/tui/term_io.py
=======================
Purpose
-------
The ONLY module in TUI4Edge that touches the real terminal: enabling ANSI
on Windows, entering/leaving the alternate screen buffer, hiding/showing
the cursor, measuring terminal size, and reading a single logical
keypress -- cross-platform, stdlib-only (no curses / windows-curses /
pyreadline / blessed / urwid / textual).

Why not curses?
-----------------
Python's `curses` module ships in the standard library on POSIX, but NOT
on Windows -- using it would mean either dropping Windows support or
requiring `pip install windows-curses`, which breaks this project's
"zero pip install, on either platform" principle (the same principle
behind yaml_mini.py avoiding PyYAML). Everything here is built from two
things every Python install already has: ANSI escape codes (which Windows
10+ consoles understand once "virtual terminal processing" is switched on
via a single `ctypes` call) and the platform's own low-level character
reader (`msvcrt.getch()` on Windows, raw-mode `os.read()` on POSIX).

Functionality
-------------
- enable_windows_ansi(): turns on ANSI escape-code interpretation in the
  Windows console host, via SetConsoleMode + ENABLE_VIRTUAL_TERMINAL_PROCESSING.
  A no-op (does nothing, raises nothing) on POSIX.
- raw_terminal(): a context manager that enters the alternate screen
  buffer, hides the cursor, and (on POSIX) switches stdin to cbreak mode
  so keys are read one at a time without waiting for Enter and without
  being echoed -- then guarantees everything is restored on exit, even if
  an exception propagates out of the TUI.
- get_terminal_size(): (cols, rows), clamped to a sane minimum of 80x24 so
  every screen's fixed-size BIOS layout always has room to draw.
- read_key(timeout=None): blocks (or waits up to `timeout` seconds) for
  one logical keypress and returns a short symbolic string: 'UP', 'DOWN',
  'LEFT', 'RIGHT', 'ENTER', 'ESC', 'TAB', 'BACKSPACE', 'F1'..'F10', or a
  single printable character. Returns None on timeout. Arrow/F-key escape
  sequences (which arrive as 3-6 raw bytes) are fully decoded here so
  every other TUI module only ever deals with these clean symbolic names.
- write(s) / clear_screen() / move_cursor(row, col): thin helpers used by
  theme.Canvas.render()'s caller.

How it interacts with other modules
------------------------------------
agent/tui/app.py calls raw_terminal() once around its whole event loop,
and read_key() once per loop iteration. agent/tui/theme.py's Canvas
produces the ANSI string that gets passed to write() -- this module never
builds screen content itself, only moves/measures/reads the real terminal.

Configuration requirements
---------------------------
None.
"""
from __future__ import annotations

import contextlib
import os
import select
import sys
import shutil
from typing import Optional

IS_WINDOWS = os.name == "nt"

if IS_WINDOWS:
    import msvcrt
else:
    import termios
    import tty


def enable_windows_ansi() -> None:
    """Turn on ANSI escape-code processing in the Windows console host.
    Safe to call on any platform; does nothing on POSIX."""
    if not IS_WINDOWS:
        return
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        STD_OUTPUT_HANDLE = -11
        ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
        handle = kernel32.GetStdHandle(STD_OUTPUT_HANDLE)
        mode = ctypes.c_uint32()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            kernel32.SetConsoleMode(handle, mode.value | ENABLE_VIRTUAL_TERMINAL_PROCESSING)
    except Exception:  # noqa: BLE001 -- best-effort; older consoles simply won't get colour
        pass


def get_terminal_size() -> tuple:
    size = shutil.get_terminal_size(fallback=(100, 32))
    return max(size.columns, 80), max(size.lines, 24)


def write(s: str) -> None:
    sys.stdout.write(s)
    sys.stdout.flush()


def clear_screen() -> str:
    return "\x1b[2J\x1b[H"


def move_cursor(row: int, col: int) -> str:
    return f"\x1b[{row};{col}H"


def hide_cursor() -> str:
    return "\x1b[?25l"


def show_cursor() -> str:
    return "\x1b[?25h"


def enter_alt_screen() -> str:
    return "\x1b[?1049h"


def leave_alt_screen() -> str:
    return "\x1b[?1049l"


@contextlib.contextmanager
def raw_terminal():
    """Context manager: alternate screen + hidden cursor + (POSIX) cbreak
    input mode, guaranteed to be restored on exit."""
    enable_windows_ansi()
    write(enter_alt_screen() + hide_cursor())
    old_attrs = None
    if not IS_WINDOWS:
        fd = sys.stdin.fileno()
        old_attrs = termios.tcgetattr(fd)
        tty.setcbreak(fd)
    try:
        yield
    finally:
        if not IS_WINDOWS and old_attrs is not None:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old_attrs)
        write(show_cursor() + leave_alt_screen())


# --- key decoding -------------------------------------------------------

# POSIX CSI (\x1b[ ...) final-byte -> symbolic name, for simple arrow/home/end keys.
_CSI_SIMPLE = {"A": "UP", "B": "DOWN", "C": "RIGHT", "D": "LEFT", "H": "HOME", "F": "END"}

# POSIX CSI numeric-parameter sequences (\x1b[<n>~) -> symbolic name.
_CSI_TILDE = {
    "1": "HOME", "3": "DELETE", "4": "END", "5": "PGUP", "6": "PGDN",
    "15": "F5", "17": "F6", "18": "F7", "19": "F8", "20": "F9", "21": "F10",
}

# POSIX SS3 (\x1bO ...) -- F1..F4 on many terminals.
_SS3 = {"P": "F1", "Q": "F2", "R": "F3", "S": "F4"}

# Windows msvcrt second-byte (after a b'\x00'/b'\xe0' prefix) -> symbolic name.
_WIN_EXTENDED = {
    "H": "UP", "P": "DOWN", "K": "LEFT", "M": "RIGHT",
    "G": "HOME", "O": "END", "I": "PGUP", "Q": "PGDN", "S": "DELETE",
    ";": "F1", "<": "F2", "=": "F3", ">": "F4", "?": "F5", "@": "F6",
    "A": "F7", "B": "F8", "C": "F9", "D": "F10",
}


def _posix_read_key(timeout: Optional[float]) -> Optional[str]:
    fd = sys.stdin.fileno()
    ready, _w, _x = select.select([fd], [], [], timeout)
    if not ready:
        return None
    ch = os.read(fd, 1).decode("latin-1")

    if ch == "\x1b":
        # Could be a lone ESC, or the start of a CSI/SS3 escape sequence.
        # Peek briefly for the next byte; real escape sequences arrive
        # as one burst from the terminal, so a short timeout reliably
        # tells a lone ESC apart from e.g. an arrow key's '\x1b[A'.
        ready2, _w2, _x2 = select.select([fd], [], [], 0.02)
        if not ready2:
            return "ESC"
        ch2 = os.read(fd, 1).decode("latin-1")
        if ch2 == "[":
            seq = ""
            while True:
                ready3, _w3, _x3 = select.select([fd], [], [], 0.02)
                if not ready3:
                    break
                c = os.read(fd, 1).decode("latin-1")
                seq += c
                if c.isalpha() or c == "~":
                    break
            if seq.endswith("~"):
                return _CSI_TILDE.get(seq[:-1], "UNKNOWN")
            if seq and seq[-1] in _CSI_SIMPLE:
                return _CSI_SIMPLE[seq[-1]]
            return "UNKNOWN"
        if ch2 == "O":
            ready3, _w3, _x3 = select.select([fd], [], [], 0.02)
            if ready3:
                c = os.read(fd, 1).decode("latin-1")
                return _SS3.get(c, "UNKNOWN")
            return "UNKNOWN"
        return "ESC"

    if ch in ("\r", "\n"):
        return "ENTER"
    if ch == "\t":
        return "TAB"
    if ch in ("\x7f", "\x08"):
        return "BACKSPACE"
    if ch == "\x03":
        return "ESC"  # Ctrl+C mapped to ESC's meaning (no SIGINT in cbreak raw-ish mode)
    return ch


def _windows_read_key(timeout: Optional[float]) -> Optional[str]:
    import time
    start = time.monotonic()
    while True:
        if msvcrt.kbhit():
            ch = msvcrt.getch()
            if ch in (b"\x00", b"\xe0"):
                ch2 = msvcrt.getch().decode("latin-1", errors="ignore")
                return _WIN_EXTENDED.get(ch2, "UNKNOWN")
            if ch == b"\r":
                return "ENTER"
            if ch == b"\t":
                return "TAB"
            if ch in (b"\x08", b"\x7f"):
                return "BACKSPACE"
            if ch == b"\x1b":
                return "ESC"
            if ch == b"\x03":
                return "ESC"
            return ch.decode("latin-1", errors="ignore")
        if timeout is not None and (time.monotonic() - start) >= timeout:
            return None
        time.sleep(0.01)


def read_key(timeout: Optional[float] = None) -> Optional[str]:
    """Block (or wait up to `timeout` seconds) for one logical keypress."""
    return _windows_read_key(timeout) if IS_WINDOWS else _posix_read_key(timeout)
