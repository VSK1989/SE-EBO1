"""
agent/tui/theme.py
=====================
Purpose
-------
The BIOS colour palette, box-drawing characters, and the `Canvas` class:
a plain 2D grid of (character, foreground, background) cells that every
widget draws into. Canvas never touches the real terminal -- it only
produces a final ANSI string via render(). This separation is what makes
every widget's layout logic fully unit-testable (tests/test_tui_*.py
instantiate a Canvas, draw into it, and assert on canvas.grid directly,
with no real terminal needed).

The palette
-----------
Classic Award/AMI BIOS setup screens: solid blue background, light-grey/
white body text, bold yellow for titles and the currently-selected field
label, and a reverse "white-bar, black-text" highlight for the selected
menu row -- plus a light-grey/black "key legend" bar pinned to the very
bottom of the screen, exactly like the real thing's
"↑↓:Move  Enter:Select  F10:Save  ESC:Exit" footer.

Functionality
-------------
- Canvas(cols, rows): a blank blue-background grid.
- Canvas.put(x, y, text, fg, bg): write a run of text at a position.
- Canvas.hline / vline / box / fill_rect: drawing primitives.
- Canvas.render(): returns one ANSI string painting the ENTIRE terminal in
  a single write (cursor-home once, then row by row), merging consecutive
  same-style cells into one escape-code run to keep output compact.

How it interacts with other modules
------------------------------------
agent/tui/widgets.py and agent/tui/screens.py only ever call Canvas
methods -- never emit raw ANSI themselves. agent/tui/app.py calls
canvas.render() once per frame and hands the result to term_io.write().
"""
from __future__ import annotations

from typing import List, Optional, Tuple

RESET = "\x1b[0m"

# Foreground / background colour codes (basic 16-colour ANSI -- chosen over
# 256-colour/truecolour codes specifically for maximum compatibility with
# older Windows consoles and minimal-featured terminals).
BG_BLUE = 44
FG_WHITE = 37
FG_BOLD_WHITE = 97
FG_YELLOW = 33
FG_BOLD_YELLOW = 93
FG_CYAN = 36
FG_RED = 91
FG_GREEN = 92
FG_BLACK = 30
BG_WHITE = 47
BG_GREY = 47
BG_RED = 41
BG_GREEN = 42

DEFAULT_FG = FG_WHITE
DEFAULT_BG = BG_BLUE
TITLE_FG = FG_BOLD_YELLOW
SELECTED_FG = FG_BLACK
SELECTED_BG = BG_WHITE
HELP_FG = FG_CYAN
LEGEND_FG = FG_BLACK
LEGEND_BG = BG_GREY
ERROR_FG = FG_RED
OK_FG = FG_GREEN
WARN_FG = FG_BOLD_YELLOW

# Double-line box-drawing (outer frame) and single-line (inner panels) --
# the mix of double+single borders is itself a classic BIOS visual cue.
DBL_TL, DBL_TR, DBL_BL, DBL_BR, DBL_H, DBL_V = "\u2554", "\u2557", "\u255a", "\u255d", "\u2550", "\u2551"
SGL_TL, SGL_TR, SGL_BL, SGL_BR, SGL_H, SGL_V = "\u250c", "\u2510", "\u2514", "\u2518", "\u2500", "\u2502"


def _style(fg: int, bg: int) -> str:
    return f"\x1b[{fg};{bg}m"


class Canvas:
    """A cols x rows grid of (char, fg, bg) cells."""

    def __init__(self, cols: int, rows: int, fg: int = DEFAULT_FG, bg: int = DEFAULT_BG):
        self.cols = cols
        self.rows = rows
        self.default_fg = fg
        self.default_bg = bg
        self.grid: List[List[Tuple[str, int, int]]] = [
            [(" ", fg, bg) for _ in range(cols)] for _ in range(rows)
        ]

    def put(self, x: int, y: int, text: str, fg: Optional[int] = None, bg: Optional[int] = None) -> None:
        if y < 0 or y >= self.rows:
            return
        fg = self.default_fg if fg is None else fg
        bg = self.default_bg if bg is None else bg
        for i, ch in enumerate(text):
            xi = x + i
            if 0 <= xi < self.cols:
                self.grid[y][xi] = (ch, fg, bg)

    def put_centered(self, y: int, text: str, fg: Optional[int] = None, bg: Optional[int] = None,
                      x0: int = 0, width: Optional[int] = None) -> None:
        width = self.cols if width is None else width
        x = x0 + max(0, (width - len(text)) // 2)
        self.put(x, y, text, fg, bg)

    def fill_rect(self, x: int, y: int, w: int, h: int, fg: Optional[int] = None, bg: Optional[int] = None) -> None:
        for yy in range(y, y + h):
            self.put(x, yy, " " * w, fg, bg)

    def hline(self, x: int, y: int, w: int, ch: str = SGL_H, fg: Optional[int] = None, bg: Optional[int] = None) -> None:
        self.put(x, y, ch * w, fg, bg)

    def vline(self, x: int, y: int, h: int, ch: str = SGL_V, fg: Optional[int] = None, bg: Optional[int] = None) -> None:
        for yy in range(y, y + h):
            self.put(x, yy, ch, fg, bg)

    def box(self, x: int, y: int, w: int, h: int, double: bool = False,
            title: Optional[str] = None, fg: Optional[int] = None, bg: Optional[int] = None) -> None:
        tl, tr, bl, br, hch, vch = (DBL_TL, DBL_TR, DBL_BL, DBL_BR, DBL_H, DBL_V) if double else \
                                    (SGL_TL, SGL_TR, SGL_BL, SGL_BR, SGL_H, SGL_V)
        self.put(x, y, tl + hch * (w - 2) + tr, fg, bg)
        self.put(x, y + h - 1, bl + hch * (w - 2) + br, fg, bg)
        for yy in range(y + 1, y + h - 1):
            self.put(x, yy, vch, fg, bg)
            self.put(x + w - 1, yy, vch, fg, bg)
        if title:
            label = f" {title} "
            self.put(x + max(2, (w - len(label)) // 2), y, label, fg, bg)

    def render(self) -> str:
        out = [f"\x1b[1;1H"]
        for row in self.grid:
            out.append(_render_row(row))
            out.append("\r\n")
        out.append(RESET)
        return "".join(out)


def _render_row(row: List[Tuple[str, int, int]]) -> str:
    parts = []
    cur_fg, cur_bg = None, None
    buf = []
    for ch, fg, bg in row:
        if fg != cur_fg or bg != cur_bg:
            if buf:
                parts.append("".join(buf))
            parts.append(_style(fg, bg))
            cur_fg, cur_bg = fg, bg
            buf = [ch]
        else:
            buf.append(ch)
    if buf:
        parts.append("".join(buf))
    parts.append(RESET)
    return "".join(parts)
