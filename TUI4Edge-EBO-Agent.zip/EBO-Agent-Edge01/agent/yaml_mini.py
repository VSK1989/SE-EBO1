"""
agent/yaml_mini.py
=====================
Purpose
-------
A tiny, dependency-free parser for the specific YAML subset used by
servers.yml (nested block mappings, scalars, comments, Yes/No booleans,
null scalars) -- so the agent (and TUI4Edge) can read the real
servers.yml directly without adding a PyYAML dependency.

Functionality
-------------
- parse_yaml(text) -> dict
- load_yaml_file(path) -> dict
- update_scalar_in_file(path, "a.b.c", new_value) -- surgical single-line
  edit, preserving every other line/comment byte-for-byte.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple


class YamlMiniError(Exception):
    pass


_BOOL_TRUE = {"yes", "true", "on"}
_BOOL_FALSE = {"no", "false", "off"}
_UNSUPPORTED_MARKERS = ("---", "...", "&", "*", "<<", "!!")


def _strip_comment(line: str) -> str:
    out = []
    for i, ch in enumerate(line):
        if ch == "#" and (i == 0 or line[i - 1].isspace()):
            break
        out.append(ch)
    return "".join(out).rstrip()


def _coerce_scalar(raw: str) -> Any:
    raw = raw.strip()
    if raw == "":
        return None
    if (raw.startswith('"') and raw.endswith('"') and len(raw) >= 2) or (
        raw.startswith("'") and raw.endswith("'") and len(raw) >= 2
    ):
        return raw[1:-1]
    low = raw.lower()
    if low in _BOOL_TRUE:
        return True
    if low in _BOOL_FALSE:
        return False
    if low in ("null", "~"):
        return None
    if re.fullmatch(r"-?\d+", raw):
        return int(raw)
    if re.fullmatch(r"-?\d+\.\d+", raw):
        return float(raw)
    return raw


def _indent_of(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def parse_yaml(text: str) -> Dict[str, Any]:
    raw_lines = text.replace("\r\n", "\n").split("\n")
    lines: List[Tuple[int, str]] = []
    for line in raw_lines:
        if line.lstrip(" ").startswith("#"):
            continue
        content = _strip_comment(line)
        if content.strip() == "":
            continue
        for marker in _UNSUPPORTED_MARKERS:
            if marker in content:
                raise YamlMiniError(f"Unsupported YAML feature '{marker}' in: {line!r}")
        if "\t" in line:
            raise YamlMiniError(f"Tabs not supported: {line!r}")
        lines.append((_indent_of(line), content.strip()))

    root: Dict[str, Any] = {}
    stack: List[Tuple[int, Dict[str, Any]]] = [(-1, root)]
    for indent, content in lines:
        if ":" not in content:
            raise YamlMiniError(f"Expected 'key: value': {content!r}")
        key, _, value_part = content.partition(":")
        key = key.strip()
        value_raw = value_part.strip()
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if value_raw == "":
            new_dict: Dict[str, Any] = {}
            parent[key] = new_dict
            stack.append((indent, new_dict))
        else:
            parent[key] = _coerce_scalar(value_raw)

    def _collapse_empty_dicts(node):
        if isinstance(node, dict):
            if not node:
                return None
            return {k: _collapse_empty_dicts(v) for k, v in node.items()}
        return node

    return _collapse_empty_dicts(root)


def load_yaml_file(path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        return parse_yaml(fh.read())


def update_scalar_in_file(path, key_path: str, new_value: str) -> bool:
    segments = key_path.split(".")
    with open(path, "r", encoding="utf-8") as fh:
        original_lines = fh.read().replace("\r\n", "\n").split("\n")

    search_index = 0
    expected_indent_stack: List[int] = []
    target_line_no = None

    for line_no, line in enumerate(original_lines):
        if line.lstrip(" ").startswith("#") or line.strip() == "":
            continue
        content = _strip_comment(line)
        if content.strip() == "" or ":" not in content:
            continue
        indent = _indent_of(line)
        key, _, _ = content.partition(":")
        key = key.strip()
        while expected_indent_stack and indent <= expected_indent_stack[-1]:
            expected_indent_stack.pop()
            search_index -= 1
        if search_index < len(segments) and key == segments[search_index]:
            if search_index == len(segments) - 1:
                target_line_no = line_no
                break
            expected_indent_stack.append(indent)
            search_index += 1

    if target_line_no is None:
        return False

    line = original_lines[target_line_no]
    m = re.match(r"^(\s*[^:#]+:\s*)([^#]*)(#.*)?$", line)
    if not m:
        return False
    prefix, _old_value, comment = m.group(1), m.group(2), m.group(3) or ""
    new_line = f"{prefix}{new_value}"
    if comment:
        new_line = f"{new_line} {comment}" if not new_line.endswith(" ") else f"{new_line}{comment}"
    original_lines[target_line_no] = new_line

    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(original_lines))
    return True
