r"""
agent/docker_tools.py
=======================
Purpose
-------
The ONLY module that calls the `docker` CLI directly. Ported from
start.py's list-based, validated subprocess pattern (teststart.py's
unvalidated shell-string pattern was reviewed and rejected). Whitelist
widened by exactly two characters (comma, backslash) for no_proxy lists
and Windows bind-mount paths -- see docs/SOURCE_FILES_REVIEW.md.
"""
from __future__ import annotations

import json
import logging
import re
import subprocess
import time
from typing import List, Optional, Tuple

from . import platform_utils as pf

logger = logging.getLogger(__name__)

_TOKEN_RE = re.compile(r"^[A-Za-z0-9._:/@=,\\\-]+$")


class DockerError(Exception):
    pass


def validate_token(value: Optional[str], field_name: str) -> Optional[str]:
    if value is None or value == "":
        return value
    if not _TOKEN_RE.fullmatch(value):
        raise ValueError(f"Invalid characters in {field_name}: {value!r}")
    return value


_TRANSIENT_MARKERS = (
    "error during connect", "cannot connect to the docker daemon",
    "the system cannot find the file specified", "timeout",
)


def exe(cmd: List[str], dry_run: bool = False, check: bool = False,
        retries: int = 0, retry_delay: float = 1.0) -> Tuple[int, str, str]:
    printable = " ".join(cmd)
    if dry_run:
        logger.info("[DRY-RUN] %s", printable)
        return 0, "", ""
    attempt = 0
    while True:
        logger.debug("Running: %s", printable)
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        except FileNotFoundError as exc:
            raise DockerError("Could not execute 'docker'. Is it installed and on PATH?") from exc
        if result.returncode == 0:
            return result.returncode, result.stdout.strip(), result.stderr.strip()
        is_transient = any(m in result.stderr.lower() for m in _TRANSIENT_MARKERS)
        if is_transient and attempt < retries:
            attempt += 1
            logger.warning("Transient Docker error (attempt %d/%d), retrying: %s",
                            attempt, retries, result.stderr.strip()[:200])
            time.sleep(retry_delay)
            continue
        if check:
            raise DockerError(f"Command failed ({result.returncode}): {printable}\n{result.stderr.strip()}")
        return result.returncode, result.stdout.strip(), result.stderr.strip()


def docker_available(dry_run: bool = False) -> bool:
    try:
        rc, _o, _e = exe(["docker", "version", "--format", "{{.Server.Version}}"], dry_run=dry_run)
    except DockerError:
        return False
    return rc == 0


def container_exists(name: str, dry_run: bool = False) -> bool:
    validate_token(name, "container name")
    rc, out, _e = exe(["docker", "ps", "-a", "--format", "{{.Names}}"], dry_run=dry_run)
    if dry_run:
        return False
    return name in out.splitlines()


def inspect_container(name: str, dry_run: bool = False) -> Optional[dict]:
    validate_token(name, "container name")
    rc, out, _e = exe(["docker", "inspect", name], dry_run=dry_run)
    if dry_run or rc != 0 or not out:
        return None
    try:
        data = json.loads(out)
        return data[0] if data else None
    except (json.JSONDecodeError, IndexError):
        return None


def is_running(name: str, dry_run: bool = False) -> bool:
    info = inspect_container(name, dry_run=dry_run)
    return bool(info and info.get("State", {}).get("Running", False))


def get_logs(name: str, tail: int = 500, dry_run: bool = False) -> str:
    validate_token(name, "container name")
    rc, out, err = exe(["docker", "logs", "--tail", str(int(tail)), name], dry_run=dry_run)
    if dry_run:
        return "[DRY-RUN] no logs retrieved"
    return out if rc == 0 else f"<error retrieving logs: {err}>"


def stop_container(name, dry_run=False): validate_token(name, "name"); return exe(["docker", "stop", name], dry_run=dry_run)
def start_existing_container(name, dry_run=False): validate_token(name, "name"); return exe(["docker", "start", name], dry_run=dry_run)
def restart_container(name, dry_run=False): validate_token(name, "name"); return exe(["docker", "restart", name], dry_run=dry_run)


def remove_container(name: str, force: bool = False, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "name")
    cmd = ["docker", "rm"]
    if force:
        cmd.append("-f")
    cmd.append(name)
    return exe(cmd, dry_run=dry_run)


def run_container(cmd: List[str], dry_run: bool = False) -> Tuple[int, str, str]:
    return exe(cmd, dry_run=dry_run, retries=2)


def docker_exec(name: str, args: List[str], dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "name")
    for a in args:
        validate_token(a, "exec argument")
    return exe(["docker", "exec", name] + args, dry_run=dry_run)


def copy_from_container(name: str, container_path: str, host_path: str, dry_run: bool = False):
    validate_token(name, "name")
    host_path = pf.normalize_bind_source(host_path)
    return exe(["docker", "cp", f"{name}:{container_path}", host_path], dry_run=dry_run)


def copy_to_container(host_path: str, name: str, container_path: str, dry_run: bool = False):
    validate_token(name, "name")
    host_path = pf.normalize_bind_source(host_path)
    return exe(["docker", "cp", host_path, f"{name}:{container_path}"], dry_run=dry_run)


def run_ephemeral_against_volume(image, volume, volume_target, bind_source, bind_target,
                                  shell_command, dry_run=False):
    validate_token(image, "image"); validate_token(volume, "volume"); validate_token(volume_target, "volume_target")
    cmd = ["docker", "run", "--rm"]
    if bind_source and bind_target:
        bind_source = pf.normalize_bind_source(bind_source)
        validate_token(bind_source, "bind_source"); validate_token(bind_target, "bind_target")
        cmd += ["--mount", f"type=bind,source={bind_source},target={bind_target}"]
    cmd += ["--mount", f"source={volume},target={volume_target}", image, "bash", "-c", shell_command]
    return exe(cmd, dry_run=dry_run)


def network_exists(name: str, dry_run: bool = False) -> bool:
    validate_token(name, "network name")
    rc, out, _e = exe(["docker", "network", "ls", "--format", "{{.Name}}"], dry_run=dry_run)
    return True if dry_run else name in out.splitlines()


def create_ipvlan_network(name, subnet, gateway, parent_interface, dry_run=False):
    for v, f in ((name, "name"), (subnet, "subnet"), (gateway, "gateway"), (parent_interface, "iface")):
        validate_token(v, f)
    cmd = ["docker", "network", "create", "-d", "ipvlan", "--subnet", subnet,
           "--gateway", gateway, "-o", f"parent={parent_interface}", name]
    return exe(cmd, dry_run=dry_run)


def create_bridge_network(name: str, dry_run: bool = False):
    validate_token(name, "network name")
    return exe(["docker", "network", "create", name], dry_run=dry_run)


def pull_image(image: str, dry_run: bool = False):
    validate_token(image, "image")
    return exe(["docker", "pull", image], dry_run=dry_run, retries=1, retry_delay=2.0)
