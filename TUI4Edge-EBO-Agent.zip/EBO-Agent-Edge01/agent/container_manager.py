r"""
agent/container_manager.py
============================
Purpose
-------
Container lifecycle (start/stop/restart/upgrade/status/remove), with
OS-aware network strategy (ipvlan on Linux/WSL, bridge_ports with
published ports on native Windows), and resolve_target() so every command
accepts a server's configured NAME or its IP ADDRESS.
"""
from __future__ import annotations

import logging
import os
import re
from typing import List, Optional

from . import discovery
from . import docker_tools as dt
from . import platform_utils as pf
from .config import AgentConfig, ConfigError, ServerConfig

logger = logging.getLogger(__name__)
TEST_MODE_PORTS = {"80": "1080", "443": "1443", "4444": "14444"}


def _is_legacy_ca_folder_version(version: str) -> bool:
    match = re.match(r"^\s*(\d+)", version or "")
    return bool(match) and int(match.group(1)) < 8


def resolve_target(cfg: AgentConfig, name_or_ip: str) -> ServerConfig:
    if name_or_ip in cfg.list_server_names():
        return cfg.get_server(name_or_ip)
    for name in cfg.list_server_names():
        server = cfg.get_server(name)
        if server.ip == name_or_ip or discovery.get_runtime_ip(name) == name_or_ip:
            return server
    raise ConfigError(f"'{name_or_ip}' does not match any configured server's name or IP. "
                       f"Configured: {cfg.list_server_names()}")


def build_run_command(cfg: AgentConfig, server: ServerConfig, test_mode: bool = False) -> List[str]:
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"
    defaults = cfg.defaults
    db_folder = defaults.get("db_folder", "/var/sbo")
    db_vol = f"{server.name}{defaults.get('db_vol_suffix', '-db')}"
    forced = ((cfg.raw.get("agentSettings") or {}).get("network") or {}).get("force_strategy")
    strategy = "bridge_ports" if test_mode else pf.network_strategy(forced)

    for value, fname in ((server.name, "name"), (server.version, "version"), (server.ip, "ip"),
                         (server.type, "type"), (server.accept_eula, "accept_eula"),
                         (server.graphdb, "graphdb"), (server.dns, "dns")):
        dt.validate_token(value, fname)

    cmd = ["docker", "run", "-d", f"--name={server.name}", "-h", server.name,
           "--ulimit", "core=-1", "--restart", "always", "--network", server.network,
           "-e", f"NSP_ACCEPT_EULA={server.accept_eula}", "-e", f"Semantic_Db_URL={server.graphdb}"]

    for cfg_value, lower_env, upper_env in ((server.http_proxy, "http_proxy", "HTTP_PROXY"),
                                             (server.https_proxy, "https_proxy", "HTTPS_PROXY"),
                                             (server.no_proxy, "no_proxy", "NO_PROXY")):
        if cfg_value:
            dt.validate_token(cfg_value, lower_env)
            cmd += ["-e", f"{lower_env}={cfg_value}"]
        else:
            if lower_env in os.environ:
                cmd += ["-e", f"{lower_env}={os.environ[lower_env]}"]
            if upper_env in os.environ:
                cmd += ["-e", f"{upper_env}={os.environ[upper_env]}"]

    if strategy == "ipvlan":
        cmd += ["--ip", server.ip]
    else:
        for cport, hport in TEST_MODE_PORTS.items():
            cmd += ["-p", f"{hport}:{cport}"]

    cmd += ["--mount", f"source={db_vol},target={db_folder}"]

    legacy = _is_legacy_ca_folder_version(server.version)
    if legacy and server.ca_folder:
        cf = pf.normalize_bind_source(server.ca_folder)
        cmd += ["--mount", f"type=bind,source={cf},target=/usr/local/share/ca-certificates"]
    if not legacy and server.ca_bundle:
        cb = pf.normalize_bind_source(server.ca_bundle)
        cmd += ["--mount", f"type=bind,source={cb},target=/opt/sbo/etc/ca-bundle.crt,readonly"]

    crash_folder = pf.normalize_bind_source(defaults.get("crash_folder", "/var/crash"))
    if os.path.exists(crash_folder):
        cmd += ["--mount", f"type=bind,source={crash_folder},target=/var/crash"]

    if server.dns:
        cmd += ["--dns", server.dns]

    cmd.append(image)
    return cmd


def ensure_network(cfg: AgentConfig, test_mode: bool = False, dry_run: bool = False) -> None:
    net = cfg.network
    name = net.get("name", "bridged-net")
    forced = ((cfg.raw.get("agentSettings") or {}).get("network") or {}).get("force_strategy")
    strategy = "bridge_ports" if test_mode else pf.network_strategy(forced)
    if dt.network_exists(name, dry_run=dry_run):
        logger.info("Docker network '%s' already exists.", name)
        return
    if strategy == "ipvlan":
        rc, _o, err = dt.create_ipvlan_network(name, net.get("subnet", "192.168.10.0/24"),
                                                net.get("gateway", "192.168.10.254"),
                                                net.get("interface", "eth0"), dry_run=dry_run)
    else:
        rc, _o, err = dt.create_bridge_network(name, dry_run=dry_run)
    logger.info("Network '%s' %s.", name, "created" if rc == 0 else f"FAILED: {err}")


def start(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False, test_mode: bool = False) -> bool:
    server = resolve_target(cfg, name_or_ip)
    name = server.name
    if discovery.container_exists_cached(name, dry_run=dry_run):
        if dt.is_running(name, dry_run=dry_run):
            logger.info("Container '%s' is already running.", name)
            return True
        rc, _o, err = dt.start_existing_container(name, dry_run=dry_run)
        discovery.clear_cache()
        if rc != 0:
            logger.error("Failed to start '%s': %s", name, err)
            return False
        logger.info("Container '%s' started.", name)
        return True
    ensure_network(cfg, test_mode=test_mode, dry_run=dry_run)
    cmd = build_run_command(cfg, server, test_mode=test_mode)
    rc, out, err = dt.run_container(cmd, dry_run=dry_run)
    discovery.clear_cache()
    if rc != 0:
        logger.error("Failed to start '%s': %s", name, err)
        return False
    logger.info("Container '%s' created and started.", name)
    return True


def stop(name_or_ip, cfg=None, dry_run=False):
    name = resolve_target(cfg, name_or_ip).name if cfg else name_or_ip
    rc, _o, err = dt.stop_container(name, dry_run=dry_run)
    discovery.clear_cache()
    if rc != 0:
        logger.error("Failed to stop '%s': %s", name, err); return False
    logger.info("Container '%s' stopped.", name); return True


def restart(name_or_ip, cfg=None, dry_run=False):
    name = resolve_target(cfg, name_or_ip).name if cfg else name_or_ip
    rc, _o, err = dt.restart_container(name, dry_run=dry_run)
    discovery.clear_cache()
    if rc != 0:
        logger.error("Failed to restart '%s': %s", name, err); return False
    logger.info("Container '%s' restarted.", name); return True


def remove(name_or_ip, cfg=None, force=False, dry_run=False):
    name = resolve_target(cfg, name_or_ip).name if cfg else name_or_ip
    rc, _o, err = dt.remove_container(name, force=force, dry_run=dry_run)
    discovery.clear_cache()
    if rc != 0:
        logger.error("Failed to remove '%s': %s", name, err); return False
    logger.info("Container '%s' removed.", name); return True


def status(name_or_ip: str, cfg: Optional[AgentConfig] = None, dry_run: bool = False) -> dict:
    name = resolve_target(cfg, name_or_ip).name if cfg else name_or_ip
    if not discovery.container_exists_cached(name, dry_run=dry_run):
        return {"name": name, "exists": False}
    info = dt.inspect_container(name, dry_run=dry_run) or {}
    state = info.get("State", {})
    return {"name": name, "exists": True, "running": state.get("Running", False),
            "status": state.get("Status", "unknown"), "restart_count": info.get("RestartCount", 0),
            "started_at": state.get("StartedAt", ""), "image": info.get("Config", {}).get("Image", ""),
            "ip": info.get("NetworkSettings", {}).get("Networks", {})}


def upgrade(cfg: AgentConfig, name_or_ip: str, new_version: str, dry_run: bool = False) -> bool:
    server = resolve_target(cfg, name_or_ip)
    name = server.name
    info = dt.inspect_container(name, dry_run=dry_run)
    if not info and not dry_run:
        logger.error("Cannot upgrade '%s': does not exist.", name)
        return False
    old_image = info.get("Config", {}).get("Image", "") if info else "unknown:unknown"
    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")
    dt.stop_container(name, dry_run=dry_run)
    dt.remove_container(name, dry_run=dry_run)
    if old_image and old_image != "unknown:unknown":
        dt.exe(["docker", "run", "--rm", "--mount", f"source={db_vol},target={db_folder}",
                old_image, "/opt/sbo/bin/prepare-upgrade"], dry_run=dry_run)
    server.version = new_version
    cmd = build_run_command(cfg, server)
    rc, _o, err = dt.run_container(cmd, dry_run=dry_run)
    discovery.clear_cache()
    if rc != 0:
        logger.error("Failed to start upgraded '%s': %s", name, err)
        return False
    logger.info("Container '%s' upgraded to '%s'.", name, new_version)
    return True
