#!/usr/bin/env python3
r"""
tui4edge.py
=============
Purpose
-------
Standalone launcher for TUI4Edge -- the BIOS-style, full-screen Text User
Interface for the EBO Docker Agent. This is the single file you run
directly in VS Code's integrated terminal (or any terminal: Windows
Terminal, cmd.exe with VT100 support, a Remote-SSH session into Ubuntu,
etc.) to get the arrow-key-navigable menu system instead of typing CLI
flags.

Usage
-----
    python tui4edge.py
    python tui4edge.py --config path\to\servers.yml

Requirements
------------
None beyond the Python standard library -- no curses, no windows-curses,
no pip install, on either Windows or Linux. See agent/tui/__init__.py for
why.
"""
import argparse
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent.config import ConfigError, load_config  # noqa: E402
from agent.logging_setup import configure_logging  # noqa: E402
from agent.tui.app import run_tui  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser(description="TUI4Edge -- BIOS-style launcher for the EBO Docker Agent.")
    parser.add_argument("--config", default=None, help="Path to servers.yml (default: config/servers.yml).")
    parser.add_argument("--verbose", action="store_true", help="Enable debug-level logging to logs/agent.log.")
    args = parser.parse_args()

    configure_logging(verbose=args.verbose)

    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        print(f"Configuration error: {exc}")
        sys.exit(2)

    run_tui(cfg)


if __name__ == "__main__":
    main()
