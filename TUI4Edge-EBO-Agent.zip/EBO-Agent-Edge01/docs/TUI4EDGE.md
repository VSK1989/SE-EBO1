# TUI4Edge — BIOS-Style Launcher for the EBO Docker Agent

TUI4Edge is a full-screen, keyboard-only Text User Interface for the EBO
Docker Agent, styled visually on classic BIOS setup utilities (Award/AMI
BIOS, old DOS tools): a solid blue background, double-line borders, a
scrolling "Item Help" panel describing whatever is currently highlighted,
and a reverse-video key-legend bar pinned to the bottom of the screen.

It is a pure alternative **front-end** — every action it performs calls
the exact same `agent.*` modules the plain CLI (`python run_agent.py ...`)
uses, so the two are always behaviourally identical. Use whichever you
prefer; nothing is CLI-only or TUI-only.

## Launching it

```powershell
python tui4edge.py
# or, equivalently:
python run_agent.py tui
```

No `pip install` is required on Windows or Linux — see "Why no curses?"
below.

## Screen map

```
Main Menu
 ├── Servers               (list of configured servers + live status badges)
 │     └── <ServerName>    (per-server action menu)
 ├── Network               (settings view + strategy override + adapter detect)
 ├── Diagnostics           (discover / validate / sync-ip / collect-all-logs)
 └── About / Help          (version, key bindings, lineage note)
```

Press **F1** from anywhere to jump straight to About/Help. Press **ESC**
to go back one level, or — from the Main Menu — to bring up the
"Exit TUI4Edge?" confirmation.

## Key bindings (global)

| Key | Action |
|---|---|
| `\u2191` / `\u2193` (Up/Down) | Move the selection in the current menu |
| `\u2190` / `\u2192` (Left/Right) | Change a value (Network screen) / toggle a Yes-No choice |
| `Enter` | Select the highlighted item / confirm |
| `Esc` | Go back one screen, or cancel a dialog |
| `F1` | Open the About/Help screen |
| `F5` | Refresh the Servers list |
| `F10` | Save (Network screen's strategy override) |

## ASCII mock-up: Main Menu

```
╔══════════════════════════════════════════════════════════════════════╗
║              TUI4Edge -- EBO Docker Agent Setup Utility               ║
╚══════════════════════════════════════════════════════════════════════╝

  ┌──────────────────────── System Summary ─────────────────────────┐
  │  Host OS:          windows        Docker daemon:    available   │
  │  Network strategy: bridge_ports   Configured servers: 1         │
  └───────────────────────────────────────────────────────────────┘

  ┌──────────────────────────────────────────────────────────────┐
  │> Servers                                                      │
  │  Network                                                      │
  │  Diagnostics                                                  │
  │  About / Help                                                 │
  │  Exit                                                         │
  └──────────────────────────────────────────────────────────────┘

 ↑↓: Move  Enter: Select  F1: Help  ESC: Exit
```

## ASCII mock-up: Servers list + Item Help panel

```
╔══════════════════════════════════════════════════════════════════════╗
║              TUI4Edge -- EBO Docker Agent Setup Utility               ║
╚══════════════════════════════════════════════════════════════════════╝

  ┌──────────── Menu ────────────┐┌─────────── Item Help ────────────┐
  │> Edge01   [RUNNING]          ││ Server 'Edge01'. Press Enter to  │
  │  Refresh                     ││ view its action menu (start/     │
  │  Back                        ││ stop/backup/password-reset/      │
  │                              ││ trace logs/...).                 │
  └──────────────────────────────┘└───────────────────────────────────┘

 ↑↓: Move  Enter: Select  F5: Refresh  ESC: Back
```

If a server's Docker-assigned IP no longer matches `servers.yml`, its
badge reads `RUNNING (IP DRIFT)` — head to Diagnostics → Sync IP Drift
to correct it automatically.

## ASCII mock-up: Exit confirmation dialog

```
                  ╔═══════════ Exit TUI4Edge ════════════╗
                  ║                                       ║
                  ║   Exit and return to your shell?      ║
                  ║                                       ║
                  ║        No            [ Yes ]          ║
                  ║                                       ║
                  ╚═══════════════════════════════════════╝
```

Every destructive action (Stop, Remove, Restore Backup, Exit) shows this
same style of Y/N dialog before proceeding — nothing happens on a single
accidental Enter press against a menu item that mutates state.

## Why no curses?

Python's `curses` module ships in the standard library on POSIX but
**not** on Windows (it requires `pip install windows-curses`), which would
have broken this project's zero-pip-install-on-either-platform principle.
TUI4Edge is instead built from two things every Python install already
has:

- **ANSI escape codes** for all colour/box-drawing/cursor control — which
  work on Linux/macOS terminals out of the box, and on Windows 10+ consoles
  once "virtual terminal processing" is switched on with a single
  `ctypes` call (`agent/tui/term_io.py:enable_windows_ansi()`).
- **The platform's own raw key reader** — `msvcrt.getch()` on Windows,
  raw-mode `os.read()` + escape-sequence parsing on POSIX — both unified
  behind one `read_key()` function that returns the same symbolic names
  (`'UP'`, `'ENTER'`, `'F1'`, etc.) on either OS.

## Architecture

```
agent/tui/
  term_io.py   -- the ONLY module touching the real terminal
  theme.py     -- BIOS palette + Canvas (a testable, in-memory screen grid)
  widgets.py   -- Menu, TabBar, ToggleField, ConfirmDialog, TextInputDialog,
                  ScrollableText -- all draw into a Canvas, never the terminal
  screens.py   -- MainMenu / Servers / ServerDetail / Network / Diagnostics /
                  About -- each wired to the real agent.* modules
  app.py       -- the screen-stack + main event loop
```

Because `Canvas` is plain data (a grid of `(char, fg, bg)` cells) rather
than direct terminal writes, every widget's layout and every screen's menu
navigation is unit-testable without a real terminal — see
`tests/test_tui_theme.py` and `tests/test_tui_widgets.py`. A further,
fully automated end-to-end test (`tests/test_tui_integration_pty.py`)
spawns the real `tui4edge.py` inside a genuine pseudo-terminal, feeds it
scripted keystrokes, and asserts the expected screen content appears —
proving the whole stack (key decoding → screen navigation → rendering)
works together, not just in isolation.

## A real bug this testing approach caught

While building the automated pty-based test, the first version lost the
first few scripted keystrokes. The cause turned out to be a classic
terminal-programming gotcha, not a TUI bug: Python's `tty.setcbreak()`
defaults to `TCSAFLUSH`, which **discards any input bytes already sitting
in the kernel's buffer** at the exact moment raw mode is switched on. The
test was sending keystrokes before the subprocess had finished starting up
and called `raw_terminal()` — so those early keys were silently dropped by
the OS itself. The fix was in the test's timing (wait for the first
rendered frame before sending any keys), not in `term_io.py`, which was
correct all along — confirmed by an isolated key-decode probe that
validated every arrow/Enter/Tab/F-key decoded correctly once the timing
was right. This is documented in `tests/test_tui_integration_pty.py`'s
own module docstring so it is never mis-diagnosed differently later.
