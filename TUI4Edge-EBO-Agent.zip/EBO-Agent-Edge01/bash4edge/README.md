# Bash4Edge (Path B)

This folder holds the shared `servers.yml` for the Ubuntu/Linux side of
the project. The full, verified Bash4Edge toolkit (functions.sh,
manageOS.sh, setupDockerNetwork.sh, manageGraphDb.sh, manageServers.sh,
getLogs.sh, manageBackups.sh, dockerCommands.sh, plus the
discoverConnectivity.sh companion script) was delivered in the previous
cross-platform enhancement ZIP from this same project thread. This
delivery's focus is TUI4Edge (see docs/TUI4EDGE.md) and the Python agent
package it drives -- ask if you'd like the full Bash4Edge scripts
re-bundled alongside it in one combined ZIP.
