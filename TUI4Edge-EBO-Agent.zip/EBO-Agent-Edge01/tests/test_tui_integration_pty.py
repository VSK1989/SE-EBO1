"""
tests/test_tui_integration_pty.py
====================================
Purpose
-------
An automated, end-to-end smoke test for TUI4Edge: spawns tui4edge.py
inside a REAL pseudo-terminal (so term_io's termios/tty raw-mode calls
have a genuine TTY to operate on -- they are silently no-ops/errors under
unittest's normal captured stdin), feeds it a scripted sequence of
keystrokes, and asserts the expected BIOS-style screen content appears.

Regression note: the very first version of this test used only a 0.3s
startup delay before sending keystrokes, and lost the first few
keypresses. The cause: Python's tty.setcbreak() defaults to TCSAFLUSH,
which DISCARDS any input bytes already buffered by the kernel at the
exact moment raw mode is entered. If the test harness writes keystrokes
before the subprocess has finished starting up (importing modules,
loading config, and calling raw_terminal()), those bytes are silently
dropped -- not a bug in term_io or the app, but a timing hazard in the
TEST ITSELF. Fixed by waiting substantially longer (1.5s) for the first
rendered frame before sending any keys. This is documented here so it is
never "fixed" the wrong way (e.g., by changing production code) if
someone encounters the same symptom again.

Skipped entirely on Windows and in any environment without a `pty` module
(Windows has no pty; the production app's Windows code path uses
msvcrt.getch() instead, which is exercised by unit tests on the decode
tables in test_tui_term_io.py, not by this POSIX-only integration test).
"""
import os
import select
import subprocess
import sys
import time
import unittest
from pathlib import Path

try:
    import pty
    HAVE_PTY = True
except ImportError:
    HAVE_PTY = False

PROJECT_ROOT = Path(__file__).resolve().parent.parent


def _run_scripted_session(keys, startup_wait=1.5, key_wait=0.15):
    master_fd, slave_fd = pty.openpty()
    proc = subprocess.Popen(
        [sys.executable, "tui4edge.py"],
        stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
        cwd=str(PROJECT_ROOT), env={**os.environ, "TERM": "xterm-256color"},
    )
    os.close(slave_fd)
    output = b""

    def drain(t):
        nonlocal output
        end = time.monotonic() + t
        while time.monotonic() < end:
            r, _w, _x = select.select([master_fd], [], [], 0.05)
            if r:
                try:
                    output += os.read(master_fd, 65536)
                except OSError:
                    break

    drain(startup_wait)
    for k in keys:
        os.write(master_fd, k.encode("latin-1"))
        drain(key_wait)

    proc.terminate()
    try:
        proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        proc.kill()
    os.close(master_fd)
    return output.decode("utf-8", errors="replace")


@unittest.skipUnless(HAVE_PTY, "pty module not available on this platform (expected on Windows)")
class TestTuiEndToEnd(unittest.TestCase):
    def test_initial_screen_shows_title_and_summary(self):
        text = _run_scripted_session(keys=["\x1b"], startup_wait=1.5, key_wait=0.1)
        self.assertIn("TUI4Edge", text)
        self.assertIn("System Summary", text)
        self.assertIn("\u2554", text)  # double-line box border character

    def test_navigate_to_exit_and_see_confirm_dialog(self):
        # DOWN x4: Servers -> Network -> Diagnostics -> About/Help -> Exit
        keys = ["\x1b[B"] * 4 + ["\r"]
        text = _run_scripted_session(keys)
        self.assertIn("Exit TUI4Edge", text)
        self.assertIn("Exit and return to your shell?", text)

    def test_escape_from_confirm_dialog_cancels_without_exiting(self):
        # Reach the Exit confirm, then ESC to cancel -- app should still be
        # alive and back at the Main Menu (title bar still present).
        keys = ["\x1b[B"] * 4 + ["\r", "\x1b"]
        text = _run_scripted_session(keys)
        self.assertIn("TUI4Edge", text)

    def test_enter_servers_screen_lists_configured_server(self):
        # Index 0 is already "Servers" -- just press Enter.
        keys = ["\r"]
        text = _run_scripted_session(keys)
        self.assertIn("Edge01", text)

    def test_f1_opens_about_screen_from_main_menu(self):
        keys = ["\x1bOP"]  # F1 via SS3 sequence
        text = _run_scripted_session(keys)
        self.assertIn("About TUI4Edge", text)


if __name__ == "__main__":
    unittest.main()
