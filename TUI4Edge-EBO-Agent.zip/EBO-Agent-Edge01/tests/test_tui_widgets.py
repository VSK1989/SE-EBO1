"""
tests/test_tui_widgets.py
============================
Purpose: Validate Menu/TabBar/ToggleField navigation state machines and
wrap_text(), all pure logic operating on theme.Canvas -- no real terminal
needed.
"""
import unittest

from agent.tui.theme import Canvas
from agent.tui.widgets import Menu, MenuItem, TabBar, ToggleField, wrap_text


class TestWrapText(unittest.TestCase):
    def test_short_text_single_line(self):
        self.assertEqual(wrap_text("hello", 20), ["hello"])

    def test_wraps_at_width(self):
        lines = wrap_text("one two three four five", 10)
        self.assertTrue(all(len(l) <= 10 for l in lines))
        self.assertEqual(" ".join(lines).split(), "one two three four five".split())

    def test_respects_existing_newlines(self):
        lines = wrap_text("line one\nline two", 50)
        self.assertEqual(lines, ["line one", "line two"])


class TestMenu(unittest.TestCase):
    def setUp(self):
        self.menu = Menu([MenuItem("A", "help A"), MenuItem("B", "help B"), MenuItem("C", "help C")])

    def test_starts_at_index_zero(self):
        self.assertEqual(self.menu.index, 0)
        self.assertEqual(self.menu.current().label, "A")

    def test_move_down_advances(self):
        self.menu.move_down()
        self.assertEqual(self.menu.current().label, "B")

    def test_move_down_wraps_around(self):
        self.menu.index = 2
        self.menu.move_down()
        self.assertEqual(self.menu.current().label, "A")

    def test_move_up_wraps_around(self):
        self.menu.move_up()
        self.assertEqual(self.menu.current().label, "C")

    def test_empty_menu_does_not_crash(self):
        empty = Menu([])
        empty.move_down()
        empty.move_up()
        self.assertIsNone(empty.current())

    def test_draw_renders_items_and_help_panel(self):
        canvas = Canvas(80, 20)
        self.menu.draw(canvas, 0, 0, 80, 10)
        flat = "".join(cell[0] for row in canvas.grid for cell in row)
        self.assertIn("A", flat)
        self.assertIn("help A", flat)

    def test_draw_without_help_panel(self):
        canvas = Canvas(80, 20)
        self.menu.draw(canvas, 0, 0, 80, 10, help_panel=False)
        flat = "".join(cell[0] for row in canvas.grid for cell in row)
        self.assertIn("A", flat)


class TestTabBar(unittest.TestCase):
    def test_wraps_both_directions(self):
        tabs = TabBar(["Main", "Servers", "Network"])
        self.assertEqual(tabs.current(), "Main")
        tabs.move_left()
        self.assertEqual(tabs.current(), "Network")
        tabs.move_right()
        self.assertEqual(tabs.current(), "Main")
        tabs.move_right()
        self.assertEqual(tabs.current(), "Servers")


class TestToggleField(unittest.TestCase):
    def test_cycles_left_and_right(self):
        t = ToggleField("Strategy:", ["Auto", "ipvlan", "bridge_ports"])
        self.assertEqual(t.value(), "Auto")
        t.move_right()
        self.assertEqual(t.value(), "ipvlan")
        t.move_right()
        t.move_right()
        self.assertEqual(t.value(), "Auto")  # wrapped
        t.move_left()
        self.assertEqual(t.value(), "bridge_ports")

    def test_draw_shows_current_value(self):
        t = ToggleField("Strategy:", ["Auto", "ipvlan"])
        canvas = Canvas(80, 5)
        t.draw(canvas, 0, 0, 60)
        flat = "".join(cell[0] for row in canvas.grid for cell in row)
        self.assertIn("Auto", flat)


if __name__ == "__main__":
    unittest.main()
