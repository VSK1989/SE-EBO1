"""
tests/test_tui_theme.py
==========================
Purpose: Validate theme.Canvas's drawing primitives directly against its
in-memory grid -- no real terminal needed, since Canvas is plain data.
"""
import unittest

from agent.tui.theme import Canvas, DEFAULT_BG, DEFAULT_FG, TITLE_FG


class TestCanvas(unittest.TestCase):
    def test_starts_blank_with_default_colors(self):
        c = Canvas(10, 5)
        ch, fg, bg = c.grid[0][0]
        self.assertEqual(ch, " ")
        self.assertEqual(fg, DEFAULT_FG)
        self.assertEqual(bg, DEFAULT_BG)

    def test_put_writes_text_at_position(self):
        c = Canvas(20, 5)
        c.put(2, 1, "Hello")
        row = c.grid[1]
        self.assertEqual(row[2][0], "H")
        self.assertEqual(row[6][0], "o")

    def test_put_out_of_bounds_is_ignored_not_raised(self):
        c = Canvas(10, 5)
        c.put(100, 100, "overflow")  # must not raise
        c.put(-5, -5, "underflow")

    def test_put_centered(self):
        c = Canvas(20, 5)
        c.put_centered(0, "Hi")
        row = c.grid[0]
        self.assertEqual(row[9][0], "H")

    def test_box_draws_corners(self):
        c = Canvas(10, 5)
        c.box(0, 0, 10, 5, double=False)
        self.assertEqual(c.grid[0][0][0], "\u250c")
        self.assertEqual(c.grid[0][9][0], "\u2510")
        self.assertEqual(c.grid[4][0][0], "\u2514")
        self.assertEqual(c.grid[4][9][0], "\u2518")

    def test_box_double_line_variant(self):
        c = Canvas(10, 5)
        c.box(0, 0, 10, 5, double=True)
        self.assertEqual(c.grid[0][0][0], "\u2554")

    def test_box_title_is_embedded_in_top_border(self):
        c = Canvas(20, 5)
        c.box(0, 0, 20, 5, title="Hi")
        top_row = "".join(cell[0] for cell in c.grid[0])
        self.assertIn("Hi", top_row)

    def test_fill_rect(self):
        c = Canvas(10, 5)
        c.fill_rect(1, 1, 3, 2, fg=TITLE_FG)
        self.assertEqual(c.grid[1][1][1], TITLE_FG)
        self.assertEqual(c.grid[2][3][1], TITLE_FG)

    def test_render_includes_cursor_home_and_reset(self):
        c = Canvas(5, 2)
        out = c.render()
        self.assertTrue(out.startswith("\x1b[1;1H"))
        self.assertTrue(out.endswith("\x1b[0m"))

    def test_render_produces_correct_row_count(self):
        c = Canvas(5, 3)
        out = c.render()
        # 3 rows + final reset with no trailing \r\n after reset
        self.assertEqual(out.count("\r\n"), 3)


if __name__ == "__main__":
    unittest.main()
