"""
tests/manual_pty_smoke_test.py
=================================
Not a unittest -- a manual smoke-test harness that spawns tui4edge.py
inside a real pseudo-terminal (so term_io's termios/tty raw-mode calls
have a genuine TTY to operate on, which they do not when run under
pytest/unittest's captured stdin), feeds it a scripted sequence of
keystrokes, and dumps whatever the TUI wrote to the terminal so we can
visually confirm the BIOS-style screen actually renders and responds to
navigation, without a human sitting at a real keyboard.

Run manually with: python tests/manual_pty_smoke_test.py
"""
import os
import pty
import select
import subprocess
import sys
import time

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run_scripted_session(keys, wait=0.15):
    master_fd, slave_fd = pty.openpty()
    proc = subprocess.Popen(
        [sys.executable, "tui4edge.py"],
        stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
        cwd=PROJECT_ROOT, env={**os.environ, "TERM": "xterm-256color"},
    )
    os.close(slave_fd)

    output = b""

    def drain(t=0.2):
        nonlocal output
        end = time.monotonic() + t
        while time.monotonic() < end:
            r, _w, _x = select.select([master_fd], [], [], 0.05)
            if r:
                try:
                    chunk = os.read(master_fd, 65536)
                except OSError:
                    break
                output += chunk

    drain(1.5)  # let the subprocess finish starting up and enter raw/cbreak
    # mode (tty.setcbreak uses TCSAFLUSH, which discards any input bytes
    # already buffered at the moment the mode switches -- so keystrokes
    # sent too early, before the app has fully started, can be silently
    # dropped by the kernel itself, not by any bug in term_io/the app).
    for k in keys:
        os.write(master_fd, k.encode("latin-1"))
        drain(wait)

    proc.terminate()
    try:
        proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        proc.kill()
    os.close(master_fd)
    return output


if __name__ == "__main__":
    # ESC ESC confirms "Exit? Y/N" -> arrow to Yes-equivalent not needed
    # since ENTER after ESC opens confirm dialog defaulting to "No"; here
    # we navigate: DOWN DOWN DOWN DOWN (to 'Exit' item) ENTER (opens
    # confirm) RIGHT (select Yes) ENTER (confirm) to cleanly exit.
    keys = ["\x1b[B", "\x1b[B", "\x1b[B", "\x1b[B", "\r", "\x1b[C", "\r"]
    raw = run_scripted_session(keys)
    text = raw.decode("utf-8", errors="replace")
    print("=== RAW OUTPUT LENGTH:", len(raw), "bytes ===")
    print("=== Contains BIOS title? ===", "TUI4Edge" in text)
    print("=== Contains 'System Summary'? ===", "System Summary" in text)
    print("=== Contains box-drawing chars? ===", "\u2554" in text or "\u250c" in text)
    # Save RAW BYTES for visual inspection (so ANSI escape codes + UTF-8
    # box-drawing characters survive untouched; decode only when printing).
    with open("/tmp/tui_smoke_output.bin", "wb") as f:
        f.write(raw)
    with open("/tmp/tui_smoke_output.txt", "w", encoding="utf-8") as f:
        f.write(text)
    print("Full captured output written to /tmp/tui_smoke_output.bin (raw) and .txt (decoded)")
