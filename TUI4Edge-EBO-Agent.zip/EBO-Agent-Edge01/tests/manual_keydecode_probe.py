"""Standalone probe: prints each decoded key name to a log file, fed over a
real pty, to isolate term_io.read_key() correctness from the rest of the
TUI's application logic."""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from agent.tui import term_io

with open("/tmp/keydecode_probe.log", "w") as f:
    with term_io.raw_terminal():
        for _ in range(10):
            key = term_io.read_key(timeout=3)
            f.write(f"{key!r}\n")
            f.flush()
            if key == "ESC":
                break
