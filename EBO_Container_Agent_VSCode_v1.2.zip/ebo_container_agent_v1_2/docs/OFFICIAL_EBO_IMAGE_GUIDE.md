# EBO image operations merged into this package

This reference captures the operational areas supplied by the user: licensing/EULA, IPvlan network creation, start and upgrade scripts, XBK backup listing/copy/restore, CA bundles, proxy variables, crash dumps, DNS override, password-reset mode, Docker commands, port-forwarded lab use and GraphDB.

## Safety model
The agent prints commands by default. Docker-changing operations require `--execute`. Official helper-script commands are emitted as plans because the helper scripts must exist on a Linux Docker host.

## Network
`network-plan` builds:
`./create-bridged-network <subnet> <gateway> <parent-interface>`

Use a free static address. The source guide recommends IPvlan for direct LAN communication such as BACnet. The included default stays on Docker Desktop port forwarding because Docker Desktop and a native Linux host are different environments.

## EULA and licensing
`config.json` intentionally ships with `accept_eula` set to `No`. Change it to `Yes` only after you are authorised to accept the EULA. Valid activated product licensing is still required for full functionality.

## Start and upgrade
`start-plan` emits the official `start.py` syntax. `upgrade-plan VERSION` emits `upgrade.py` with the new version while preserving the other configured values.

## Backup
`backup-plan list`, `backup-plan copy --path PATH`, and `backup-plan restore --path FILE --backup-version VERSION --mode ConfigurationOnly|AllData` emit the documented helper commands. Paths containing spaces are safely quoted by the CLI.

## Certificates and proxy
Set `tls.ca_bundle` to a combined PEM bundle. It is mounted read-only over `/opt/sbo/etc/ca-bundle.crt` for the direct Docker mode and passed through `--ca-bundle` for the official-script plan. `http_proxy`, `https_proxy`, and `no_proxy` are supported.

## Crash dumps
Crash-dump host configuration changes kernel and security settings and is therefore documented, not automated. Follow the official host procedure and ensure `/var/crash` is writable by the required container identity. DNS must work for transmission.

## DNS
Set `network.dns` to the required DNS server. The value is added to generated start commands.

## Password reset
The official syntax is `./password-reset-mode <name> <version>`. Run it only from the checked-out `user-scripts` folder and with the exact deployed version.

## GraphDB
When enabled, `start-plan` adds `--graphdb=<url>`. The supplied guide requires a GraphDB repository ID `nsp` with context index enabled. GraphDB licensing is separate.
