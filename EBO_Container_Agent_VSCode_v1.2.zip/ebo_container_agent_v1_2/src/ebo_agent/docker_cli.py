import json, subprocess, shutil

def run(args, check=True):
    if not shutil.which("docker"):
        raise RuntimeError("Docker CLI was not found in PATH")
    cp=subprocess.run(["docker",*args],text=True,capture_output=True)
    if check and cp.returncode:
        raise RuntimeError(cp.stderr.strip() or cp.stdout.strip())
    return cp

def inspect(name):
    cp=run(["inspect",name])
    return json.loads(cp.stdout)[0]

def exists(name):
    return run(["inspect",name],check=False).returncode==0
