import argparse, json, shlex
from .config import load
from .commands import plan, doctor, run
from .official_scripts import start_command,upgrade_command,network_command,backup_command

def show(parts): print(" ".join(shlex.quote(str(x)) for x in parts))
def main():
    p=argparse.ArgumentParser(prog='ebo-agent'); p.add_argument('--config',default='config.json')
    s=p.add_subparsers(dest='cmd',required=True)
    s.add_parser('doctor');
    op=s.add_parser('docker'); op.add_argument('operation',choices=['pull','start','stop','remove','logs','follow']); op.add_argument('--execute',action='store_true')
    s.add_parser('network-plan'); s.add_parser('start-plan')
    u=s.add_parser('upgrade-plan'); u.add_argument('new_version')
    b=s.add_parser('backup-plan'); b.add_argument('action',choices=['list','copy','restore']); b.add_argument('--path'); b.add_argument('--backup-version'); b.add_argument('--mode',choices=['ConfigurationOnly','AllData'],default='ConfigurationOnly')
    a=p.parse_args(); c=load(a.config)
    if a.cmd=='doctor':
        for k,v in doctor(c): print(('PASS' if v else 'FAIL')+': '+k)
    elif a.cmd=='docker':
        x=plan(c,a.operation); show(['docker',*x]);
        if a.execute: print(run(x).stdout,end='')
    elif a.cmd=='network-plan': show(network_command(c))
    elif a.cmd=='start-plan': show(start_command(c))
    elif a.cmd=='upgrade-plan': show(upgrade_command(c,a.new_version))
    elif a.cmd=='backup-plan': show(backup_command(c,a.action,a.path,a.backup_version,a.mode))
if __name__=='__main__': main()
