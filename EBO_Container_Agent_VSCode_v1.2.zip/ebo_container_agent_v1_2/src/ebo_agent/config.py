from pathlib import Path
import json

def load(path="config.json"):
    p=Path(path)
    data=json.loads(p.read_text(encoding="utf-8"))
    required=[("container","name"),("container","type"),("container","version")]
    missing=[".".join(x) for x in required if not data.get(x[0],{}).get(x[1])]
    if missing: raise ValueError("Missing configuration: "+", ".join(missing))
    return data
