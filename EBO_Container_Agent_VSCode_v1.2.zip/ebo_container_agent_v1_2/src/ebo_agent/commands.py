from pathlib import Path
from .docker_cli import run, exists, inspect

def image(c): return f"{c['container']['image_registry']}/{c['container']['type']}:{c['container']['version']}"

def port_run(c):
    n=c['container']['name']; p=c['ports']; st=c['storage']; args=["run","-d","--name",n,"--hostname",n,
      "-p",f"{p['http']}:80","-p",f"{p['https']}:443","-p",f"{p['csp']}:4444",
      "-e",f"NSP_ACCEPT_EULA={c['container']['accept_eula']}","-v",f"{st['database_volume']}:/opt/sbo/db"]
    if c['network'].get('dns'): args += ["--dns",c['network']['dns']]
    for k in ('http_proxy','https_proxy','no_proxy'):
        v=c['proxy'].get(k)
        if v: args += ["-e",f"{k}={v}","-e",f"{k.upper()}={v}"]
    if c['tls'].get('ca_bundle'):
        args += ["-v",f"{Path(c['tls']['ca_bundle']).resolve()}:/opt/sbo/etc/ca-bundle.crt:ro"]
    args += [image(c)]
    return args

def plan(c, operation):
    n=c['container']['name']
    if operation=='pull': return ["pull",image(c)]
    if operation=='start': return port_run(c)
    if operation=='stop': return ["stop",n]
    if operation=='remove': return ["rm",n]
    if operation=='logs': return ["logs","--tail","200",n]
    if operation=='follow': return ["logs","-f",n]
    raise ValueError(operation)

def doctor(c):
    checks=[]
    try:
        cp=run(["version"],check=False); checks.append(("Docker engine",cp.returncode==0))
        checks.append(("Container exists",exists(c['container']['name'])))
        checks.append(("EULA accepted",c['container']['accept_eula'].lower()=="yes"))
        if exists(c['container']['name']):
            d=inspect(c['container']['name']); checks.append(("Container running",d.get('State',{}).get('Running',False)))
    except Exception as e: checks.append((str(e),False))
    return checks
