from pathlib import Path

def q(x): return str(x).replace(" ","\\ ")

def start_command(c):
    x=c['container']; cmd=["./start.py",f"--name={x['name']}",f"--version={x['version']}",f"--ip={x['ip']}",f"--type={x['type']}",f"--accept-eula={x['accept_eula']}"]
    if c['tls'].get('ca_bundle'): cmd.append(f"--ca-bundle={c['tls']['ca_bundle']}")
    if c['network'].get('dns'): cmd.append(f"--dns={c['network']['dns']}")
    for k,flag in [('http_proxy','--http-proxy'),('https_proxy','--https-proxy'),('no_proxy','--no-proxy')]:
        if c['proxy'].get(k): cmd.append(f"{flag}={c['proxy'][k]}")
    if c['graphdb'].get('enabled'): cmd.append(f"--graphdb={c['graphdb']['url']}")
    return cmd

def upgrade_command(c,new_version):
    cmd=start_command(c); cmd[0]="./upgrade.py"
    cmd=[f"--version={new_version}" if x.startswith('--version=') else x for x in cmd]
    return cmd

def network_command(c):
    n=c['network']; return ["./create-bridged-network",n['subnet'],n['gateway'],n['parent_interface']]

def backup_command(c,action,path=None,version=None,mode='ConfigurationOnly'):
    name=c['container']['name']
    if action=='list': return ["./list-backups",name]
    if action=='copy': return ["./copy-backups",name,path or c['storage']['backup_export_folder']]
    if action=='restore':
        if not path or not version: raise ValueError('restore needs --path and --backup-version')
        return ["./restore-backup",name,version,path,mode]
    raise ValueError(action)
