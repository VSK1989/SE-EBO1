# EBO Container Agent 1.2

VS Code-ready, dependency-free Python package for **Edge01** on Docker Desktop. This release merges the supplied EBO image guidance into configuration, command planners and documentation.

## Included
- Docker health check, logs, pull/start/stop/remove planning and optional execution
- Safe Docker Desktop port-forwarded deployment
- Official Linux helper-script plans for IPvlan network, start, upgrade and XBK backups
- CA bundle, proxy, DNS and GraphDB settings
- EULA guard: acceptance defaults to `No`
- VS Code tasks, debugger configuration and tests

## Quick start (Windows PowerShell in VS Code)
```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\scripts\setup.ps1
.\.venv\Scripts\python.exe -m ebo_agent.cli doctor
.\.venv\Scripts\python.exe -m ebo_agent.cli docker start
```
The last command only prints the Docker command. Review `config.json`, accept the EULA only if authorised, then add `--execute`.

## Official Linux script plans
```powershell
.\.venv\Scripts\python.exe -m ebo_agent.cli network-plan
.\.venv\Scripts\python.exe -m ebo_agent.cli start-plan
.\.venv\Scripts\python.exe -m ebo_agent.cli upgrade-plan 7.1.2.171
.\.venv\Scripts\python.exe -m ebo_agent.cli backup-plan list
```
These print commands for the repository's `user-scripts`; they do not claim the scripts are available on Docker Desktop.

## Important
- The configured `192.168.10.1` must be validated against the actual host network before IPvlan use.
- Do not delete `Edge01-db` unless a full reset and data loss are intended.
- Do not use the initial `admin/admin` credentials beyond controlled first login; change them immediately.
- Review `docs/OFFICIAL_EBO_IMAGE_GUIDE.md`.
