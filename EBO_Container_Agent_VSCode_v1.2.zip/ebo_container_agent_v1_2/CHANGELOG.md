# Changelog

## 1.2.0
- Merged EBO image network, EULA, start, upgrade, backup, CA, proxy, DNS, crash-dump, password-reset and GraphDB guidance.
- Added safe command planners and EULA default-deny behaviour.
