import json, tempfile, unittest
from pathlib import Path
from ebo_agent.config import load
from ebo_agent.commands import port_run
from ebo_agent.official_scripts import start_command, network_command, backup_command
class T(unittest.TestCase):
 def setUp(self): self.c=json.loads(Path('config.json').read_text())
 def test_image(self): self.assertIn('ebo-enterprise-server:hf-712',port_run(self.c)[-1])
 def test_ports(self): self.assertIn('1443:443',port_run(self.c))
 def test_eula(self): self.assertIn('NSP_ACCEPT_EULA=No',port_run(self.c))
 def test_official_start(self): self.assertIn('--name=Edge01',start_command(self.c))
 def test_network(self): self.assertEqual(network_command(self.c)[0],'./create-bridged-network')
 def test_backup(self): self.assertEqual(backup_command(self.c,'list'),['./list-backups','Edge01'])
if __name__=='__main__': unittest.main()
