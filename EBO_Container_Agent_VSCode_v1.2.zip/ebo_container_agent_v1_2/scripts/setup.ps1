$ErrorActionPreference='Stop'
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e .
Write-Host "Setup complete. First run: .\.venv\Scripts\python.exe -m ebo_agent.cli doctor"
