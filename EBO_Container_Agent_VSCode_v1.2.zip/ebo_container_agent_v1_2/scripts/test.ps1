$env:PYTHONPATH="$PSScriptRoot\..\src"
py -3 -m unittest discover -s "$PSScriptRoot\..\tests" -v
