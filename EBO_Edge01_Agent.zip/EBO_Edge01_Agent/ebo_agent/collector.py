"""Bounded, best-effort evidence capture and session retention."""
import json
import logging
import shutil
from datetime import datetime
from pathlib import Path
from uuid import uuid4
from .diagnostics import assess,safe_inspect

def save_json(path,obj):path.write_text(json.dumps(obj,indent=2,default=str),encoding='utf-8')
def collect(ops,cfg,root):
    """Create unique session; preserve partial evidence and record individual errors."""
    folder=root/'collections'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:8]);folder.mkdir(parents=True)
    errors=[];result=assess(ops,cfg)
    for key,value in [('container_inspect.json',safe_inspect(result['inspect'])),('container_status.json',result['checks']),('network_inspect.json',result['networks']),('resources.json',result['stats'])]:
        try:save_json(folder/key,value)
        except OSError as exc:errors.append(f'{key}: {exc}')
    try:
        text=ops.logs(cfg['container'],cfg['log_tail'])
        (folder/'container_logs.txt').write_text(text[-cfg['max_log_bytes']:],encoding='utf-8')
    except Exception as exc:errors.append(f'container logs: {exc}')
    if result['inspect'] and (result['inspect'].get('State') or {}).get('Status')=='running':
        for trace in cfg['trace_paths']:
            try:
                text=ops.trace(cfg['container'],trace,cfg['max_log_bytes'])
                (folder/('trace_'+Path(trace).name+'.txt')).write_text(text,encoding='utf-8')
            except Exception as exc:errors.append(f'optional trace {trace}: {exc}')
    errors.extend(result['errors']);errors.extend(ops.warnings)
    summary='EBO Edge01 diagnostic collection\n'+'\n'.join(f'{k}: {v["result"]} | {v["detail"]}' for k,v in result['checks'].items())+'\nRecommendations:\n'+'\n'.join(result['recommendations'])+'\nEvidence warnings:\n'+'\n'.join(errors)+'\n'
    for name,content in [('diagnostics.txt',summary),('summary.txt',summary),('errors.log','\n'.join(errors)+'\n')]:
        try:(folder/name).write_text(content,encoding='utf-8')
        except OSError as exc:logging.error('Cannot write %s: %s',name,exc)
    (root/'latest_summary.txt').write_text(summary,encoding='utf-8')
    sessions=sorted((root/'collections').iterdir(),key=lambda x:x.stat().st_mtime,reverse=True)
    for old in sessions[cfg['max_sessions']:]:
        if old.is_dir() and old.name[:8].isdigit():shutil.rmtree(old)
    return folder,result
