"""Command-line interface, local rule-based analysis and validation."""
import argparse
import json
import logging
import shutil
import sys
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path
from .config import ConfigError,load,output_path
from .docker_ops import DockerOps
from .diagnostics import assess
from .collector import collect

def setup_logging(root):
    log=logging.getLogger();log.setLevel(logging.INFO)
    handler=RotatingFileHandler(root/'agent.log',maxBytes=1000000,backupCount=3,encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));log.addHandler(handler)

def print_checks(result):
    for key,value in result['checks'].items():print(f'{value["result"]}: {key}: {value["detail"]}')
    for line in result['recommendations']:print('ACTION:',line)
    for line in result['errors']:logging.warning('%s',line)

def main(argv=None):
    parser=argparse.ArgumentParser(description='Read-only EBO Docker diagnostic agent')
    parser.add_argument('--config',default=str(Path(__file__).resolve().parent.parent/'config'/'agent.json'))
    commands=parser.add_subparsers(dest='command',required=True)
    for cmd in ('status','diagnostics','collect','validate','health','report','errors','config','connect','auto-on','auto-off','monitor'):commands.add_parser(cmd)
    args=parser.parse_args(argv)
    try:cfg=load(args.config);root=output_path(cfg)
    except ConfigError as exc:print('FAIL:',exc,file=sys.stderr);return 2
    setup_logging(root)
    if args.command=='config':
        print(json.dumps({**cfg,'output_dir_resolved':str(root)},indent=2));return 0
    if args.command in ('auto-on','auto-off'):
        cfg['auto_collect']=args.command=='auto-on'
        Path(args.config).write_text(json.dumps(cfg,indent=2)+'\n',encoding='utf-8')
        print('Automatic collection:',cfg['auto_collect'],'(monitor must be running)');return 0
    if args.command=='errors':
        for file in [root/'agent.log',*sorted((root/'collections').glob('*/errors.log'))[-3:]]:
            if file.exists():print(f'[{file}]\n'+file.read_text(encoding='utf-8',errors='replace')[-4000:])
        return 0
    ops=DockerOps(cfg['backend'])
    if args.command=='connect':
        try:print('PASS: Docker daemon' if ops.ping() else 'FAIL: Docker daemon');return 0
        except Exception as exc:print('FAIL:',exc);return 1
    if args.command=='monitor':
        print('Monitoring Edge01. Ctrl+C stops; no automatic container restart.')
        try:
            while True:
                current=load(args.config);result=assess(ops,current);print_checks(result)
                if current['auto_collect']:print('Collection:',collect(ops,current,root)[0])
                time.sleep(current['interval_seconds'])
        except KeyboardInterrupt:return 0
    if args.command in ('collect','report'):
        folder,result=collect(ops,cfg,root);print('Diagnostic report:',folder/'summary.txt');print_checks(result)
    else:
        result=assess(ops,cfg);print_checks(result)
        if args.command=='validate':
            print('PASS: Python environment',sys.version.split()[0]);print('PASS: JSON configuration');print('PASS: Log directory writable',root)
            if result['checks'].get('docker_daemon',{}).get('result')=='PASS':
                folder,result=collect(ops,cfg,root);print('PASS: Log collection completed',folder);print('PASS: Diagnostic report generated',folder/'summary.txt')
            else:print('WARN: Log collection skipped because Docker daemon is unavailable')
    for warning in ops.warnings:print('WARN:',warning)
    return 1 if any(v['result']=='FAIL' for v in result['checks'].values()) else 0
