"""Normalise container state and produce actionable recommendations."""
import shutil
from .docker_ops import DockerError

def assess(ops, cfg):
    """Return status, evidence, recommendations and per-step errors."""
    result={'checks':{},'errors':[],'recommendations':[],'inspect':None,'networks':{},'stats':None}
    def check(key,fn):
        try: result['checks'][key]={'result':'PASS','detail':fn()}
        except Exception as exc:
            result['checks'][key]={'result':'FAIL','detail':str(exc)}
            result['errors'].append(f'{key}: {exc}')
    check('docker_cli',lambda:shutil.which('docker') or (_ for _ in ()).throw(DockerError('docker not on PATH')))
    check('docker_daemon',ops.ping)
    if result['checks']['docker_daemon']['result']=='FAIL':
        result['recommendations'].append('Start Docker Desktop; in WSL enable Docker Desktop WSL Integration, then run docker version.')
        return result
    try:
        info=ops.inspect(cfg['container']);result['inspect']=info
        state=info.get('State') or {};status=state.get('Status','unknown');health=(state.get('Health') or {}).get('Status','not configured')
        result['checks']['container']={'result':'PASS','detail':status}
        result['checks']['health']={'result':'WARN' if health=='unhealthy' else 'PASS','detail':health}
        if status!='running':result['recommendations'].append('Inspect exit code and recent logs; start container only after reviewing cause.')
        if health=='unhealthy':result['recommendations'].append('Inspect Docker healthcheck output and application trace logs.')
        networks=(info.get('NetworkSettings') or {}).get('Networks') or {}
        ips={name:entry.get('IPAddress','') for name,entry in networks.items()}
        result['checks']['ip']={'result':'PASS' if cfg['expected_ip'] in ips.values() else 'WARN','detail':ips}
        if cfg['expected_ip'] not in ips.values():result['recommendations'].append('Check configured network and actual Docker inspect IP; do not assume the container IP is reachable from Windows.')
        image=(info.get('Config') or {}).get('Image','')
        result['checks']['image']={'result':'PASS' if image==cfg['expected_image'] else 'WARN','detail':image}
        result['networks']=ops.networks(networks)
        if status=='running':check('resources',lambda:ops.stats(cfg['container']))
    except Exception as exc:
        result['checks']['container']={'result':'FAIL','detail':str(exc)}
        result['errors'].append(f'container: {exc}')
        result['recommendations'].append('Check docker ps -a and confirm the container name and active Docker context.')
    return result

def safe_inspect(info):
    """Remove Docker environment variables, labels and potentially sensitive command arguments."""
    if not info:return {}
    state=info.get('State') or {};config=info.get('Config') or {}
    return {'Id':info.get('Id'),'Name':info.get('Name'),'Created':info.get('Created'),'State':state,'Config':{'Image':config.get('Image'),'Hostname':config.get('Hostname'),'Healthcheck':config.get('Healthcheck')},'NetworkSettings':info.get('NetworkSettings'),'Mounts':[{'Type':m.get('Type'),'Destination':m.get('Destination')} for m in info.get('Mounts',[]) ]}
