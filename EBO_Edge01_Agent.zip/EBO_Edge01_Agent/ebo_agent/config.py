"""JSON configuration and Windows/WSL output-path validation."""
import ipaddress
import json
import os
from pathlib import Path

class ConfigError(ValueError):
    """Invalid settings or inaccessible output directory."""

def load(path: str) -> dict:
    """Read and validate configuration, without executing input as code."""
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        assert isinstance(data, dict)
        assert isinstance(data['container'], str) and data['container'].strip()
        ipaddress.ip_address(data['expected_ip'])
        assert data['backend'] in ('auto', 'sdk', 'cli')
        for key in ('log_tail', 'max_sessions', 'max_log_bytes', 'interval_seconds'):
            assert type(data[key]) is int and data[key] > 0
        assert type(data['auto_collect']) is bool
        assert isinstance(data['trace_paths'], list) and all(isinstance(x,str) and x.startswith('/var/sbo/db/logs/') for x in data['trace_paths'])
        return data
    except (OSError, ValueError, KeyError, AssertionError, TypeError) as exc:
        raise ConfigError(f"Invalid configuration {path}: {exc}") from exc

def output_path(config: dict) -> Path:
    """Map Windows path into WSL; reject unmounted Windows paths on native Ubuntu."""
    raw = os.environ.get('EBO_AGENT_OUTPUT_DIR', config['output_dir'])
    if os.name != 'nt' and len(raw)>2 and raw[1:3] == ':\\':
        if 'WSL_DISTRO_NAME' not in os.environ:
            raise ConfigError('Windows output path on native Ubuntu. Mount the Windows folder and set EBO_AGENT_OUTPUT_DIR to its Linux path.')
        raw = '/mnt/' + raw[0].lower() + raw[2:].replace('\\','/')
    path = Path(raw).expanduser()
    try:
        path.mkdir(parents=True, exist_ok=True)
        probe = path / '.agent_write_probe'
        probe.write_text('ok', encoding='utf-8')
        probe.unlink()
    except OSError as exc:
        raise ConfigError(f'Output folder not writable: {path}. Check mount, permissions and available disk space: {exc}') from exc
    return path
