"""Read-only EBO container diagnostic agent."""
__version__ = "1.0.0"
