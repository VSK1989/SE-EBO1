"""Read-only Docker SDK and CLI adapters with explicit fallback."""
import json
import shutil
import subprocess

class DockerError(RuntimeError):
    """Docker command, API or connectivity failure."""

def run(args: list[str], timeout: int = 25) -> str:
    """Execute fixed Docker argv without a shell and with a timeout."""
    try:
        result = subprocess.run(['docker', *args], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise DockerError(str(exc)) from exc
    if result.returncode:
        raise DockerError((result.stderr or result.stdout).strip()[:1500])
    return result.stdout

class DockerOps:
    """Select SDK or CLI per operation; CLI fallback in auto mode."""
    def __init__(self, backend='auto'):
        self.backend=backend
        self.warnings=[]
        self.client=None
        if backend != 'cli':
            try:
                import docker
                self.client=docker.from_env(timeout=12)
                self.client.ping()
            except Exception as exc:
                self.warnings.append(f'SDK unavailable: {exc}; CLI fallback will be attempted' if backend=='auto' else f'SDK unavailable: {exc}')
                self.client=None
    def _call(self, sdk, cli):
        if self.client is not None:
            try: return sdk()
            except Exception as exc:
                self.warnings.append(f'SDK operation failed: {exc}; trying CLI' if self.backend=='auto' else f'SDK operation failed: {exc}')
                if self.backend=='sdk': raise DockerError(str(exc)) from exc
        if self.backend=='sdk': raise DockerError('SDK is unavailable; set backend to auto or cli')
        return cli()
    def ping(self):
        """Verify daemon, not merely Docker executable presence."""
        return self._call(lambda: bool(self.client.ping()),lambda: bool(run(['info','--format','{{json .ServerVersion}}']).strip()))
    def inspect(self,name):
        """Return full Docker inspect mapping; missing container raises DockerError."""
        return self._call(lambda:self.client.containers.get(name).attrs,lambda:json.loads(run(['inspect','--type','container',name]))[0])
    def logs(self,name,tail):
        """Read bounded stdout and stderr logs."""
        return self._call(lambda:self.client.containers.get(name).logs(tail=tail,stdout=True,stderr=True).decode('utf-8','replace'),lambda:run(['logs','--tail',str(tail),name],timeout=35))
    def networks(self, names):
        """Inspect only networks attached to target container."""
        result={}
        for name in names:
            try: result[name]=self._call(lambda n=name:self.client.networks.get(n).attrs,lambda n=name:json.loads(run(['network','inspect',n]))[0])
            except DockerError as exc: self.warnings.append(f'Network {name}: {exc}')
        return result
    def stats(self,name):
        """Return a single resource snapshot if container is running."""
        return self._call(lambda:self.client.containers.get(name).stats(stream=False),lambda:json.loads(run(['stats','--no-stream','--format','{{json .}}',name],timeout=35)))
    def trace(self,name,path,max_bytes):
        """Read a bounded trace file through docker exec; no shell in container."""
        if not path.startswith('/var/sbo/db/logs/'): raise DockerError('Trace path outside allowlisted directory')
        # CLI is used here for bounded output; tail -c is supported on typical Linux images.
        return run(['exec',name,'tail','-c',str(max_bytes),path],timeout=25)
