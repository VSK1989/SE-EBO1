# EBO Edge01 diagnostic agent

Read-only, offline rule-based diagnostic agent for an existing Docker container. No model, API key, YAML, PyYAML or third-party package is required. Optional Docker SDK uses `requirements-sdk.txt`; CLI fallback is automatic. This tool does **not** provision, restart, upgrade or alter EBO.

## Ubuntu in WSL2 + Docker Desktop, recommended
1. Start Docker Desktop on Windows; enable Settings > Resources > WSL Integration for your Ubuntu distribution. In Ubuntu run `docker version` and `docker ps -a`. Do not install a second Docker Engine in WSL just for this project.
2. Extract the ZIP into Ubuntu, open its folder with `code .` in a VS Code WSL window. Install recommended Python and WSL extensions.
3. Run `bash scripts/setup_ubuntu.sh`; select `.venv/bin/python` as interpreter. Optional SDK: `.venv/bin/python -m pip install -r requirements-sdk.txt` (CLI works without this).
4. Run `.venv/bin/python run_agent.py validate` then `.venv/bin/python run_agent.py health` and `.venv/bin/python run_agent.py collect`.
5. For automatic sessions: `.venv/bin/python run_agent.py auto-on` then `.venv/bin/python run_agent.py monitor`. Stop with Ctrl+C; `auto-off` disables subsequent collections. The monitor must remain running; no background service is installed.

## Native Ubuntu, separate Docker Engine
Use a Docker context that reaches the actual Edge01 daemon. Set `EBO_AGENT_OUTPUT_DIR` to a mounted Windows-host directory; an unmounted `C:\...` path is rejected. Check write permission before running. Do not expose the Docker socket over unauthenticated TCP.

## Commands
`status`, `diagnostics`, `health`, `connect`, `collect`, `report`, `validate`, `errors`, `config`, `auto-on`, `auto-off`, `monitor`. Run all as `.venv/bin/python run_agent.py COMMAND`. Use `--config /path/to/agent.json` before COMMAND to override settings.

## Output
Configured Windows destination: `C:\Users\SESA367373\Downloads\DOCKER\CONTAINER1`. Under WSL mapped to `/mnt/c/Users/SESA367373/Downloads/DOCKER/CONTAINER1`. Override with `EBO_AGENT_OUTPUT_DIR`. Each session has a unique timestamp and random suffix; `max_sessions` removes oldest agent-created session folders only. `agent.log` rotates at 1 MB with three backups. Docker logs and trace files are truncated to `max_log_bytes` each; Docker `--tail` limits fetched log lines. Docker CLI log capture currently returns stdout only (stderr Docker log stream may be omitted by CLI); SDK captures both. See docs/ARCHITECTURE.md and docs/FILE_GUIDE.md.

## Configuration
Edit `config/agent.json`: container, expected_ip, expected_image, output_dir, backend (`auto`, `sdk`, `cli`), auto_collect, interval_seconds, log_tail, max_sessions, max_log_bytes, trace_paths. `auto` attempts SDK then CLI. `expected_ip` is an assertion against inspect, not a reachability promise. No secrets in JSON.

## Validation and limitations
`python3 -m unittest discover -s tests -v` runs offline tests. `validate` runs live checks and collects evidence if Docker is available. Live image access, daemon status, network, and EBO application health cannot be proven in the packaged build environment. A Docker `running` state does not establish EBO application readiness. Windows Docker Desktop networking may not route the container IP to the host; check published ports and network design. No container creation or automatic remediation is implemented intentionally. Trace collection is optional and may fail if the file or `tail` utility is absent.

## Security
Read-only Docker operations except optional `docker exec tail` for trace reads; Docker daemon access itself is privileged. Treat logs as confidential, inspect reports before sharing. Full environment variables and command arguments are excluded from inspect export, but raw Docker logs, network data, healthcheck output and trace can still contain secrets. Store output in an access-controlled directory. No credentials from supplied scripts are copied into this project.

## Troubleshooting
- `docker not on PATH`: install/enable Docker Desktop WSL Integration and reopen Ubuntu terminal.
- Daemon unavailable: start Docker Desktop, check `docker context ls` and `docker version`.
- Missing Edge01: `docker ps -a --filter name=Edge01`, verify active context.
- IP mismatch: inspect network assignment; never rewrite network automatically.
- Output path failure: check `/mnt/c` mount and Windows permissions; use `EBO_AGENT_OUTPUT_DIR` for native Ubuntu.
- SDK unavailable: use `backend: cli` or install optional SDK in selected venv.
- `No module named docker`: core CLI still works; SDK is optional.

## Sources
Internal: supplied start.py, getLogs.sh, servers.yml and Bash4Edge readme. External: https://github.com/SchneiderElectricBuildings/EBO-Servers/tree/main/user-scripts ; https://docs.docker.com/desktop/features/wsl/use-wsl/ ; https://docker-py.readthedocs.io/en/stable/index.html .
