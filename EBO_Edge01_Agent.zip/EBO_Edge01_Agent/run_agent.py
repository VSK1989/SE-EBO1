"""Project entry point for VS Code and terminal."""
from ebo_agent.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
