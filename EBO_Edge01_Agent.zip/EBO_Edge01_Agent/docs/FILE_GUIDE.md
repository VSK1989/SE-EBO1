# Source-file guide

| File | Purpose, inputs/outputs and failure handling | Extension |
|---|---|---|
| run_agent.py | Entry point; forwards argv to cli.main and returns exit status. | Alternative UI entry points. |
| ebo_agent/__init__.py | Package version and package marker. | Bump version on release. |
| ebo_agent/config.py | load(path) validates JSON keys and numeric limits; output_path(cfg) validates writable Windows/WSL destination; raises ConfigError. | Add schema validation. |
| ebo_agent/docker_ops.py | run(argv,timeout) executes shell-free Docker CLI; DockerOps wraps ping/inspect/logs/networks/stats/trace and SDK fallback. Raises DockerError, accumulates warnings. | Add read-only operations. |
| ebo_agent/diagnostics.py | assess(ops,cfg) returns checks, errors, advice and raw data; safe_inspect(info) removes environment and command fields. Per-step errors do not abort checks. | Add EBO-specific rules. |
| ebo_agent/collector.py | collect(ops,cfg,root) writes bounded unique session and prunes old sessions; returns folder and assessment. Individual evidence errors are recorded. | Add evidence types with privacy review. |
| ebo_agent/cli.py | main(argv) parses commands, configures rotating log, prints PASS/WARN/FAIL and controls foreground monitor. Exit 1 on failed checks, 2 on configuration failure. | Add subcommands. |
| tests/test_agent.py | unittest fake backend checks config, errors, health/IP, redaction, report, retention without Docker. | Add mocked CLI and SDK integration tests. |
| config/agent.json | Validated non-secret defaults. | Change target and retention. |
| scripts/setup_ubuntu.sh | Creates venv, runs offline tests; does not install Docker or SDK. | Add controlled deployment automation. |
| .vscode/*.json | Interpreter, debug targets, tasks and extension recommendations. | Add launch/task shortcuts. |
| requirements*.txt | Core has no pip dependencies; SDK optional. | Pin approved versions. |

Interaction: CLI loads config and output directory first, instantiates DockerOps, requests diagnostics, then optionally collector. Exceptions from unavailable Docker are reported as checks; configuration failures stop startup. `auto-on` and `auto-off` update only the local JSON. No YAML input or PyYAML. Read README for exact commands and limitations.
