"""Offline tests using fake Docker responses; no live daemon required."""
import json
import tempfile
import unittest
from pathlib import Path
from ebo_agent.config import load,ConfigError
from ebo_agent.diagnostics import assess,safe_inspect
from ebo_agent.collector import collect

class FakeOps:
    warnings=[]
    def ping(self):return True
    def inspect(self,name):return {'Id':'abc','Name':name,'State':{'Status':'running','Health':{'Status':'healthy'}},'Config':{'Image':'image','Env':['SECRET=do-not-export']},'NetworkSettings':{'Networks':{'net':{'IPAddress':'192.168.10.1'}}},'Mounts':[]}
    def networks(self,names):return {'net':{'Name':'net'}}
    def stats(self,name):return {'memory_stats':{'usage':123}}
    def logs(self,name,tail):return 'hello\n'
    def trace(self,name,path,max_bytes):return 'trace\n'

class AgentTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.cfg={'container':'Edge01','expected_ip':'192.168.10.1','expected_image':'image','backend':'cli','auto_collect':False,'interval_seconds':5,'log_tail':5,'max_sessions':2,'max_log_bytes':1000,'trace_paths':['/var/sbo/db/logs/trace.log'],'output_dir':self.tmp.name}
    def test_config(self):
        path=Path(self.tmp.name)/'c.json';path.write_text(json.dumps(self.cfg));self.assertEqual(load(str(path))['container'],'Edge01')
    def test_bad_config(self):
        path=Path(self.tmp.name)/'c.json';path.write_text('{bad');self.assertRaises(ConfigError,load,str(path))
    def test_health_ip(self):self.assertEqual(assess(FakeOps(),self.cfg)['checks']['ip']['result'],'PASS')
    def test_redaction(self):self.assertNotIn('SECRET',json.dumps(safe_inspect(FakeOps().inspect('Edge01'))))
    def test_collection_and_retention(self):
        root=Path(self.tmp.name)
        for _ in range(3):collect(FakeOps(),self.cfg,root)
        self.assertEqual(len(list((root/'collections').iterdir())),2)
        self.assertTrue((root/'latest_summary.txt').exists())
    def test_missing_container(self):
        class Missing(FakeOps):
            def inspect(self,name):raise RuntimeError('not found')
        self.assertEqual(assess(Missing(),self.cfg)['checks']['container']['result'],'FAIL')

if __name__=='__main__':unittest.main()
