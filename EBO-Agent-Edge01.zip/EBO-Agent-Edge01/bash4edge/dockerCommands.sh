#!/bin/bash

# Create an associative array of command prompts and bash commands
declare -A commands=(
    ["List containers"]="docker ps"
    ["Display disk usage"]="docker system df"
    ["Display disk usage (Verbose)"]="docker system df -v"
    ["Prune only unused images"]="docker image prune"
    ["Prune only unused volumes"]="docker volume prune"
    ["Prune unused objects (System-wide)"]="docker system prune -a"
    ["Prune unused objects (System-wide + Volumes)"]="docker system prune -a --volumes"
)

handle_select() {
  PS3="What do you want to do?  "

  # Sort the keys and store them in an array
  IFS=$'\n' sorted_keys=($(printf "%s\n" "${!commands[@]}" | sort))

  select key in "${sorted_keys[@]}" EXIT; do
      if [[ "$key" == "EXIT" ]]; then
        printf "%s\n" "Exiting the script."
        exit
      elif [[ -z "$key" || -z "${commands[$key]}" ]]; then
        printf "%s\n" "Invalid option. Please try again."
      else
        printf "%s\n" "$key"
        command_line=${commands[$key]}
        echo " "
        echo "COMMAND: $command_line"
        echo " "
        bash -c "$command_line"
        echo " "
      fi
  done
}

# Error handling for the SELECT function
handle_select || {
    echo "An error occurred while executing the script."
}