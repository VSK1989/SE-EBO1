#!/bin/bash
#################################################################
# discoverConnectivity.sh  --  NEW, added for cross-platform     #
# feature parity with the Python agent (Path A).                #
#                                                                #
# This file is NOT part of the original, verified Bash4Edge      #
# toolkit (manageOS.sh / setupDockerNetwork.sh / manageGraphDb.sh /#
# manageServers.sh / getLogs.sh / manageBackups.sh /              #
# dockerCommands.sh / functions.sh remain byte-for-byte unchanged  #
# from what was reviewed -- see docs/SOURCE_FILES_REVIEW.md).      #
# It is a new, clearly-labelled ADDITION that gives this Linux/     #
# Bash4Edge side the same "discover every configured server,         #
# check whether it exists/is running, compare configured vs.          #
# actual runtime IP, and validate TCP connectivity" capability the     #
# Python agent's `discover` / `validate` / `sync-ip` commands provide,  #
# so both platforms behave consistently (per your explicit request).    #
#
# Usage:
#   ./discoverConnectivity.sh            # report only
#   ./discoverConnectivity.sh --sync-ip   # also auto-correct drifted IPs
#                                           in servers.yml (uses yq -i,
#                                           the same tool/approach every
#                                           other Bash4Edge script uses for
#                                           in-place edits)
#################################################################

# Reference script containing all functions
# shellcheck source=/dev/null
source ./functions.sh

yaml_file=servers.yml
SYNC_IP=0
if [ "$1" == "--sync-ip" ]; then
    SYNC_IP=1
fi

# Cross-platform note: this script is Ubuntu/Debian-focused by design (like
# the rest of Bash4Edge), but we still print what we detect for
# transparency and troubleshooting, matching the Python agent's own
# "Host OS detected: ..." banner.
if [ -f /etc/os-release ]; then
    . /etc/os-release
    echo "Host OS detected: $NAME $VERSION_ID (Bash4Edge targets Debian/Ubuntu-based hosts)"
fi

servers=$(yq '.servers[] | key' $yaml_file)

echo ""
echo "=== Discovering configured servers ==="
for server in $servers; do
    configured_ip=$(yq .servers.$server.ip $yaml_file)

    if docker inspect "$server" >/dev/null 2>&1; then
        exists="yes"
        running=$(docker inspect -f '{{.State.Running}}' "$server")
        runtime_ip=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' "$server")
    else
        exists="no"
        running="false"
        runtime_ip=""
    fi

    echo ""
    echo "$server:"
    echo "  Exists:        $exists"
    echo "  Running:       $running"
    echo "  Configured IP: $configured_ip"
    echo "  Runtime IP:    ${runtime_ip:-(not running)}"

    if [ -n "$runtime_ip" ] && [ "$runtime_ip" != "$configured_ip" ]; then
        echo "  WARNING: IP DRIFT DETECTED (configured=$configured_ip, actual=$runtime_ip)"
        if [ "$SYNC_IP" -eq 1 ]; then
            eval "yq -i eval '.servers.$server.ip = \"$runtime_ip\"' $yaml_file"
            echo "  -> servers.yml corrected automatically to $runtime_ip"
        else
            echo "  -> re-run with --sync-ip to correct servers.yml automatically"
        fi
    fi

    # Connectivity check: plain TCP connect test on port 443, using bash's
    # own /dev/tcp pseudo-device -- no extra package (nc, nmap, etc.)
    # required, matching this project's zero-extra-dependency philosophy.
    check_ip=${runtime_ip:-$configured_ip}
    if [ "$running" == "true" ] && [ -n "$check_ip" ]; then
        if timeout 3 bash -c "echo > /dev/tcp/$check_ip/443" 2>/dev/null; then
            echo "  Connectivity:  TCP $check_ip:443 reachable"
        else
            echo "  Connectivity:  TCP $check_ip:443 UNREACHABLE"
        fi
    fi
done

echo ""
echo "=== Discovery complete ==="
