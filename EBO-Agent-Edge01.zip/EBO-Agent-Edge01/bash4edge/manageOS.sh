#!/bin/bash

# Reference script containing all functions
# shellcheck source=/dev/null
source ./functions.sh

if [ "$EUID" -ne 0 ]; then
    echo "Please run this script with sudo."
    exit
fi
initPrompt "What do you want to manage OS? (Enter to refresh list, Type 6 to Exit) "
select option in "Install Required Apps" "Update Ubuntu" "Install Docker" "Ensure user has docker permissions" "Install SSH Server" EXIT; do
    if [ -n "$option" ]; then
        if [ "$option" == "EXIT" ]; then
            echo "Exiting the script."
            break
        else
            case $option in
                "Install Required Apps")
                    echo "Installing Required Apps"
                    # REQUIRED bash commands install
                    apt install curl ipcalc jq
                    # REQUIRED Install yq binary
                    curl -L https://github.com/mikefarah/yq/releases/latest/download/yq_linux_amd64 -o /usr/bin/yq && chmod +x /usr/bin/yq
                    ;;
                "Update Ubuntu")
                    echo "Running apt updates and snap refresh"
                    # Install ansible (ONLY for Vangrant Ubuntu image)
                        # apt install ansible ansible-core --allow-change-held-packages -y                
                    # Update and upgrade packages
                    apt update && apt upgrade -y
                    # Autoremove and clean packages
                    apt autoremove -y && apt clean -y
                    # Ensure snap store is updated
                    killall snap-store && snap refresh snap-store
                    # Ensure snap packages are updates
                    snap refresh
                    ;;
                "Install Docker")
                    echo "Removing default docker installation,"
                    echo "installing Docker from latest Docker script,"
                    echo "and configuring user to run docker commands without sudo"
                    # Remove default docker packages
                    apt remove docker docker-engine docker.io containerd runc
                    # Download and install Docker
                    curl -fsSL https://get.docker.com -o get-docker.sh
                    bash ./get-docker.sh
                    echo "----------If you see no errors, Docker is installed.----------"
                    echo "Ensure prompt is not root. Otherwise open new terminal session."
                    ;;
                "Ensure user has docker permissions")
                    # Create the 'docker' group if it doesn't exist
                    if ! grep -q "^docker:" /etc/group; then
                        groupadd docker
                        echo "The 'docker' user group was added"
                    fi
                    # Check if the current user is already a member of the 'docker' group
                    # Use 'logname' to get the session user, instead of $USER which will be root when script is run as sudo
                    LOGNAME=$(logname)
                    if ! groups $LOGNAME | grep -q '\bdocker\b'; then
                        # Add the current user to the 'docker' group
                        usermod -a -G docker $LOGNAME
                        newgrp docker - # added so do not have to logout of current session
                        echo "The user has been added to the 'docker' group."
                    else
                        echo "PLEASE LOG OUT and LOG IN. The user is already a member of the 'docker' group"
                    fi

                    ;;
                "Install SSH Server")
                    echo "Installing OpenSSH Server"
                    # Install openssh-server via apt
                    apt install openssh-server -y

                    # Harden OpenSSH (see functions.sh for more information)
                    hardenOpenSSH

                    # Restart openssh-server to reload config file
                    systemctl restart sshd
            esac
        fi
    else
        echo "Invalid option, please try again"
    fi
done