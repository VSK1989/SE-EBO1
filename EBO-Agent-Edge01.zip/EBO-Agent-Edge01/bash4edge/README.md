## Bash4Edge

These scripts look to solve the issues with setting up Ubuntu 22.04 LTS (Desktop or Server) for use with Edge Server. These are based on User Scripts from [EBO-Edge-Server/user-scripts at main · SchneiderElectricBuildings/EBO-Edge-Server · GitHub](https://github.com/SchneiderElectricBuildings/EBO-Edge-Server/tree/main/user-scripts) and do not require Python to run.

Updating the **servers.yml** file, you can manage multiple servers on the same docker installation. One can also review the code to see the commands to manage Edge Servers.

After managing the Ubuntu OS, I used Microsoft's VS Code running on my laptop to remotely access via SSH the files and terminal. In VS Code, I installed the extension: **Remote Explorer by Microsoft**

### INSTALLATION
- Create Edge folder in home directory (**mkdir ~/Edge**)
- Add the .yml and .sh files to this folder using your favorite method(s).
- Edit **servers.yml** file to build the network(s) and server(s) as needed for the installation.
- Make the sh files executable (**sudo chmod +x \*.sh**)
- Start by running these files in order and answering questions.
- **sudo ./manageOS.sh**
- **./setupDockerNetwork.sh**
- **./manageServers.sh**

**NOTES:**

Each bash script can be run with \<Period\>\<ForwardSlash\> in front of the command, like **./getLogs.sh**

You can exit to the command prompt at any time with **CTRL-z**

**ADDED IN 2.0:**
- Password Reset
- Certificates
- setting DNS servers
- Crash Dumps

**CURRENTLY EXCLUDED:**
- **IPv6**
- **Performing features on multiple servers at once**

\*\*Please DM me if there are any issue and provide specifics. Also let me know if there are any features you would like added.

### ./manageOS.sh

**WARNING:** Must be run as **sudo ./manageOS.sh** to perform the functions

| Type | Option | Notes |
|---|---|---|
| **R** | Install Required Apps | |
| **R** | Update Ubuntu | |
| **R** | Install Docker | |
| **E** | Ensure user has docker permissions | **Note:** Reboot OS when complete to ensure user was assigned to docker group. You can type '**groups**' to see if docker is listed or type '**docker ps**' to see if can run docker without any errors. |
| **O** | Install SSH Server | Can login with Putty or VS Code via SSH using username & password configured on the system. Default Port 22, but code is there to uncomment and change. |

**R** - Required
**E** - Encouraged
**O** - Optional

### ./setupDockerNetwork.sh

| Option | Functionality |
|---|---|
| Get Local Adapter Settings | Checks connection to internet and displays the following: Local Adapter, Local Gateway, Local subnet (CIDR notation). Then prompts to update any network listed in the servers.yml file. |
| Create Docker Network | This creates the docker network from your servers.yml file. It could have been updated for this installation using Get Local Adapter Settings. |

### ./manageGraphDb.sh

Select the Semantics Database server from the servers.yml file. This will manage the ontotext/graphdb container.

| Option | Functionality |
|---|---|
| Create | Pulls container and runs the GraphDb server |
| Check Status | |
| Start | |
| Stop | |
| Stop & Remove | removes the container, but leaves the volume/database |
| Stop & Delete | removes the container and deletes the volume/database |
| Upgrade | Option not available at this time because uses tagged version 10.2.4 |

### ./manageServers.sh

Select the server from the servers.yml file

| Option | Functionality |
|---|---|
| Create | Pulls container and runs the Edge server |
| Check Status | |
| Start | |
| Stop | |
| Stop & Remove | removes the container, but leaves the volume/database |
| Stop & Delete | removes the container and deletes the volume/database |
| Password Reset | Set EBO Server in password reset mode to connect with Workstation and provide Session ID to PSS |
| Upgrade | Choose from the available tags and it will download new image, stop server, remove server, prepare for upgrade, create and run the new version, and update the servers.yml file with the new version. |

### ./getLogs.sh

Select the server from the servers.yml

Creates Log directory

Copies Trace.logs to the \<server name\>/Log directory

Copies docker log to the \<server name\>/Log directory and saves as docker.system.log

### ./manageBackups.sh

Select the server from the servers.yml

| Option | Functionality |
|---|---|
| List Backups | List backups on the Edge Server |
| Copy Backups | Creates \<server name\>/Backups folder and copies XBK from Edge server |
| Restore Backups | Ensure XBK backup is in \<server name\>/Backups folder, then it copies to Edge Server and restores with option of All Data or Configuration Only |

### ./dockerCommands.sh

List of docker commands used for maintenance.

### Known Issues

| Known Issue | Cause | Workaround |
|---|---|---|
| Locale unset throws error: `perl: warning: Setting locale failed.` ... `Falling back to the standard locale ("C").` | User does not have locale configured, typically a 'root' user | Use this command and set to 'en_US.UTF-8' or your language preference: `dpkg-reconfigure locales` |
| Can not login as 'root' via SSH when used 'Install SSH Server' option | Root user is disabled during installation. | Open /etc/ssh/sshd_config and change 'PermitRootLogin' from 'no' to 'yes' |
| Received error message when creating server: `docker: Error response from daemon: invalid mount config for type "bind": bind source path does not exist: /var/crash.` | Directory does not exist. | Exit from script with Ctrl-z. Enter command (may need 'sudo'): `mkdir /var/crash`. Run ./manageServers.sh, select the same server, select 'Stop & Delete' to remove the container with the issue, select 'Create server' to re-create the container properly. |
| Creating server shows similar error: `docker: Error response from daemon: Invalid address 192.168.1.181: It does not belong to any of this network's subnets.` | Server IP in servers.yml does not belong to network IP range. | Update the IP address in servers.yml. If still in options to manage the server, select "Pick a new server" option because one needs to reload IP from servers.yml. Select server with issue. Select the 'Stop & Delete' option to delete the misconfigured server container. Select 'Create server' to re-create the server container with updated ip address. |

### VERSIONS

1.0 - Developed and tested on David's test bench environment (2023-01)

1.1 - Added functions and improved documentation (2023-03)

2.0 - Added EC & ES Repositories, Password Reset, Default Server Settings, and certificate, DNS, and GraphDb support (2024-01)

---

### ADDENDUM (not part of the original toolkit): ./discoverConnectivity.sh

This single script was added to bring this Bash4Edge toolkit into feature
parity with the companion Python agent's `discover` / `validate` /
`sync-ip` commands. It is clearly marked as new in its own header comment
and does not modify any of the eight original scripts above.

```
./discoverConnectivity.sh              # report existence/running/IP-drift/connectivity
./discoverConnectivity.sh --sync-ip    # also auto-correct drifted IPs in servers.yml
```

It uses only `yq`, `docker`, and bash's own `/dev/tcp` pseudo-device for
the connectivity check — no new package dependency is introduced.

Also note: `servers.yml` in this folder is now the SAME file as
`config/servers.yml` used by the Python agent, so both sides of the
project stay in sync automatically if you keep the two copies identical.
