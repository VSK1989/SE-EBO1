#!/bin/bash

#######################################################
# Functions for Bash for Edge Server scripts          #
#                                                     #
# 1.1 - First version using functions                 #
# 2.0 - Added EBO Server default settings and GraphDb #
#######################################################

# Handle Prompts
#################

function initPrompt() {
    if [ -n "$1" ]; then
		export PROMPT="$1"
		PS3=$PROMPT
    fi
}

function updatePrompt() {
    if [ -n "$1" ]; then
        export PROMPTLAST=$PROMPT
		export PROMPT="$1"
		PS3=$PROMPT
    fi         
}

function previousPrompt() {
    export PROMPT=$PROMPTLAST
    PS3=$PROMPT
}

# Handle YAML file and Variables for selected EBO servers
#########################################################

function checkDefaultSettings() {
    local server_data=$1
    local server=$2
    local val=$3

    server_val=$(yq .servers.$server.$val $server_data)
    settings_val=$(yq .serverSettings.$val $server_data)

    if [ $server_val = "null" ]; then
        # No value found for $val in $server. Using default value of $settings_val
        echo $settings_val
    else
        # Using value of $server_val for $val in $server
        echo $server_val
    fi
}

function createServerVars() {
    local server=$1
    local yaml_file=$2

    # Check if parameters are not empty
    if [ -z "$server" ] || [ -z "$yaml_file" ]; then
        echo "Missing parameters. Please provide both 'server' and 'yaml_file' parameters."
        return 1
    fi

    # Required per server
    version_tag=$(yq .servers.$server.version $yaml_file)
    ip=$(yq .servers.$server.ip $yaml_file)
    repo_ref=$(yq .servers.$server.repo $yaml_file)
    repo=$(yq .repos.$repo_ref.repository $yaml_file)

    # Required in serverSettings
    eula=$(yq .serverSettings.accept_eula $yaml_file)

    # Optional per individual server with defaults in serverSettings
    network=$(checkDefaultSettings $yaml_file $server "network")
    db_folder=$(checkDefaultSettings $yaml_file $server "db_folder")
    db_vol=$server$(checkDefaultSettings $yaml_file $server "db_vol_suffix")
    crash_folder=$(checkDefaultSettings $yaml_file $server "crash_folder")
    server_backups=/var/sbo/db_backup/LocalBackup
    local_dest=$(checkDefaultSettings $yaml_file $server "working_dir")/$server/Backups
    local_backups=$(eval echo $local_dest) # Added to expand ~ to home directory

    # Optional per individual server and defaults in serverSettings
    ca_dest=$(checkDefaultSettings "$yaml_file" "$server" "ca_folder")
    ca_folder=$(eval echo $ca_dest) # Added to expand ~ to home directory
    dns_ip=$(checkDefaultSettings "$yaml_file" "$server" "dns_ip")
    graphdb_URL=$(checkDefaultSettings "$yaml_file" "$server" "graphdb_URL")

    export version_tag
    export ip
    export repo
    export eula
    export network
    export db_folder
    export db_vol
    export crash_folder
    export server_backups
    export local_backups
    export ca_folder
    export dns_ip
    export graphdb_URL  
}

# Handle YAML file and Variables for selected SemanticDbs
#########################################################

function createGraphDbVars() {
    local db_server=$1
    local yaml_file=$2

    # Check if parameters are not empty
    if [ -z "$db_server" ] || [ -z "$yaml_file" ]; then
        echo "Missing parameters. Please provide both 'db_server' and 'yaml_file' parameters."
        return 1
    fi

    # Required per server
    db_repo=$(yq .semanticsDbs.$db_server.repository $yaml_file)
    db_version_tag=$(yq .semanticsDbs.$db_server.version $yaml_file)
    db_ip=$(yq .semanticsDbs.$db_server.ip $yaml_file)
    db_port=$(yq .semanticsDbs.$db_server.port $yaml_file)
    db_network=$(yq .semanticsDbs.$db_server.network $yaml_file)

    export db_repo
    export db_version_tag
    export db_ip
    export db_port
    export db_network  
}

# Handle YAML file and Variables for selected network
#####################################################

function createNetworkVars() {
    local network=$1
    local yaml_file=$2

    # Check if parameters are not empty
    if [ -z "$network" ] || [ -z "$yaml_file" ]; then
        echo "Missing parameters. Please provide both 'network' and 'yaml_file' parameters."
        return 1
    fi

    # Extract required fields
    network_type=$(yq .networks.$network.type $yaml_file)
    subnet=$(yq .networks.$network.subnet $yaml_file)
    gateway=$(yq .networks.$network.gateway $yaml_file)
    interface=$(yq .networks.$network.interface $yaml_file)

    # Export variables
    export network_type
    export subnet
    export gateway
    export interface
}

# Harden OpenSSH Server
#######################

function hardenOpenSSH() {
    ###########################################################    
    # CONFIGURATION FILE INFO
    #
    # Reference Location: /usr/share/opessh/sshd_config
    # Working Location: /etc/ssh/sshd_config
    #
    # Run this command to return to default:
    # sudo sshd -T
    # or
    # cp /usr/share/openssh/sshd_config /etc/ssh/sshd_config
    # To compare:
    # diff /usr/share/openssh/sshd_config /etc/ssh/sshd_config
    ###########################################################

    ## Backup original configuration file
    echo "Copying config to /etc/ssh/sshd_config.bak"
    cp /etc/ssh/sshd_config /etc/ssh/sshd_config.bak

    ## Hardening Recommendations ##

    echo "Attempting to harden OpenSSH. Please review hardeningOpenSSH in functions.sh to configure as required by your setup."   

    # Change default port 22 to another port, ie 2200
    # sudo sed -i 's/#Port 22/Port 2200/' /etc/ssh/sshd_config

    # Disable Root Login and forwarding
	sed -i 's/#PermitRootLogin.*/PermitRootLogin no/' /etc/ssh/sshd_config  # This is an issue if you have not added another user besides "root"

    #Thwart login attempts
	sed -i 's/#LoginGraceTime.*/LoginGraceTime 30/' /etc/ssh/sshd_config
	sed -i 's/#MaxAuthTries.*/MaxAuthTries 3/' /etc/ssh/sshd_config

    # Password authentication
	sed -i 's/#PasswordAuthentication.*/PasswordAuthentication yes # Set to NO if configured ssh key authentication/' /etc/ssh/sshd_config  # Set to NO if configured ssh key authentication
	sed -i 's/#PermitEmptyPasswords.*/PermitEmptyPasswords no/' /etc/ssh/sshd_config

    # Disable alternate forms of authentication
	sed -i 's/#KbdInteractiveAuthentication.*/KbdInteractiveAuthentication no/' /etc/ssh/sshd_config
	sed -i 's/#KerberosAuthentication.*/KerberosAuthentication no/' /etc/ssh/sshd_config
	sed -i 's/#GSSAPIAuthentication.*/GSSAPIAuthentication no/' /etc/ssh/sshd_config

    # Disable forwarding, tunneling, and ability to change environment
	sed -i 's/#AllowAgentForwarding.*/AllowAgentForwarding no/' /etc/ssh/sshd_config
	sed -i 's/#AllowTcpForwarding.*/AllowTcpForwarding yes # Set YES for VSCode remote connection, otherwise set to NO/' /etc/ssh/sshd_config   # Set YES for VSCode remote connection, otherwise set to NO   
	sed -i 's/#GatewayPorts.*/GatewayPorts no/' /etc/ssh/sshd_config
	sed -i 's/X11Forwarding.*/X11Forwarding no/' /etc/ssh/sshd_config
	sed -i 's/#PermitUserEnvironment.*/PermitUserEnvironment no/' /etc/ssh/sshd_config
	sed -i 's/#PermitTunnel.*/PermitTunnel no/' /etc/ssh/sshd_config
}