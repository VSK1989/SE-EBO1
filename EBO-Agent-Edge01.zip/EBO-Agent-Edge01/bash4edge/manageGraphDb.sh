#!/bin/bash
# Version 2.0

#Declare variables returned from createGraphDbVars function
declare -g db_server
declare -g db_repo
declare -g db_version_tag
declare -g db_network
declare -g db_ip

# Reference script containing all functions
# shellcheck source=/dev/null
source ./functions.sh

# set path to YAML file
yaml_file=servers.yml

#parse yaml with yq and list networks
db_servers=$(yq '.semanticsDbs[] | key' $yaml_file)
initPrompt "Which server do you want to manage? (Press ENTER to refresh) "
select db_server in $db_servers EXIT; do
    if [ "$db_server" == "EXIT" ]; then
        echo "Exiting the script"
        break
    else
        # Update variables required below based on selected database
        createGraphDbVars $db_server $yaml_file
        # Ensure container has been pulled
        docker pull $db_repo:$db_version_tag
        image_id=$(docker images --filter=reference=$db_repo:$db_version_tag --format "{{.ID}}")
        #
        # Select action to manage the selected server
        updatePrompt "Which action do you want to execute? (Enter to refresh, Type 7 to pick a new server): "
        select action in "Create" "Check Status & Logs" "Start" "Stop" "Stop & Remove" "Upgrade" "Pick new server"; do
            case $action in
                "Create")
                    # Create server and run it
                    docker run -d --name=$db_server -h $db_server --restart always --network $db_network --ip $db_ip $image_id
                    echo "Created and running $db_server container"
                    ;;                    
                "Check Status & Logs")
                    # Output container status
                    STATUS=$(docker inspect -f '{{.State.Status}}' $db_server)
                    echo ""
                    echo "Server $db_server is $STATUS"
                    echo ""
                    docker logs $db_server
                    echo ""
                    ;;
                "Start")
                    docker start $db_server
                    echo "Started $db_server container"
                    ;;
                "Stop")
                    docker stop $db_server
                    echo "Stopped $db_server container"
                    ;;
                "Stop & Remove")
                    docker stop $db_server
                    echo "Stopped $db_server container"
                    docker rm $db_server
                    echo "Removed $db_server container"
                    ;;
                "Upgrade")
                    echo "Upgrade option not available at this time"
                    ;;
                "Pick new server")
                    previousPrompt
                    break
                    ;;
            esac
        done
    fi
done