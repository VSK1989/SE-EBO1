#!/bin/bash
# Version 1.1

# Declare variables returned from createServerVars function
declare -g server
declare -g repo
declare -g version_tag
declare -g network
declare -g ip
declare -g db_vol
declare -g db_folder
declare -g crash_folder
declare -g eula
declare -g ca_folder
declare -g dns_ip
declare -g graphdb_URL

# Reference script containing all functions
# shellcheck source=/dev/null
source ./functions.sh

# set path to YAML file
yaml_file=servers.yml

#parse yaml with yq and list networks
servers=$(yq '.servers[] | key' $yaml_file)
initPrompt "Which server do you want to manage? (Press ENTER to refresh) "
select server in $servers EXIT; do
    if [ "$server" == "EXIT" ]; then
        echo "Exiting the script"
        break
    else
        # Update variables required below based on selected server
        createServerVars $server $yaml_file
        # Compile optional arguments for Create Server command
        # CA Certificates Folder
        if [ "$ca_folder" == "null" ]; then
            ca_folders_command=""
        else
            # If defined, create $ca_folder to ensure it exists
            mkdir -p $ca_folder
            ca_folders_command="--mount type=bind,source=$ca_folder,target=/usr/local/share/ca-certificates "
        fi
        # DNS Server IP Address     
        if [ "$dns_ip" == "null" ]; then
            dns_ip_command=""
        else
            dns_ip_command="--dns $dns_ip "
        fi
        # GraphDb Server URL
        if [ "$graphdb_URL" = "null" ]; then
            graphdb_URL_command=""
        else
            if [[ $graphdb_URL =~ ^(http|https)://[^/]+:[0-9]+ ]]; then
                graphdb_URL_command="-e Semantic_Db_URL=$graphdb_URL"
            else
                # Check if $graphdb_URL matches the name of a semanticDbs in servers.yml and returns expected repo name
                graphdb_URL_repo=$(yq .semanticsDbs.$graphdb_URL.repository $yaml_file)
                if [  $graphdb_URL_repo == "ontotext/graphdb" ]; then
                    # Generate URL from ip and port values
                    graphdb_ip=$(yq .semanticsDbs.$graphdb_URL.ip $yaml_file)
                    graphdb_port=$(yq .semanticsDbs.$graphdb_URL.port $yaml_file)
                    graphdb_URL="http://$graphdb_ip:$graphdb_port"
                    graphdb_URL_command="-e Semantic_Db_URL=$graphdb_URL"
                else
                    echo "Invalid graphdb_URL: $graphdb_URL"
                    exit 1
                fi
            fi
        fi
        optional_arguments="$ca_folders_command $dns_ip_command $graphdb_URL_command"
        echo "Optional Arguements: $optional_arguments"
        # Ensure container has been pulled
        docker pull $repo:$version_tag
        image_id=$(docker images --filter=reference=$repo:$version_tag --format "{{.ID}}")
        #
        # Select action to manage the selected server
        updatePrompt "Which action do you want to execute? (Enter to refresh, Type 9 to pick a new server): "
        select action in "Create" "Check Status" "Start" "Stop" "Stop & Remove" "Stop & Delete" "Password Reset" "Upgrade" "Pick new server"; do
            case $action in
                "Create")
                    # Create server and run it
                    docker run -d --name=$server -h $server --ulimit core=-1 --restart always --network $network --mount type=bind,source=$crash_folder,target=/var/crash -e NSP_ACCEPT_EULA=$eula --ip $ip --mount source=$db_vol,target=/var/sbo $optional_arguments $image_id
                    echo "Created and running $server container"
                    ;;                    
                "Check Status")
                    # Output container status
                    STATUS=$(docker inspect -f '{{.State.Status}}' $server)
                    echo "Server $server is $STATUS"
                    ;;
                "Start")
                    docker start $server
                    echo "Started $server container"
                    ;;
                "Stop")
                    docker stop $server
                    echo "Stopped $server container"
                    ;;
                "Stop & Remove")
                    docker stop $server
                    echo "Stopped $server container"
                    docker rm $server
                    echo "Removed $server container, but volume/database $db_vol remains"
                    ;;
                "Stop & Delete")
                    echo "WARNING: This will remove $server container and DELETE the $db_vol database"
                    read -r -p "Are you sure? [y/N] " confirm
                    case $confirm in
                        [yY][eE][sS]|[yY])
                            docker stop $server
                            echo "Stopped $server container"
                            docker rm -v $server
                            echo "Removed $server container"
                            docker volume rm $db_vol
                            echo "Volume/database $db_vol has been DELETED"
                            ;;
                        *)
                            echo "Deletion was declined."
                            break
                            ;;
                    esac
                    ;;
                "Password Reset")
                    echo "Starting temporary container to reset password"
                    docker run --rm --mount source=$db_vol,target=$db_folder $image_id bash -c "mkdir -p /var/sbo/db/reset && touch /var/sbo/db/reset/r0.txt"
                    echo "Password reset complete"
                    ;;
                "Upgrade")
                    # Request upgrade version and verify image with that version can be pulled

                    # Code requires a personal access token to be created via a GitHub account.
                    # The token needs to be a "Token (Classic)" and just needs "read:packages" permission.

                    tags_available=$(curl -s -H "Authorization: Bearer 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" -H "Accept: application/vnd.github+json" -H "X-GitHub-Api-Version: 2022-11-28" https://api.github.com/orgs/SchneiderElectricBuildings/packages/container/ebo-edge-server/versions | jq -r '.[0].metadata.container.tags[]')
                    updatePrompt "Please enter the version number you want to upgrade to:"
                    select upgrade_version in $tags_available; do
                        echo "You have entered: $upgrade_version."
                        previousPrompt
                        break
                    done
                    # Pull container
                    echo "Pulling new container $repo:$upgrade_version"
                    docker pull $repo:$upgrade_version
                    # Stop running container
                    echo "Stopping $server"
                    docker stop $server
                    # Remove container
                    echo "Removing $server container"
                    docker rm $server
                    # Prepare volume for upgrade
                    echo "Prepping $db_vol for upgrade of $server"
                    docker run --rm --mount source=$db_vol,target=var/sbo $image_id /opt/sbo/bin/prepare-upgrade
                    # Start new container with new version image with pre-upgraded volume
                    echo "Acquiring Image ID, creating $server container, and starting it."
                    image_id_upgrade=$(docker images --filter=reference=$repo:$upgrade_version --format "{{.ID}}")
                    docker run -d --name=$server -h $server --ulimit core=-1 --restart always --network $network --mount type=bind,source=$crash_folder,target=/var/crash -e NSP_ACCEPT_EULA=$eula --ip $ip --mount source=$db_vol,target=/var/sbo $image_id_upgrade
                    # Update Version in yaml file for the selected server
                    echo "Updated yml file for $server to set version equal to $upgrade_version"
                    eval "yq -i eval '.servers.$server.version = \"$upgrade_version\"' $yaml_file"
                    ;;
                "Pick new server")
                    previousPrompt
                    break
                    ;;
            esac
        done
    fi
done