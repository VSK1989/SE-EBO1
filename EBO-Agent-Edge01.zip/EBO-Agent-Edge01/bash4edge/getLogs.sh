#!/bin/bash
# Version 1.1

# Reference script containing all functions
# shellcheck source=/dev/null
source ./functions.sh

# set path to YAML file
yaml_file=servers.yml

#parse yaml with yq and list servers
servers=$(yq '.servers[] | key' $yaml_file)
initPrompt "Which server do you want to collect logs? "
select server in $servers NONE; do
    if [ -n "$server" ]; then
        if [ "$server" == "NONE" ]; then
            echo "Skipping retrieving logs"
            break
        else
            echo "You selected to retrieve logs from $server"
            # Get the working_dir from the YAML file
            local_dest=$(yq .servers.$server.working_dir $yaml_file)
            # Construct the full directory path and eval echo in case used ~ 
            local_logs=$(eval echo "$local_dest/$server/Logs")
            # Create the directory
            mkdir -p $local_logs
            #get trace logs
            docker cp $server:/var/sbo/db/logs/trace.log $local_logs
            docker cp $server:/var/sbo/db/logs/trace.log.old $local_logs 2>/dev/null  #Suppressed error in case files does not exist
            #get system log
            docker logs $server > $local_logs/docker.system.log 2>/dev/null  #Suppressed error in case files does not exist
            continue
        fi
    else
        echo "Invalid option. Please try again."
    fi
done