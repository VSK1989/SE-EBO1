#!/bin/bash
# Version 1.1

# Declare variables returned from createServerVars function
declare -g server
declare -g repo
declare -g version_tag
declare -g db_vol
declare -g server_backups
declare -g local_backups

# Reference script containing all functions
# shellcheck source=/dev/null
source ./functions.sh

# set path to YAML file
yaml_file=servers.yml

#parse yaml with yq and list servers
servers=$(yq '.servers[] | key' $yaml_file)

initPrompt "Which server do you want to work on? (Enter to refresh) "
select server in $servers NONE; do
    if [ -n "$server" ]; then
        if [ "$server" == "NONE" ]; then
            echo "Exiting the script"
            break
        else
            #Setup all variables based on the server selected
            createServerVars $server $yaml_file
            image_id=$(docker images --filter=reference=$repo:$version_tag --format "{{.ID}}")
            #Request and execute action
            updatePrompt "Which action do you want to execute? (Enter to refresh or 4 to select another server)"
            select option in "List Backups" "Copy Backup" "Restore Backup" "Select another server"; do
                if [ -n "$option" ]; then
                    if [ "$option" == "Select another server" ]; then
                        echo "Going back to select a server."
                        previousPrompt
                        break
                    else
                        case $option in
                            "List Backups")
                                echo "Backups on $server are:"
                                docker exec -it $server sh -c "ls $server_backups | tr -d '\"'"
                                ;;
                            "Copy Backup")
                                echo "Backups copied from $server to $local_backups"
                                mkdir -p $local_backups
                                docker cp $server:$server_backups/. $local_backups  #/. added to just copy file(s) and not the LocalBackup folder
                                ;;
                            "Restore Backup")
                                # Request user ensure backup is in server backup folder
                                echo "Please ensure backups are located in $local_backups"
                                mkdir -p $local_backups
                                read -r -p "---When ready, press Enter to continue---" </dev/tty
                                # Ask user to select an .xbk file
                                updatePrompt "Select the .xbk file to restore, or 0 to exit: "
                                select file in $local_backups/*xbk; do
                                    if [ $file == "0" ]; then
                                        echo "Exiting to select an action"
                                        exit
                                    elif [[ -z $file ]]; then
                                        echo "Invalid option. Please try again."
                                    else
                                        break
                                    fi
                                done
                                # Ask user for restore type and confirm
                                initPrompt "Select restore type:"       #initPrompt instead of updatePrompt because do not need to return to previous after this.
                                select restore_type in "AllData" "ConfigurationOnly"; do
                                    echo "Restore is set for -- $restore_type --"
                                    read -p "Are you sure? [y/N] " -r
                                    if [[ $REPLY =~ ^[Yy]$ ]]
                                    then
                                        break
                                    else
                                        continue
                                    fi
                                done
                                #Copy xbk to server volume
                                echo "Copying $file to $server"
                                # echo "docker run --rm --mount type=bind,source=$local_backups,target=/mnt --mount source=$db_vol,target=/var/sbo $image_id bash -c "cp '/mnt/$file' /var/sbo/db_backup/LocalBackup/""
                                docker run --rm --mount type=bind,source=$local_backups,target=/mnt --mount source=$db_vol,target=/var/sbo $image_id bash -c "cp '/mnt/$file' /var/sbo/db_backup/LocalBackup/"
                                # Prepare restore
                                echo "Running prepare upgrade with $restore_type option"
                                #echo "docker run --rm --mount source=$db_vol,target=/var/sbo $image_id /opt/sbo/bin/prepare-restore $file $restore_type"
                                docker run --rm --mount source=$db_vol,target=/var/sbo $image_id /opt/sbo/bin/prepare-restore $file $restore_type
                                # Restart server
                                echo "docker restart $server"
                                docker restart $server
                                echo "$file has been copied to $server and that server has been restarted to restore $restore_type"
                                previousPrompt
                                ;;
                        esac
                    fi
                fi
            done
        fi
    fi
done