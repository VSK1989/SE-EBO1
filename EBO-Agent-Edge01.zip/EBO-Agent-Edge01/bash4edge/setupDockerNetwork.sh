#!/bin/bash
# Version 1.1

# Reference script containing all functions
# shellcheck source=/dev/null
source ./functions.sh

# set path to YAML file
yaml_file=servers.yml

initPrompt "Choose option for Docker Networks (Enter to refresh, Type 3 to exit): "
select option in "Get Local Adapter settings" "Create Docker Network" NONE; do
    if [ -n "$option" ]; then
        if [ "$option" == "NONE" ]; then
            echo "Exiting the script."
            break
        else
            case $option in
                "Get Local Adapter settings")
                    #find local adapter
                    local_adapter=$(ip route get 8.8.8.8 | awk '{printf $5}')
                    echo " "
                    echo "  - Local adapter is: $local_adapter"
                    # Get the local gateway for the adapter
                    local_gateway=$(ip route show dev $local_adapter | awk '$1 == "default" {print $3}')
                    echo "  - Local gateway is: $local_gateway"
                    # Get the local subnet for the adapter
                    local_ip_cidr=$(ip addr show dev $local_adapter | awk '$1 == "inet" {print $2}')
                    local_subnet_cidr=$(ipcalc $local_ip_cidr | awk '/Network:/ {print $2}')
                    echo "  - Local subnet in CIDR format is: $local_subnet_cidr"
                    echo " "
                    #update yaml assigning local adapter to the chosen network interface
                    networks=$(yq '.networks[] | key' $yaml_file)
                    updatePrompt "Which network needs the interface updated? "
                    select network in $networks NONE; do
                        if [ -n "$network" ]; then
                            if [ "$network" == "NONE" ]; then
                                echo "Skipping update"
                                break
                            else
                                echo "You selected $network"
                                eval "yq -i eval '.networks.$network.subnet = \"$local_subnet_cidr\"' $yaml_file"
                                eval "yq -i eval '.networks.$network.gateway= \"$local_gateway\"' $yaml_file"
                                eval "yq -i eval '.networks.$network.interface = \"$local_adapter\"' $yaml_file"
                                break
                            fi
                        else
                            echo "Invalid option. Please try again."
                        fi  
                    done
                    previousPrompt
                    ;;
                "Create Docker Network")
                    #parse yaml with yq and list networks
                    networks=$(yq '.networks[] | key' $yaml_file)
                    updatePrompt "Which network do you want to use to create the docker network? "
                    select network in $networks NONE; do
                        if [ -n "$network" ]; then
                            if [ "$network" == "NONE" ]; then
                                echo "Skipping defining docker network"
                                break
                            else
                                echo "You selected $network to be created."
                                #get values for selected network
                                createNetworkVars $network $yaml_file
                                docker network create --driver $network_type --subnet $subnet --gateway $gateway -o parent=$interface $network
                                echo "Network $network has been created."
                                break
                            fi
                        else
                            echo "Invalid option. Please try again."
                        fi
                    done
                    previousPrompt
                    ;;
            esac
        fi
    else
        echo "Invalid option, please try again"
    fi
done