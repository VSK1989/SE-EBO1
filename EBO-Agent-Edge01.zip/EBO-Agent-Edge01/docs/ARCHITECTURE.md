# Architecture & Module Reference

## Architecture Diagram

![EBO Docker Agent Cross-Platform Architecture](architecture-diagram.png)

The diagram shows the full workflow: a single shared `config/servers.yml`
feeds BOTH the Python agent (Path A — Windows/Linux/WSL) and the Bash4Edge
toolkit (Path B — Ubuntu/Linux), each of which talks to its own Docker
Engine instance using an OS-appropriate network strategy, and both of
which produce the same kind of diagnostic output.

## Design goals

- **Zero-install plug-and-play**: only the Python standard library is used
  on the Python side (no PyYAML, no `docker` PyPI SDK); Bash4Edge uses only
  `bash`, `yq`, `jq`, and the `docker` CLI — nothing else.
- **One configuration file, two platforms**: `config/servers.yml` uses
  EXACTLY Bash4Edge's own schema (`repos`, `networks`, `semanticsDbs`,
  `serverSettings`, `servers`), plus one new, optional, Python-agent-only
  `agentSettings` section that Bash4Edge's scripts simply never look up.
  The same file can be copied into `bash4edge/servers.yml` unmodified.
- **Automatic, cross-platform host detection**: the agent detects Windows,
  native Linux, WSL, or macOS at runtime and adapts its Docker networking
  strategy, bind-mount path format, and default Downloads location
  accordingly — see `docs/ASSUMPTIONS.md` for the full rationale.
- **Built from reviewed source, not from scratch**: every module's
  docstring states whether its logic was ported from reviewed source,
  corrected against a second, independently-verified source, reconstructed
  from documented-but-unseen behaviour, or genuinely new. See
  `docs/SOURCE_FILES_REVIEW.md`.
- **Safe by default**: every mutating action supports `--dry-run`; the
  auto-remediation loop is opt-in (`monitor.auto_restart`, default `false`).
- **Transparent "AI"**: the decision engine is a small, readable rule
  table, not an opaque model.

## Module map — Path A (`agent/`)

| File | Purpose | Lineage |
|---|---|---|
| `run_agent.py` | Top-level launcher | New |
| `agent/agent.py` | CLI parsing + orchestration (incl. new `discover`/`validate`/`sync-ip`/`auto`) | New shell around ported/new logic |
| `agent/platform_utils.py` | **NEW.** OS detection, path translation (Windows↔WSL), network-strategy selection, cross-platform adapter auto-detection | New |
| `agent/yaml_mini.py` | **NEW.** Dependency-free YAML-subset parser + surgical single-line file patcher | New (reads the real servers.yml schema directly) |
| `agent/config.py` | Loads/validates `config/servers.yml` via yaml_mini.py | Rewritten this pass: now reads the real YAML schema instead of a JSON re-expression |
| `agent/logging_setup.py` | Console + rotating file logging | New (replaces print() in start.py/upgrade.py) |
| `agent/docker_tools.py` | Only module that calls the `docker` CLI; validation, cross-platform path normalisation, bounded retry | Ported from `start.py`; enhanced this pass with retry + path translation |
| `agent/discovery.py` | **NEW.** Cached container discovery, runtime IP lookup, IP-drift detection/auto-sync, TCP connectivity validation | New |
| `agent/container_manager.py` | start/stop/restart/upgrade/status/remove; OS-aware network strategy; name-or-IP resolution | Ported from `start.py` + `upgrade.py`; enhanced this pass for cross-platform networking |
| `agent/trace_tools.py` | Pull trace.log directly from a server's DB volume | PORTED, VERIFIED from `get-trace.log` |
| `agent/backup_tools.py` | list-backups/copy-backups/restore-backup | Corrected against verified `manageBackups.sh` |
| `agent/password_reset.py` | Password reset mode | PORTED, VERIFIED from `manageServers.sh` |
| `agent/graphdb_tools.py` | Semantics/GraphDB companion container | PORTED, VERIFIED command shape from `manageGraphDb.sh` |
| `agent/decision_engine.py` | Rule-based health evaluation incl. NEW "unreachable" state | Enhanced this pass with connectivity validation |
| `agent/log_collector.py` | Diagnostic snapshots (logs+inspect+health+trace) | Enhanced this pass for cross-platform output paths |
| `tests/*.py` | 120 unit tests (mocked/dry-run, no real Docker needed) | New |

## Path B — `bash4edge/`

The original, verified toolkit (`functions.sh`, `manageOS.sh`,
`setupDockerNetwork.sh`, `manageGraphDb.sh`, `manageServers.sh`,
`getLogs.sh`, `manageBackups.sh`, `dockerCommands.sh`) is unchanged,
byte-for-byte, from what was reviewed. **One new file was added**,
clearly labelled as new in its own header comment:

- `discoverConnectivity.sh` — the Bash-side equivalent of the Python
  agent's `discover`/`validate`/`sync-ip` commands: reports each
  configured server's existence/running state/configured-vs-runtime IP,
  validates TCP connectivity using bash's own `/dev/tcp` pseudo-device (no
  extra package needed), and can optionally auto-correct drifted IPs in
  `servers.yml` via the same `yq -i eval` pattern every other Bash4Edge
  script already uses.

`bash4edge/servers.yml` is now the SAME file as `config/servers.yml` (see
"one configuration file, two platforms" above).

## Data flow for `python run_agent.py auto`

```
agent.py (CLI)
  -> platform_utils.detect_os() / network_strategy()      # Step 1
  -> discovery.discover_servers(cfg)                        # Step 2
       -> docker_tools (cached ps -a / inspect)
  -> discovery.sync_ip_drift(cfg, auto_fix=...)              # Step 2b (optional)
       -> yaml_mini.update_scalar_in_file()                   # surgical, single-line edit
  -> discovery.validate_all(cfg)                               # Step 3
       -> discovery.validate_connectivity() (TCP connect test)
  -> monitor loop (decision_engine + log_collector)             # Step 4
```

## Data flow for `python run_agent.py start Edge01` (cross-platform branch)

```
agent.py -> container_manager.start()
  -> container_manager.resolve_target()      # accepts NAME or IP
  -> platform_utils.network_strategy()        # "ipvlan" (Linux/WSL) or
                                                 "bridge_ports" (Windows)
  -> container_manager.ensure_network()         # creates the right kind
  -> container_manager.build_run_command()       # static IP vs published ports
  -> docker_tools.run_container()                 # with bounded retry
```

## Why the network strategy differs by OS

readme.md's own instructions and Bash4Edge's `setupDockerNetwork.sh` both
assume native Linux Docker Engine, where an IPVLAN network can bind
directly to a real host network adapter. Docker Desktop for Windows runs
the daemon inside a hidden WSL2-based VM, where a real host NIC usually
isn't available for IPVLAN/MACVLAN to bind to. Rather than let this fail
with a non-obvious Docker error on Windows, `platform_utils.network_strategy()`
auto-selects a plain Docker bridge network with published ports on
Windows (reachable at `https://localhost:1443`), and the original
static-IP IPVLAN behaviour on Linux/WSL — overridable per
`agentSettings.network.force_strategy` in `config/servers.yml`.

## Why rule-based instead of ML/LLM-based

A rule table (`decision_engine.KNOWN_LOG_PATTERNS`) satisfies "simple,
lightweight, easy-to-maintain" directly: adding a new detection is a
one-line regex + advice string, with no model weights or extra runtime
dependency.
