# Architecture & Module Reference

## Design goals
- **Zero-install plug-and-play**: only the Python standard library is used
  (no PyYAML, no `docker` PyPI SDK).
- **Config-driven**: container name, IP, image, version, network, and log
  settings live in one JSON file (`config/servers.json`), not scattered
  across CLI flags.
- **Built from reviewed source, not from scratch**: every module's
  docstring states explicitly whether its logic was ported from reviewed
  source (and from WHICH of the two independent source sets), reconstructed
  from documented-but-unseen behaviour, or added as genuinely new
  functionality. See `docs/SOURCE_FILES_REVIEW.md` for the full
  traceability mapping.
- **Two complementary paths, one project**: Path A (this Python package,
  `agent/`, for Windows + Docker Desktop) and Path B (the `bash4edge/`
  folder, for a separate Ubuntu/Linux host over SSH) are bundled together,
  since both manage the same underlying EBO containers and you may use
  either depending on where a given server actually runs.
- **Safe by default**: every mutating action supports `--dry-run`; the
  auto-remediation loop is opt-in (`monitor.auto_restart`, default `false`).
- **Transparent "AI"**: the decision engine is a small, readable rule table,
  not an opaque model -- every recommendation can be traced to one `if`.

## Module map (Path A — `agent/`)

| File | Purpose | Lineage | Talks to | Configuration it reads |
|---|---|---|---|---|
| `run_agent.py` | Top-level launcher | New | `agent.agent` | — |
| `agent/agent.py` | CLI parsing + orchestration | New (CLI shell around ported/reconstructed logic) | all other `agent.*` modules | `config/servers.json` |
| `agent/config.py` | Loads/validates `config/servers.json` | Re-expression of Bash4Edge's `servers.yml` | — | `config/servers.json` |
| `agent/logging_setup.py` | Console + rotating file logging | New (replaces print() in start.py/upgrade.py) | — | — |
| `agent/docker_tools.py` | Only module that calls the `docker` CLI; input validation; dry-run support | Ported from `start.py` (`exe`, `_validate_arg`); `get-trace.log`'s ephemeral-container pattern generalised here; `teststart.py` reviewed, not reused | Docker CLI | — |
| `agent/container_manager.py` | start/stop/restart/upgrade/status/remove; `docker run` construction; `--test-mode` | Ported from `start.py` + `upgrade.py`; test-mode from readme.md's port-forwarding example | `docker_tools.py` | server + network + defaults sections |
| `agent/trace_tools.py` | Pull trace.log directly from a server's DB volume | **PORTED, VERIFIED** from `get-trace.log` | `docker_tools.py` | defaults.db_folder/db_vol_suffix |
| `agent/backup_tools.py` | list-backups/copy-backups/restore-backup equivalents | Reconstructed from readme.md, corrected against verified `manageBackups.sh` | `docker_tools.py` | defaults.db_folder |
| `agent/password_reset.py` | Password reset mode | **PORTED, VERIFIED** from `manageServers.sh`'s "Password Reset" case | `docker_tools.py` | defaults.db_vol_suffix/db_folder |
| `agent/graphdb_tools.py` | Semantics/GraphDB companion container management | **PORTED, VERIFIED** command shape from `manageGraphDb.sh`; usage context from readme.md | `docker_tools.py` | `graphdb_servers` section |
| `agent/decision_engine.py` | Rule-based health evaluation + optional auto-remediation | New (the "AI" layer; no equivalent in either source set) | `docker_tools.py`, `container_manager.py` | `monitor` section |
| `agent/log_collector.py` | Timestamped diagnostic snapshots to the Downloads folder (docker logs + inspect + health report + trace files) | New; integrates `trace_tools.py` | `docker_tools.py`, `trace_tools.py`, `decision_engine.py` | `log_collection` section |
| `tests/*.py` | Unit tests (mocked/dry-run, no real Docker needed) | New | all modules above | `config/servers.json` |
| `.vscode/*.json` | VS Code debug configs, tasks, recommended extensions, settings | New | — | — |

## Path B — `bash4edge/`

A self-contained copy of the Bash4Edge toolkit, unmodified from the
verified source reviewed in `docs/SOURCE_FILES_REVIEW.md` §3:
`functions.sh`, `manageOS.sh`, `setupDockerNetwork.sh`, `manageGraphDb.sh`,
`manageServers.sh`, `getLogs.sh`, `manageBackups.sh`, `dockerCommands.sh`,
its own `servers.yml`, and `README.md`. Intended to be copied onto a
separate Ubuntu/Linux machine and run there directly over SSH from VS
Code's Remote Explorer -- no Python required. See the companion
Installation Guide document for the full step-by-step (Stages 6-10).

## Data flow for `python run_agent.py monitor`

```
agent.py (CLI)
  -> config.load_config()                       # read servers.json once
  -> loop over each configured server:
       decision_engine.decide_and_act()
         -> docker_tools.inspect_container/get_logs   (read-only)
         -> [only if auto_restart=true] container_manager.restart()/start()
       log_collector.collect_one()
         -> docker_tools.get_logs / inspect_container   (read-only)
         -> trace_tools.get_trace()                     (best-effort, via
                                                          ephemeral container)
         -> decision_engine.evaluate()                  (embed health report)
         -> writes files to <Downloads>/<container>/<timestamp>/
  -> sleep(poll_interval_seconds); repeat until Ctrl+C or --once
```

## Data flow for `python run_agent.py restore-backup Edge01 <ver> <backup> <mode> --from-host <path>`

```
agent.py (CLI)
  -> backup_tools.restore_backup()
       -> docker_tools.run_ephemeral_against_volume()   # copy host file into
                                                           the volume (NOT
                                                           docker cp against a
                                                           live container --
                                                           matches verified
                                                           manageBackups.sh)
       -> docker_tools.exe(ephemeral `docker run --rm --mount ...
          /opt/sbo/bin/prepare-restore <backup> <mode>`)
       -> docker_tools.restart_container()                # no stop first,
                                                            matching verified
                                                            source exactly
```

## Data flow for `python run_agent.py password-reset-mode Edge01`

```
agent.py (CLI)
  -> password_reset.set_password_reset_mode()
       -> docker_tools.run_ephemeral_against_volume(
            shell_command="mkdir -p .../db/reset && touch .../db/reset/r0.txt"
          )
       # that's it -- no stop, no restart; matches verified manageServers.sh
```

## Why rule-based instead of ML/LLM-based

You asked explicitly for "simple, lightweight, and easy-to-maintain."
A rule table (`decision_engine.KNOWN_LOG_PATTERNS`) satisfies this directly:
adding a new detection is a one-line regex + advice string, with no model
weights, prompts, tokens, or extra runtime dependency. See
`docs/ASSUMPTIONS.md` item 7 if you'd prefer an LLM-driven version instead.
