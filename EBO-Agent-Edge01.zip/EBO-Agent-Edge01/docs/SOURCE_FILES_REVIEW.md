# Source Files Review — Traceability Across All Enhancement Passes

This document tracks, honestly and in full, where every piece of this
project's logic came from, across all three build passes: (1) the initial
Windows/Python agent, (2) the Bash4Edge merge and correction pass, and (3)
**this pass**: cross-platform support, automatic discovery, and
performance/architecture enhancements. Original files remain preserved
byte-for-byte under `reference/original-uploaded-files/`.

---

## Pass 3 (this pass): Cross-Platform & Auto-Discovery Enhancement

### What was requested
Cross-platform support (Windows Docker Desktop + Ubuntu/Linux), direct
`servers.yml` integration with automatic container/IP discovery, dynamic
IP-change handling, Bash4Edge parity, performance optimisation, and a
genuinely plug-and-play deployment model.

### What was built, and why

| Addition | Why it was necessary |
|---|---|
| `agent/platform_utils.py` | Centralises ALL OS-specific logic in one place. Previously, the project silently assumed Linux-style IPVLAN networking would work identically on Windows Docker Desktop — it does not, because Docker Desktop's daemon runs inside a hidden WSL2 VM with no host NIC reliably exposed for IPVLAN/MACVLAN binding. This module detects the host OS and auto-selects the correct network strategy (`ipvlan` on Linux/WSL, `bridge_ports` with published ports on Windows), auto-translates Windows↔WSL paths, and re-implements Bash4Edge's own "Get Local Adapter Settings" adapter-detection feature in a cross-platform way. |
| `agent/yaml_mini.py` | Required to fulfil "servers.yml Integration" WITHOUT reintroducing a PyYAML dependency (the project's zero-dependency principle predates this pass and was kept). A small, dependency-free parser, tailored exactly to servers.yml's real shape, plus a surgical single-line patcher used for automatic IP-drift correction (mirroring Bash4Edge's own `yq -i eval` in-place-edit style — every comment and unrelated line is preserved). |
| `agent/discovery.py` | The engine behind "automatically discover and configure IP addresses," "validate connectivity," "handle dynamic IP changes," and "faster container discovery." Introduces a short-lived, explicit cache for the two most expensive, most frequently repeated Docker calls (`docker ps -a`, `docker inspect`), directly reducing subprocess overhead versus the previous per-check-per-server pattern. |
| `agent/config.py` (rewritten) | Now reads `config/servers.yml` directly — literally the SAME schema and, if copied, the SAME file Bash4Edge itself uses — instead of a JSON re-expression. This is the heart of "Simplified configuration management": one file, one schema, two platforms. |
| `agent/container_manager.py` (enhanced) | Added `resolve_target()` (accept a configured NAME or an IP address — "support both container names and IP addresses"), and OS-aware `build_run_command()`/`ensure_network()` (the cross-platform networking fix described above). |
| `agent/docker_tools.py` (enhanced) | Added a narrow, bounded retry for genuinely transient Docker-daemon errors ("better error handling and recovery"), and routes every bind-mount source path through `platform_utils.normalize_bind_source()`. |
| `agent/decision_engine.py` (enhanced) | Added a new `"unreachable"` state: a container can be "running" per Docker yet not actually answering network traffic (e.g. after IP drift) — previously invisible to the health check, now surfaced explicitly via `discovery.validate_connectivity()`. |
| `bash4edge/discoverConnectivity.sh` (NEW file) | Extends the exact same discover/validate/sync-ip capability to the Bash4Edge side, using only `yq`, `docker`, and bash's own `/dev/tcp` pseudo-device (no new package dependency), satisfying "Bash4Edge Compatibility." The eight ORIGINAL, verified Bash4Edge scripts are untouched. |
| `agent.py`'s new `discover` / `validate` / `sync-ip` / `auto` commands | `auto` is the single, one-shot "plug-and-play" command: load config → discover → validate connectivity → (optionally sync IPs) → start monitoring — the complete answer to "a new user should only need to install Docker, configure servers.yml, launch VS Code." |

### Real bugs found and fixed DURING this pass (via the 120-test suite)

Being transparent about defects this enhancement work itself introduced,
then caught and fixed, rather than only listing things that went smoothly:

1. **yaml_mini empty-value bug**: `ca_folder:` (a null scalar) was
   initially parsed as an empty dict `{}` instead of `None`, because the
   parser optimistically treats any `key:` with nothing after the colon as
   "might become a nested mapping." Fixed with a post-processing pass that
   collapses any dict left with zero keys back to `None` — this schema
   never legitimately uses empty mappings, so the collapse is always
   correct here. Caught by `test_config.test_optional_fields_are_none_not_empty_dict`.
2. **Crash-folder force-mount bug**: an early version of the cross-platform
   `build_run_command()` logic mistakenly mounted `/var/crash` on every
   Linux-like host regardless of whether that path actually existed on the
   host, which would reintroduce the EXACT `bind source path does not
   exist: /var/crash` error Bash4Edge's own Known Issues table warns
   about. Fixed to match `start.py`'s original `os.path.exists()` check
   exactly, with no platform-based override. Caught by
   `test_container_manager.test_crash_folder_not_mounted_when_path_does_not_exist`.
3. **accept_eula boolean-vs-string bug**: `yaml_mini` (correctly) parses
   YAML 1.1's `Yes`/`No` as Python booleans, matching what a real `yq`
   would do — but `NSP_ACCEPT_EULA` needs the literal string `"Yes"`, not
   Python's `str(True)` ("True") or a lower-cased `"true"`. A small,
   explicit conversion (`_eula_str()`) in `agent/config.py` restores the
   exact string Docker needs. Caught by
   `test_config.test_accept_eula_is_literal_yes_string_not_bool`.

### Pass-3 lineage status summary

| Module | Status |
|---|---|
| `platform_utils.py` | NEW |
| `yaml_mini.py` | NEW |
| `discovery.py` | NEW |
| `config.py` | REWRITTEN (same public API, new file format/schema) |
| `container_manager.py` | ENHANCED (cross-platform network strategy, name/IP resolution) |
| `docker_tools.py` | ENHANCED (retry, path normalisation) |
| `decision_engine.py` | ENHANCED (connectivity-aware "unreachable" state) |
| `log_collector.py` | ENHANCED (cross-platform default output path) |
| `backup_tools.py`, `password_reset.py`, `trace_tools.py`, `graphdb_tools.py` | UNCHANGED logic, updated only to accept name-or-IP via `resolve_target()` |
| `bash4edge/discoverConnectivity.sh` | NEW (all 8 original scripts untouched) |

---

## Pass 1 & 2 summary (full detail preserved from earlier builds)

### Set A — Windows/Python scripts (`reference/original-uploaded-files/windows-python-agent/`)

| File | What it contains | What we did with it |
|---|---|---|
| `readme.md` | Official image readme: Network (IPvlan), EULA, Start/Upgrade, Backup management (usage only), CA certificates, Proxy, Crash dumps, DNS, Password Reset Mode, useful docker commands (incl. a port-forwarding test example), GraphDB. | Functional specification for the whole Path A agent. |
| `start.py` | argparse script; builds `docker run` as a LIST; `_validate_arg()` whitelist; `_is_legacy_ca_folder_version()`. | Primary source for `container_manager.py` / `docker_tools.py`. |
| `teststart.py` | Shell-STRING variant, no input validation. | Reviewed, NOT reused. |
| `upgrade.py` | stop → prepare-upgrade → start-new → get-upgrade-log. | Primary source for `container_manager.upgrade()`. Note: the original mixes string- and list-based subprocess calls — this project does not replicate that inconsistency. |
| `get-trace.log` | A bash script (despite the .log extension) pulling trace logs from a named volume via a disposable `ubuntu:focal` container. | PORTED, VERIFIED → `trace_tools.py`. |
| `SECURITY.md`, `pr.yml` | Vulnerability-reporting pointer; GitHub repo-lockdown workflow. | Informational only. |

### Set B — Bash4Edge (`reference/original-uploaded-files/bash4edge/`)

All eight scripts plus `servers.yml` were reviewed as full, VERIFIED source
(not usage-only documentation):
`functions.sh`, `manageOS.sh`, `setupDockerNetwork.sh`, `manageGraphDb.sh`,
`manageServers.sh`, `getLogs.sh`, `manageBackups.sh`, `dockerCommands.sh`.

Two corrections made in Pass 2, once this verified source became
available (superseding earlier, readme.md-usage-only reconstructions):

1. **Password Reset** (`password_reset.py`) — corrected to match
   `manageServers.sh`'s real mechanism exactly: an ephemeral container
   touches a marker file inside the live volume; NO stop/restart occurs.
2. **Restore Backup** (`backup_tools.py`) — corrected to match
   `manageBackups.sh`'s real mechanism: a host-side backup file is copied
   in via an ephemeral bind+volume-mount container (not `docker cp`
   against a possibly-non-running container), and no explicit stop occurs
   before `prepare-restore` — only a `docker restart` at the end.

`agent/graphdb_tools.py`'s `create()` command was built to match
`manageGraphDb.sh`'s verified `docker run` flags exactly (confirmed: no
volume mount, no EULA env var for the GraphDB container specifically).

---

## Full mapping: source → module (all three passes)

```
start.py                    --> container_manager.py, docker_tools.py
teststart.py                 --> reviewed only, not reused
upgrade.py                    --> container_manager.upgrade()
get-trace.log                  --> trace_tools.py (PORTED, VERIFIED)
readme.md                       --> functional spec for config.py fields,
                                     container_manager.py, --test-mode
Bash4Edge manageServers.sh        --> password_reset.py (corrected, Pass 2)
Bash4Edge manageBackups.sh          --> backup_tools.py (corrected, Pass 2)
Bash4Edge manageGraphDb.sh            --> graphdb_tools.py (verified shape)
Bash4Edge functions.sh/servers.yml      --> config.py's schema (Pass 1: JSON
                                           re-expression; Pass 3: DIRECT,
                                           same-file unification)
Bash4Edge setupDockerNetwork.sh           --> platform_utils.get_local_adapter_info()
                                             (cross-platform re-implementation,
                                             Pass 3)
(no prior equivalent)                      --> decision_engine.py (Pass 1),
                                             discovery.py (Pass 3),
                                             platform_utils.py (Pass 3),
                                             yaml_mini.py (Pass 3),
                                             bash4edge/discoverConnectivity.sh
                                             (Pass 3)
```

See `docs/ARCHITECTURE.md` for the current module reference and diagram,
and `docs/ASSUMPTIONS.md` for every assumption made along the way.
