# Source Files Review — How Everything Was Read, Verified, and Merged

This document is the full traceability record: **every file you supplied
was opened and read, every GitHub page you pointed at was reviewed, and
every piece of this project is labelled according to how it was derived**
-- ported verbatim from reviewed source, cross-confirmed by an independent
second source, reconstructed from documented-but-unseen behaviour, or
genuinely new. Your original files are preserved, byte-for-byte, under
`reference/original-uploaded-files/` (split into two subfolders, since two
independent sets were supplied with some overlapping filenames -- see §1)
so you can diff them against the code at any time.

---

## 1. The two independent source sets you supplied

Across this project's history you uploaded TWO separate, independent sets
of files. They describe two DIFFERENT (but related) ways of managing the
same EBO Docker containers, and this review treats them as such rather
than merging their details carelessly:

| Set | Folder in this ZIP | What it is |
|---|---|---|
| **A. Windows/Python reference scripts** | `reference/original-uploaded-files/windows-python-agent/` | The official Docker image's own readme.md (`ghcr.io/schneiderelectricbuildings/...`) plus its Python helper scripts: `start.py`, `teststart.py`, `upgrade.py`, `get-trace.log` (a bash script despite the extension), `SECURITY.md`, `pr.yml`. |
| **B. Bash4Edge toolkit** | `reference/original-uploaded-files/bash4edge/` | An independent, community-built, Python-free Bash reimplementation of similar functionality for Ubuntu/Linux hosts: `functions.sh`, `manageOS.sh`, `setupDockerNetwork.sh`, `manageGraphDb.sh`, `manageServers.sh`, `getLogs.sh`, `manageBackups.sh`, `dockerCommands.sh`, its own `servers.yml`, and its own `readme.md`. |

**Important naming note:** both sets originally used the filenames
`readme.md` and `servers.yml` for their own, completely different,
documents. When the second set (A) was uploaded, it overwrote the first
set's (B's) same-named files in the shared uploads folder on disk. Set B's
original readme.md content had already been fully read and captured
earlier in this conversation, so it was faithfully reconstructed from that
earlier capture into `bash4edge/readme.md` -- its content is unchanged from
what was originally reviewed, just preserved under its own subfolder to
avoid any further collision.

---

## 2. Set A — Windows/Python scripts: file-by-file review

| File | What it contains | What we did with it |
|---|---|---|
| **readme.md** (243 lines, "Schneider Electric EcoStruxure Building Operation") | The OFFICIAL image readme: How to use this image, Network (IPvlan + `./create-bridged-network`), EULA, Start (`start.py`), Upgrade (`upgrade.py`), Backup management (`list-backups`/`copy-backups`/`restore-backup` -- usage only, source not included), CA certificates (bundle vs. legacy folder, version-aware), Proxy, "In case of crash" (host-level kernel.core_pattern/apport/limits.conf setup), DNS, Password Reset Mode, "A few useful docker commands" (including a port-forwarding test/quick-start example), GraphDB (`./start-graphdb`, usage only). | Used as the **functional specification** for the whole Windows-side (Path A) agent. Every section maps to a module or a config field -- see the full mapping table in §4. |
| **start.py** (176 lines) | argparse-based script. Builds a `docker run` command as a Python **list** (`cmd = ['docker', 'run', ...]`). Contains `_validate_arg()`, a whitelist-regex security check (`r'[A-Za-z0-9._:/@=\-]+'`, called on `--name`, `--version`, `--ip`, `--type`, `--accept-eula`, `--graphdb`, `--dns`, and whichever of `--ca-folder`/`--ca-bundle` applies -- but **not** on the three proxy flags). Contains `_is_legacy_ca_folder_version()`, a version-number check (`int(first_number) < 8`) deciding whether `--ca-folder` (legacy) or `--ca-bundle` (8.0+) is required, and raises `SystemExit` if the wrong one is supplied. | **Primary, line-by-line source for `agent/container_manager.py` and `agent/docker_tools.py`.** Every flag in `build_run_command()` is ported in the same order as the original `cmd` list, including the CA-bundle-vs-legacy-folder branch and the host-env-var proxy fallback. `_validate_arg()` was ported as `docker_tools.validate_token()`, with two deliberate, documented widenings (see §5). |
| **teststart.py** (95 lines) | An earlier/alternate version that builds the docker command as a single **shell string** (`cmd = f'docker run ... '`) and re-splits it with `shlex.split()` inside `exe()`. Has **no** `_validate_arg()` whitelist check at all. | **Reviewed, explicitly NOT reused.** Building one long shell string without any input validation is strictly more injection-prone than `start.py`'s list-based, validated approach. This project standardises on `start.py`'s pattern everywhere; the decision is documented in `agent/docker_tools.py`'s module docstring. |
| **upgrade.py** (24 lines) | Imports `get_arguments`/`exe` from `start.py`. Stops the old container, runs an ephemeral `docker run --rm --mount ...` container invoking `/opt/sbo/bin/prepare-upgrade`, re-invokes `start.py` via `sys.argv` manipulation, then runs another ephemeral container for `/opt/sbo/bin/get-upgrade-log`. | **Primary source for `container_manager.upgrade()`.** Same stop → prepare-upgrade → start-new → get-upgrade-log sequence, driven by `config/servers.json` instead of re-parsing `sys.argv`. **An inconsistency was observed and is called out, not silently fixed**: `upgrade.py` calls `exe('docker inspect ' + name + ...)` with a **STRING**, but `start.py`'s own `exe(cmd)` does `subprocess.check_output(cmd)` expecting a **LIST** -- this is a latent bug in the supplied reference code itself (presumably left over from an earlier, `teststart.py`-style version of `exe()`). This project's `docker_tools.exe()` is list-based and validated throughout, consistently, avoiding this inconsistency entirely. |
| **get-trace.log** (14 lines) | Despite its `.log` extension, this is a **bash script**. Runs a disposable `ubuntu:focal` container, bind-mounting a destination folder to `/mnt` and the server's named database volume (`<name>-db`) to `/var/sbo`, then runs `cp /var/sbo/db/logs/trace* /mnt/` inside it. Works even if the actual EBO server container has been stopped or removed, since it only needs the **volume** to still exist. | **Ported verbatim, verified.** This is the direct source for the new `agent/trace_tools.py` module and for `docker_tools.run_ephemeral_against_volume()`, a generalised version of the exact `docker run --rm --mount ... --mount ...` invocation shown here. Exposed via the new `get-trace` CLI command. |
| **SECURITY.md** | Points to Schneider Electric's vulnerability-reporting portal. | Informational only; reproduced as-is. Not applicable to re-implement in code. |
| **pr.yml** | A GitHub Actions workflow ("Repo Lockdown") that auto-closes issues/PRs on the upstream repository. | Informational only -- this is a GitHub-repo-maintenance workflow for the vendor's repo, not something a local agent needs. Reproduced as-is for completeness. |

---

## 3. Set B — Bash4Edge toolkit: file-by-file review

All eight scripts plus `servers.yml` were reviewed as **full, verified
source** (not usage-only documentation). This matters: wherever Set A's
readme.md only *documented the usage* of a script (e.g. restore-backup,
password-reset-mode) without showing its source, Set B's independently
verified scripts were used to confirm or correct the exact mechanism.

| File | What it contains | What we did with it |
|---|---|---|
| **functions.sh** | Shared helper functions: `initPrompt`/`updatePrompt`/`previousPrompt` (menu navigation), `checkDefaultSettings`/`createServerVars`/`createGraphDbVars`/`createNetworkVars` (reading `servers.yml` via `yq`, with per-server overrides falling back to shared defaults), and `hardenOpenSSH` (SSH hardening applied when `manageOS.sh`'s "Install SSH Server" option is used). | Confirms the exact shared-defaults-with-per-server-override pattern already used by `agent/config.py` (ported originally from the same `servers.yml` shape). The SSH-hardening details informed `docs/ASSUMPTIONS.md`'s Path B guidance. |
| **manageOS.sh** | Menu: Install Required Apps (curl, ipcalc, jq, yq), Update Ubuntu (apt update/upgrade, snap refresh), Install Docker (removes old packages, installs via get.docker.com), Ensure user has docker permissions (adds user to `docker` group), Install SSH Server (installs openssh-server, calls `hardenOpenSSH`). | Bundled unmodified into `bash4edge/` (Path B). Documented step-by-step in the Installation Guide's Stage 8.1. |
| **setupDockerNetwork.sh** | Menu: Get Local Adapter Settings (auto-detects adapter/gateway/subnet via `ip route`/`ipcalc`, writes them into `servers.yml`), Create Docker Network (`docker network create --driver ipvlan ...`). | Confirms `container_manager.ensure_network()`'s `docker network create -d ipvlan --subnet ... --gateway ... -o parent=...` command shape is correct (same flags, same driver). |
| **manageGraphDb.sh** | Menu: Create (`docker run -d --name=$db_server -h $db_server --restart always --network $db_network --ip $db_ip $image_id` -- **no volume mount, no env vars**), Check Status & Logs, Start, Stop, Stop & Remove, Upgrade (explicitly "not available at this time", pinned to GraphDB 10.2.4). | **Primary, verified source for the new `agent/graphdb_tools.py`.** The `create()` function's `docker run` command was copied flag-for-flag, including the absence of a volume mount (confirmed by reading the script directly, not assumed). |
| **manageServers.sh** | Menu: Create, Check Status, Start, Stop, Stop & Remove, Stop & Delete (with a `[y/N]` confirmation), **Password Reset** (`docker run --rm --mount source=$db_vol,target=$db_folder $image_id bash -c "mkdir -p /var/sbo/db/reset && touch /var/sbo/db/reset/r0.txt"` -- no stop/restart of the live container at all), Upgrade (lists GitHub Container Registry tags via a personal access token, pulls, stops, removes, prepares, re-creates, updates `servers.yml`). | **Corrected an earlier assumption.** An earlier draft of this project's `password_reset.py` assumed a stop→ephemeral-run→restart sequence modelled on `upgrade.py`. Reading `manageServers.sh`'s actual, verified "Password Reset" case directly showed this is **wrong** -- the real mechanism is far simpler: touch a marker file inside the live volume via a disposable container, and do nothing else. `agent/password_reset.py` was rewritten to match this exactly and is now marked **PORTED**, not reconstructed. |
| **getLogs.sh** | Creates a `Logs` folder under the server's working directory, copies `trace.log`/`trace.log.old` via `docker cp` against a **running** container, and saves `docker logs` output as `docker.system.log`. | Bundled unmodified into `bash4edge/`. Cross-referenced against `get-trace.log` (Set A) -- the two take different approaches (live `docker cp` vs. disposable-container-against-volume) for extracting the same trace files; `agent/log_collector.py` now uses BOTH: `docker logs`/`docker inspect` (matching this script's spirit) plus a trace-log pull via `agent/trace_tools.py` (matching `get-trace.log`'s more robust, volume-based approach). |
| **manageBackups.sh** | Menu: List Backups (`docker exec -it $server sh -c "ls $server_backups | tr -d '\"'"` where `$server_backups=/var/sbo/db_backup/LocalBackup`), Copy Backup (`docker cp $server:$server_backups/. $local_backups`), Restore Backup (copies the chosen `.xbk` file from the HOST backups folder into the volume via an ephemeral container bind+volume mount, then runs `/opt/sbo/bin/prepare-restore $file $restore_type` via another ephemeral container, then `docker restart $server` -- **no explicit stop beforehand**). | **Corrected `agent/backup_tools.py`.** An earlier draft used `docker cp` directly against a (possibly non-running) container for the "copy backup in from host" step. Reading this script's actual, verified approach showed it instead uses an ephemeral container with a bind-mount + volume-mount, which works whether or not the live server is running. `backup_tools.restore_backup()` was corrected to match this exactly, and -- just as importantly -- to **not** add an unsourced "stop first" step that the verified script does not perform. |
| **dockerCommands.sh** | A simple menu of Docker housekeeping one-liners (list containers, disk usage, prune images/volumes/everything). | Bundled unmodified into `bash4edge/`. Conceptually mirrored by `agent/docker_tools.py`'s existing wrappers on the Python side; no new module needed. |
| **servers.yml** | The Bash4Edge configuration schema: `repos`, `networks`, `semanticsDbs`, `serverSettings` (shared defaults), `servers` (with commented-out per-server override examples). Its own `Edge01` example used version `5.0.1.128` / IP `192.168.1.191` -- a DIFFERENT example from this project's actual target (`Edge01` / `hf-712-cp-2-5000-consolidation` / `192.168.10.1`), since Bash4Edge's own README predates this specific task's requirements. | Confirms, field-for-field, that `config/servers.json`'s schema (`repos`, `network`, `defaults`, `servers`, and the new `graphdb_servers` section mirroring `semanticsDbs`) is a faithful JSON re-expression. |

---

## 4. Full mapping: source → module

```
start.py                   --> agent/container_manager.py (build_run_command,
                                start, stop, restart, remove, status;
                                CA-bundle/legacy-folder branch;
                                proxy env-var fallback)
                            --> agent/docker_tools.py (exe, validate_token,
                                run_container)

teststart.py                --> reviewed only; NOT reused (unsafe
                                shell-string pattern, no validation)

upgrade.py                   --> agent/container_manager.py (upgrade)
                                [inconsistency noted: original mixes string
                                 and list subprocess calls -- not replicated]

get-trace.log                 --> agent/trace_tools.py (NEW, PORTED/VERIFIED)
                                --> agent/docker_tools.py
                                    (run_ephemeral_against_volume, generalised
                                     from this script's exact invocation)

readme.md (Set A) "Network"     --> agent/container_manager.py (ensure_network),
                                  docker_tools.py (create_ipvlan_network)
readme.md "EULA/Start"           --> agent/container_manager.py (start,
                                  build_run_command)
readme.md "Upgrade"               --> agent/container_manager.py (upgrade)
readme.md "Backup management"      --> agent/backup_tools.py
                                  [corrected against manageBackups.sh, see §3]
readme.md "CA certificates"         --> container_manager.py's CA-bundle /
                                  legacy-CA-folder branch (ported from
                                  start.py directly, confirmed by readme.md)
readme.md "Proxy"                    --> container_manager.py's proxy env-var
                                  fallback logic
readme.md "In case of crash"          --> docs/ASSUMPTIONS.md (host-level OS
                                  configuration notes; config/servers.json's
                                  defaults.crash_folder)
readme.md "DNS"                        --> config/servers.json defaults.dns,
                                  container_manager.build_run_command
readme.md "Password Reset Mode"         --> agent/password_reset.py
                                  [corrected against manageServers.sh, see §3]
readme.md "useful docker commands"      --> agent/docker_tools.py (get_logs,
                                  etc.); agent/log_collector.py (automates
                                  these); container_manager.py's --test-mode
                                  port-forwarding option (NEW, ported from the
                                  port-forwarding example shown in this
                                  section)
readme.md "GraphDB"                      --> agent/graphdb_tools.py (NEW)
                                  [command shape confirmed verified by
                                   manageGraphDb.sh, see §3]

SECURITY.md / pr.yml                      --> informational only, reproduced
                                  as-is

Bash4Edge functions.sh                     --> confirms config/servers.json's
                                  shared-defaults-with-overrides shape
Bash4Edge manageOS.sh                       --> bundled unmodified in
                                  bash4edge/ (Path B)
Bash4Edge setupDockerNetwork.sh               --> confirms
                                  container_manager.ensure_network()'s
                                  `docker network create` flags
Bash4Edge manageGraphDb.sh                     --> agent/graphdb_tools.py
                                  (NEW, PORTED/VERIFIED command shape)
Bash4Edge manageServers.sh "Password Reset"     --> agent/password_reset.py
                                  (corrected to match exactly, see §3)
Bash4Edge getLogs.sh                             --> cross-referenced by
                                  agent/log_collector.py
Bash4Edge manageBackups.sh                        --> agent/backup_tools.py
                                  (corrected to match exactly, see §3)
Bash4Edge dockerCommands.sh                        --> bundled unmodified in
                                  bash4edge/ (Path B)
Bash4Edge servers.yml                               --> confirms
                                  config/servers.json's schema

(no prior equivalent in either set)                  --> agent/decision_engine.py
                                  (NEW -- the rule-based "AI" health engine)
(no prior equivalent in either set)                   --> agent/log_collector.py
                                  (NEW -- automates log collection into your
                                  Downloads folder)
```

---

## 5. Deliberate, documented deviations from the source material

Being transparent about every place this project's code does NOT do
exactly what the original scripts did, and why:

| # | Deviation | Rationale |
|---|---|---|
| 1 | `docker_tools.validate_token()`'s whitelist regex is widened by two characters (comma, backslash) beyond `start.py`'s original `_validate_arg()`. | Comma is needed for legitimate comma-separated `no_proxy` host lists (which `start.py` never validates at all -- this project validates them too, more strictly than the original). Backslash is needed because this project targets Windows + Docker Desktop, where bind-mount source paths are naturally `C:\Users\...` rather than the Linux-style paths `start.py`'s own examples assume. Neither character enables shell injection in this project's list-based, `shell=True`-free subprocess calls. |
| 2 | `upgrade.py`'s observed string-vs-list `exe()` inconsistency is NOT replicated. | `agent/container_manager.upgrade()` uses list-based `docker_tools.exe()` calls consistently throughout, matching every other module in this project, rather than reproducing what appears to be an unintentional bug in the supplied reference code. |
| 3 | `agent/backup_tools.py` and `agent/password_reset.py` were corrected mid-project once Bash4Edge's verified source was available, replacing earlier reconstructions based only on readme.md's usage examples. | Verified source always takes precedence over inference from usage-only documentation. See §3 for exactly what changed and why. |
| 4 | `agent/graphdb_tools.create()` does not mount a database volume for the GraphDB container. | This exactly matches Bash4Edge's verified `manageGraphDb.sh`, which also does not mount one -- confirmed by direct reading, not assumed. |
| 5 | `container_manager.py`'s `--test-mode` flag (port-forwarding instead of a static IP) is new functionality. | Directly ported from readme.md's own documented example ("if you want to play with a server without the need to talk to devices"), not something either script set exposed as a formal flag. |

See `docs/ASSUMPTIONS.md` for the complete list of assumptions made where
neither source set gave an exact answer.
