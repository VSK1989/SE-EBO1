# Data Documentation

Describes every piece of data the agent reads, produces, or stores, after
the cross-platform / auto-discovery enhancement pass.

---

## 1. Input data: `config/servers.yml`

A real, plain-text YAML file (no JSON, no PyYAML), parsed by
`agent/yaml_mini.py`. Same file can be copied to `bash4edge/servers.yml`.

### 1.1 `repos` / `networks` / `semanticsDbs` / `serverSettings` / `servers`

Identical schema to Bash4Edge's own `servers.yml` — see that file's inline
comments, or `docs/ARCHITECTURE.md`'s module map, for the full field list.
Key fields per server: `version`, `ip`, `repo` (required); `accept_eula`,
`network`, `db_vol_suffix`, `db_folder`, `crash_folder`, `working_dir`,
`ca_folder`, `dns_ip`, `graphdb_URL` (optional, inherited from
`serverSettings` if omitted).

### 1.2 `agentSettings` (NEW — Python-agent-only, optional)

| Field | Default | Meaning |
|---|---|---|
| `network.force_strategy` | unset (auto-detect) | `ipvlan` or `bridge_ports` — overrides the OS-based auto-detection in `platform_utils.network_strategy()`. |
| `log_collection.enabled` | `true` | Master on/off switch. |
| `log_collection.output_dir` | auto-detected Downloads folder | Root folder for diagnostic snapshots. |
| `log_collection.tail_lines` | `500` | Lines fetched from `docker logs`. |
| `log_collection.keep_last_n_collections` | `20` | Retention per container. |
| `monitor.poll_interval_seconds` | `60` | Seconds between monitor loop passes. |
| `monitor.auto_restart` | `false` | Whether the decision engine may act automatically. |
| `monitor.max_auto_restart_attempts` | `3` | Cap per container per agent run. |
| `monitor.connectivity_check_enabled` | `true` | NEW — whether to TCP-probe each running server. |
| `monitor.connectivity_check_port` | `443` | NEW — port used for the TCP probe. |
| `monitor.connectivity_timeout_seconds` | `3` | NEW — probe timeout. |

---

## 2. In-memory data objects

### 2.1 `ServerConfig` / `GraphDbServerConfig` (`agent/config.py`)
Same fields as before, plus `network` (resolved per-server network name).
`accept_eula` is always a literal `"Yes"`/`"No"` STRING (converted from
YAML's parsed boolean — see `docs/SOURCE_FILES_REVIEW.md` for why).

### 2.2 `ServerDiscovery` (NEW — `agent/discovery.py`)
Fields: `name, exists, running, configured_ip, runtime_ip, ip_drifted,
reachable, reachable_detail`. Returned by `discover_servers()` /
`validate_all()`; printed by the `discover`/`validate`/`auto` CLI commands.

### 2.3 `Decision` (`agent/decision_engine.py`)
`state` now includes a NEW value: `"unreachable"` (running per Docker, but
not answering a TCP connectivity check) — distinct from `"running"`
(healthy) and `"restart_loop"`.

---

## 3. Output data: diagnostic log collection

Unchanged structure from the previous pass:
```
<output_dir>\<ContainerName>\<YYYYMMDD_HHMMSS>\
  ├── <name>_docker.log
  ├── <name>_inspect.json
  ├── <name>_health_report.txt   (now may include "state=unreachable")
  └── <name>_trace\              (trace.log / trace.log.old)
```
`<output_dir>` now defaults to THIS host's real Downloads folder
(`platform_utils.default_downloads_dir()`) rather than a hard-coded
Windows path — correct on native Windows, WSL, and native Linux without
manual editing.

---

## 4. Cache data (NEW, in-memory only, never written to disk)

`agent/discovery.py` maintains a short-lived (5-second TTL), in-process
cache for `docker ps -a` and `docker inspect` results, keyed by command
signature. This cache:
- is NEVER persisted to disk,
- is automatically invalidated after any mutating action
  (`start`/`stop`/`restart`/`remove`/`upgrade` all call
  `discovery.clear_cache()`),
- exists purely to avoid repeated subprocess launches within a single CLI
  invocation or monitor-loop iteration (performance).

---

## 5. Agent's own operational log

`<project_root>\logs\agent.log` — unchanged from the previous pass.

---

## 6. Data NOT collected or stored

Unchanged from the previous pass: no EBO application-level data, no
credentials stored beyond what's already in `config/servers.yml` as plain
Docker arguments, backup file contents never parsed, no GitHub token used
or stored by the Python agent (unlike Bash4Edge's own `manageServers.sh`
Upgrade option, which embeds one for its tag-listing feature — the Python
agent's `upgrade` command requires you to specify the target version
explicitly instead, avoiding that dependency entirely).
