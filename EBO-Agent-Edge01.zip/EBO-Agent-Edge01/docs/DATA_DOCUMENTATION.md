# Data Documentation

This document describes **every piece of data** the EBO Docker Agent (Path
A) reads, produces, or stores: the configuration schema, the in-memory
objects passed between modules, and the files written to disk (including
the diagnostic snapshots delivered to your Downloads folder). For Path B
(Bash4Edge), the equivalent configuration file is `bash4edge/servers.yml`,
documented inline within that file and in `bash4edge/README.md`.

---

## 1. Input data: `config/servers.json`

Plain JSON (no YAML/PyYAML), loaded and validated by `agent/config.py`. It
has six top-level sections.

### 1.1 `repos` — image repository lookup table

| Field | Type | Meaning |
|---|---|---|
| `repos.<RepoName>.repository` | string | Full GHCR repository path (without tag), e.g. `ghcr.io/schneiderelectricbuildings/ebo-enterprise-server`. |

Shipped with three entries: `EdgeServer`, `EnterpriseServer`,
`EnterpriseCentral` — mirroring Bash4Edge's `servers.yml`'s `repos:` block.

### 1.2 `network` — Docker IPvlan network definition

| Field | Type | Default | Meaning |
|---|---|---|---|
| `name` | string | `bridged-net` | Docker network name created/used for every managed container (unless `--test-mode` is used). |
| `driver` | string | `ipvlan` | Docker network driver. |
| `subnet` | string (CIDR) | `192.168.10.0/24` | Subnet matching your host's physical LAN. |
| `gateway` | string (IP) | `192.168.10.254` | Gateway address for that subnet. |
| `parent_interface` | string | `eth0` | **Placeholder** — your host's real NIC name (see `docs/ASSUMPTIONS.md` #4). |

### 1.3 `defaults` — fallback values applied to every server entry

| Field | Type | Default | Meaning |
|---|---|---|---|
| `accept_eula` | string | `"Yes"` | EULA acceptance flag passed as `NSP_ACCEPT_EULA` env var. |
| `db_folder` | string | `/var/sbo` | In-container path where the EBO database volume is mounted. |
| `db_vol_suffix` | string | `-db` | Appended to the container name to form its Docker volume name (`<name>-db`). |
| `crash_folder` | string | `/var/crash` | Host path bind-mounted into the container for crash dumps, if it exists. See readme.md's "In case of crash" section for the host-level `kernel.core_pattern`/apport/`limits.conf` setup this depends on. |
| `dns` | string \| null | `null` | Optional DNS server override. |
| `http_proxy` / `https_proxy` / `no_proxy` | string \| null | `null` | Optional proxy overrides; falls back to host environment variables if null. `no_proxy` may contain comma-separated hosts. |
| `ca_bundle` | string \| null | `null` | Path to a single PEM file (version 8.0+ servers only). Bind-mounted read-only at `/opt/sbo/etc/ca-bundle.crt`. |
| `ca_folder` | string \| null | `null` | Path to a CA folder (legacy, version < 8.0 servers only). Bind-mounted at `/usr/local/share/ca-certificates`. Supplying the wrong one of `ca_bundle`/`ca_folder` for a given server version is silently ignored by `build_run_command()` (the inapplicable branch is simply skipped) rather than raising, unlike `start.py`'s `SystemExit` — see `docs/ASSUMPTIONS.md`. |
| `graphdb` | string | `""` | Optional GraphDB URL, passed as `Semantic_Db_URL` env var. |

### 1.4 `graphdb_servers` — optional Semantics/GraphDB companion containers

Mirrors Bash4Edge's `semanticsDbs` section. Not used by the shipped Edge01
example (which has no GraphDB configured).

| Field | Type | Meaning |
|---|---|---|
| `graphdb_servers.<Name>.repository` | string | Image repository, e.g. `ontotext/graphdb`. |
| `graphdb_servers.<Name>.version` | string | Image tag, e.g. `10.2.4`. |
| `graphdb_servers.<Name>.port` | int | Port GraphDB listens on (default `7200`). |
| `graphdb_servers.<Name>.network` | string | Docker network name to attach to. |
| `graphdb_servers.<Name>.ip` | string | Static IP for the GraphDB container. |

### 1.5 `log_collection` — diagnostic snapshot settings

| Field | Type | Default | Meaning |
|---|---|---|---|
| `enabled` | bool | `true` | Master on/off switch for automatic log collection. |
| `output_dir` | string (path) | `C:\Users\SESA367373\Downloads\DOCKER\CONTAINER1` | Root folder where snapshots are written. |
| `tail_lines` | int | `500` | Number of trailing lines fetched from `docker logs`. |
| `interval_seconds` | int | `300` | Reserved for future scheduled-collection use (the `monitor` command currently uses `monitor.poll_interval_seconds` instead). |
| `keep_last_n_collections` | int | `20` | Oldest snapshots beyond this count are deleted per container. |

### 1.6 `monitor` — health-check loop settings

| Field | Type | Default | Meaning |
|---|---|---|---|
| `poll_interval_seconds` | int | `60` | Seconds between passes in `python run_agent.py monitor`. |
| `auto_restart` | bool | `false` | If `true`, the decision engine will actually call restart/start instead of only recommending it. |
| `max_auto_restart_attempts` | int | `3` | Per-container cap on automatic restarts within one agent run. |

### 1.7 `servers` — the containers the agent manages

| Field | Type | Required | Meaning |
|---|---|---|---|
| `repo` | string | Yes | Key into the `repos` table. |
| `type` | string | No (default `ebo-edge-server`) | Image name suffix, e.g. `ebo-enterprise-server`. |
| `version` | string | Yes | Image tag, e.g. `hf-712-cp-2-5000-consolidation`. Also determines the CA-bundle-vs-legacy-folder branch (see §1.3). |
| `ip` | string | Yes | Static IPvlan address (ignored if `--test-mode` is used). |
| `accept_eula`, `dns`, `http_proxy`, `https_proxy`, `no_proxy`, `ca_bundle`, `ca_folder`, `graphdb` | — | No | Per-server overrides of the matching `defaults.*` field. |

Shipped example — your `Edge01` container:
```json
"Edge01": {
  "repo": "EnterpriseServer",
  "type": "ebo-enterprise-server",
  "version": "hf-712-cp-2-5000-consolidation",
  "ip": "192.168.10.1",
  "accept_eula": "Yes"
}
```

---

## 2. In-memory data objects (runtime)

### 2.1 `ServerConfig` (`agent/config.py`)
One resolved server entry. Fields: `name, repo, type, version, ip,
accept_eula, dns, http_proxy, https_proxy, no_proxy, ca_bundle, ca_folder,
graphdb`.

### 2.2 `GraphDbServerConfig` (`agent/config.py`)
One resolved GraphDB entry. Fields: `name, repository, version, port,
network, ip`.

### 2.3 Status dict (`container_manager.status()`)
Returned by `status <name>` and used internally by the decision engine.
Keys: `name, exists, running, status, restart_count, started_at, image, ip`.

### 2.4 `Decision` (`agent/decision_engine.py`)
Fields: `name, state` (`missing`/`stopped`/`running`/`restart_loop`),
`action` (`create`/`restart`/`none`/`alert`), `reasons` (list[str]),
`findings` (list[str]).

---

## 3. Output data: diagnostic log collection

Every call to `collect-logs` or each pass of `monitor` writes **one
snapshot folder per container**:

```
<output_dir>\<ContainerName>\<YYYYMMDD_HHMMSS>\
  ├── <ContainerName>_docker.log        Raw tail of `docker logs`
  ├── <ContainerName>_inspect.json      Full `docker inspect` output (pretty JSON)
  ├── <ContainerName>_health_report.txt Decision engine's state/action/reasons/findings
  └── <ContainerName>_trace\            trace.log / trace.log.old, pulled directly
                                        from the server's database VOLUME via an
                                        ephemeral container (ported from
                                        get-trace.log) -- present only if the
                                        extraction succeeds; a failure here (e.g.
                                        volume doesn't exist yet) is logged as a
                                        warning and does not block the rest of
                                        the snapshot
```

For your configuration, this resolves to, e.g.:
```
C:\Users\SESA367373\Downloads\DOCKER\CONTAINER1\Edge01\20261004_140908\
  ├── Edge01_docker.log
  ├── Edge01_inspect.json
  ├── Edge01_health_report.txt
  └── Edge01_trace\
        trace.log
        trace.log.old
```

### 3.1 `<name>_docker.log`
Plain text. The last `log_collection.tail_lines` lines of `docker logs
<name>`.

### 3.2 `<name>_inspect.json`
Pretty-printed JSON — the complete, unmodified output of
`docker inspect <name>` (single container object).

### 3.3 `<name>_health_report.txt`
```
Collected at: <ISO timestamp>

[<name>] state=<state> action=<action>
  reason: <reason 1>
  finding: (<severity>) <advice>
```

### 3.4 `<name>_trace/`
Raw copies of `trace.log` and (if present) `trace.log.old`, extracted
directly from `<name>-db`'s `/var/sbo/db/logs/` folder — this works even
if the container itself has been stopped or removed, as long as the named
volume still exists.

### 3.5 Retention
Only the most recent `log_collection.keep_last_n_collections` (default 20)
snapshot folders per container are kept; older ones are deleted entirely.

---

## 4. Agent's own operational log (separate from §3)

`<project_root>\logs\agent.log` — rotating at 2 MB, keeping 5 backups. This
is the agent's OWN activity log (CLI actions, errors, Docker commands run),
separate from the container diagnostic snapshots above.

---

## 5. Data NOT collected or stored

- No EBO application-level data (BMS points, alarms, trends) is read or
  stored — only Docker-level logs/metadata and trace files.
- No credentials are stored; `accept_eula`/proxy/DNS/CA values in
  `config/servers.json` are passed through as plain Docker `-e`/`--mount`
  arguments, the same way `start.py` did.
- Backup file (`.xbk`) **contents** are only copied between host and
  volume on explicit command — never opened, parsed, or inspected.
- The GitHub personal access token referenced in Bash4Edge's
  `manageServers.sh` (for the Upgrade tag-listing feature) is NOT used or
  stored anywhere in this Python agent; `agent/container_manager.upgrade()`
  requires you to specify the target version explicitly instead.
