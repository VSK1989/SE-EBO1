# EBO Docker Agent — Edge01

A lightweight, dependency-free, rule-based AI Agent for managing your
EcoStruxure Building Operation (EBO) Docker container (**Edge01**,
`192.168.10.1`), plus the **Bash4Edge** toolkit for managing the same kind
of container from a separate Ubuntu/Linux host. Two complementary paths,
one project.

> **New here? Read these three docs first:**
> - `docs/SOURCE_FILES_REVIEW.md` — exactly how every uploaded file (both
>   the Windows/Python scripts AND the Bash4Edge toolkit) and the GitHub
>   repository were reviewed and merged into this project, file by file.
> - `docs/ASSUMPTIONS.md` — every assumption made where the source
>   material didn't give an exact answer. **Verify these before a live
>   (non `--dry-run`) run.**
> - `docs/ARCHITECTURE.md` — the full module reference for both paths.
>
> Your original files are preserved, byte-for-byte, under
> `reference/original-uploaded-files/` (in two subfolders,
> `windows-python-agent/` and `bash4edge/`) so you can compare them against
> the code at any time.

## Two paths — pick the one that matches your environment

| | **Path A: Windows + Docker Desktop** | **Path B: Ubuntu/Linux + Bash4Edge** |
|---|---|---|
| Where it runs | Directly on your Windows PC | A separate Ubuntu 22.04 LTS / Debian-based machine |
| How you control it | This Python agent (`agent/`), run from VS Code on Windows | Interactive Bash scripts (`bash4edge/`), run over SSH from VS Code's Remote Explorer |
| Requires Python? | No extra install (stdlib only) | No — Python not used at all |
| Covered in | This README + `docs/` | `bash4edge/README.md` |

You do not need to use both — pick the one matching where your EBO server
container actually runs. See the companion **Installation Guide** document
for a complete, beginner-friendly walkthrough of both paths.

## What this agent does (Path A)

1. **Manages the container lifecycle** — start, stop, restart, upgrade,
   remove, status — reusing the exact `docker run` construction logic from
   `start.py`/`upgrade.py`, now driven by one JSON config file. Includes an
   optional `--test-mode` for quick testing via port-forwarding instead of
   a static IP (ported from readme.md's own example).
2. **Manages backups, password reset, and trace logs** —
   `list-backups`/`copy-backups`/`restore-backup`, `password-reset-mode`
   (verified against Bash4Edge's source), and `get-trace` (verified, ported
   from `get-trace.log` — pulls trace logs straight from the server's
   database volume, even if the container itself isn't running).
3. **Manages an optional Semantics/GraphDB companion container** —
   `graphdb create|status|start|stop|remove` (verified against Bash4Edge's
   `manageGraphDb.sh`).
4. **Continuously (or on demand) evaluates container health** using a
   transparent rule engine (missing/stopped/running/restart-loop states,
   plus known log-pattern detection for EULA, licensing, OOM, DB, and
   network errors).
5. **Automatically collects diagnostic logs** (docker logs + inspect +
   health report + trace files) into
   `C:\Users\SESA367373\Downloads\DOCKER\CONTAINER1\Edge01\<timestamp>\`
   every monitoring cycle or on demand.
6. Runs with **zero `pip install` steps** — everything is Python standard
   library only.

## Project structure

```
EBO-Agent-Edge01/
├── .vscode/                        VS Code launch/tasks/settings/extensions
├── agent/                          Path A: all Python source (see docs/ARCHITECTURE.md)
├── bash4edge/                      Path B: the Bash4Edge toolkit, ready to copy to Ubuntu
├── config/servers.json             Path A configuration (container, network, logs)
├── docs/                           Architecture, source-file review, assumptions, data docs
├── reference/original-uploaded-files/   Your original files, verbatim, for comparison
│   ├── windows-python-agent/        start.py, teststart.py, upgrade.py, get-trace.log, readme.md, ...
│   └── bash4edge/                   functions.sh, manageOS.sh, ..., servers.yml, readme.md
├── tests/                          74 unit tests (mocked — no live Docker required)
├── run_agent.py                    Path A entry point
└── requirements.txt                Intentionally empty (stdlib only)
```

---

## Prerequisites (Path A)

- **Windows 10/11** with **Docker Desktop** installed and running (WSL2
  backend recommended).
- **Python 3.9+** installed and on PATH.
- **Visual Studio Code**, with the **Python extension**
  (`ms-python.python`) and, optionally, the **Docker extension**
  (`ms-azuretools.vscode-docker`).
- Network access to `ghcr.io` to pull
  `ghcr.io/schneiderelectricbuildings/ebo-enterprise-server:hf-712-cp-2-5000-consolidation`.

## Installation (Path A)

1. Unzip the project, e.g. to `C:\Users\SESA367373\Documents\EBO-Agent-Edge01`.
2. Open the folder in VS Code: **File > Open Folder…**
3. No `pip install` is required. Verify with:
   ```powershell
   python --version
   python -c "import json, subprocess, argparse; print('stdlib OK')"
   ```

## Running the agent (Path A)

```powershell
# List configured containers (and GraphDB servers, if any)
python run_agent.py list

# Check current status + health assessment (safe, read-only)
python run_agent.py status Edge01

# ALWAYS validate with --dry-run first:
python run_agent.py --dry-run start Edge01

# Once satisfied, run it for real:
python run_agent.py start Edge01

# Quick test without an IPvlan network (port-forwarding instead):
python run_agent.py start Edge01 --test-mode
# connect at https://localhost:1443

# Stop / restart / remove
python run_agent.py stop Edge01
python run_agent.py restart Edge01
python run_agent.py remove Edge01 --force

# Upgrade to a new version tag
python run_agent.py upgrade Edge01 hf-713-cp-1-1000-consolidation

# --- Backup management ---
python run_agent.py list-backups Edge01
python run_agent.py copy-backups Edge01 C:\Backups\Edge01
python run_agent.py restore-backup Edge01 hf-712-cp-2-5000-consolidation "Server 1 2022-09-09 14_12_36_5.0.0.1082.xbk" ConfigurationOnly
python run_agent.py restore-backup Edge01 hf-712-cp-2-5000-consolidation my-backup.xbk AllData --from-host C:\Backups\my-backup.xbk

# --- Password reset mode (verified, no stop/restart performed) ---
python run_agent.py password-reset-mode Edge01

# --- Pull trace logs directly from the database volume ---
python run_agent.py get-trace Edge01 C:\Traces\Edge01

# --- Optional GraphDB companion container ---
python run_agent.py graphdb create GraphDb01
python run_agent.py graphdb status GraphDb01

# Collect a diagnostic snapshot right now
python run_agent.py collect-logs Edge01

# Continuous monitor loop (health-check + log collection)
python run_agent.py monitor
python run_agent.py monitor --once
```

Every command accepts `--verbose` (debug logging) and `--dry-run` (log the
exact Docker commands instead of executing them).

## Path B — Bash4Edge (Ubuntu/Linux)

See `bash4edge/README.md` for the full toolkit documentation, and the
companion Installation Guide document's Part B (Stages 6-10) for a
complete step-by-step walkthrough: preparing the Ubuntu machine, connecting
VS Code over SSH via Remote Explorer, copying the scripts, and running
`manageOS.sh` → `setupDockerNetwork.sh` → `manageGraphDb.sh` →
`manageServers.sh` in order.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `Could not execute 'docker'.` | Docker Desktop not running, or not on PATH. | Start Docker Desktop; wait for "Engine running"; reopen the terminal. |
| `Configuration file not found` | Wrong working directory. | Run via `python run_agent.py ...` from the project root. |
| `Server 'Edge01' not found` | Typo in container name. | Run `python run_agent.py list`. |
| Log/trace collection folder not created | Running under WSL/Linux where the Windows path isn't reachable. | Update `log_collection.output_dir` in `config/servers.json` to a reachable path (e.g. `/mnt/c/Users/...`). |
| `docker run` fails with a network/IP error | `bridged-net`'s subnet/adapter doesn't match your host. | Update `network.*` in `config/servers.json`, then `docker network rm bridged-net` to let the agent recreate it. |
| `restore-backup`/`password-reset-mode` behaves unexpectedly | These were corrected against Bash4Edge's verified source, but the OFFICIAL Windows-side scripts' exact binaries weren't directly reviewable. | Run `docker exec Edge01 ls /opt/sbo/bin/` to confirm the real binary names match. |
| `ValueError: Invalid characters in ...` | A config value contains characters outside the (deliberately widened) whitelist. | See `docs/SOURCE_FILES_REVIEW.md` §5 for exactly which characters are allowed and why. |
| Container keeps restarting (`restart_loop` in `status`) | Docker's `--restart=always` policy looping. | Run `python run_agent.py collect-logs Edge01` and inspect the snapshot before restarting further. |

## Validation and testing

74 automated unit tests, all mocked (no Docker Desktop required):

```powershell
python -m unittest discover -s tests -v
```
Expected: `OK` (74 tests passed).

**Recommended acceptance sequence:**
1. `python -m unittest discover -s tests -v`
2. `python run_agent.py --dry-run start Edge01` — inspect the printed command.
3. `python run_agent.py start Edge01` — real start; confirm with `status`.
4. `python run_agent.py collect-logs Edge01` — confirm files appear in Downloads.
5. `python run_agent.py monitor --once` — confirm one full pass completes.
6. Browse to `https://192.168.10.1/` to confirm the EBO web UI responds.

See `docs/ARCHITECTURE.md`, `docs/SOURCE_FILES_REVIEW.md`, and
`docs/ASSUMPTIONS.md` for full details.
