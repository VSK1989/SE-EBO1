# EBO Docker Agent — Cross-Platform, Plug-and-Play

A lightweight, dependency-free, rule-based AI Agent for managing your
EcoStruxure Building Operation (EBO) Docker container (**Edge01**),
working identically across **Windows Docker Desktop**, **native
Ubuntu/Linux**, and the **Bash4Edge** shell toolkit — all driven by one
shared configuration file: `config/servers.yml`.

![Architecture](docs/architecture-diagram.png)

> **New here? Read these first:**
> - `docs/SOURCE_FILES_REVIEW.md` — full traceability of every file this
>   project is built from, across all enhancement passes.
> - `docs/ASSUMPTIONS.md` — every assumption made, including the
>   cross-platform networking behaviour differences. **Read before a live
>   (non `--dry-run`) run.**
> - `docs/ARCHITECTURE.md` — full module reference + the diagram above.

## Plug-and-play quickstart

```powershell
# 1. Install Docker Desktop (Windows) or Docker Engine (Ubuntu/Linux).
# 2. Edit config/servers.yml with your container's details.
# 3. Run ONE command:
python run_agent.py auto
```
`auto` automatically: detects your OS and picks the right Docker
networking strategy → discovers which configured servers already exist
and are running → validates network connectivity to each → starts the
continuous health-monitoring loop. No other manual steps, no code
changes, on either platform.

## What's new in this cross-platform pass

- **Automatic OS detection** (`platform_utils.py`): Windows, native Linux,
  WSL, and macOS are all detected, and Docker networking/paths adapt
  automatically — see "Why the network strategy differs by OS" below.
- **Direct `servers.yml` reading, no PyYAML** (`yaml_mini.py`): a small,
  dependency-free parser reads the SAME schema Bash4Edge uses — literally
  the same file can be copied between `config/` and `bash4edge/`.
- **Automatic container & IP discovery** (`discovery.py`): `discover`,
  `validate`, and `sync-ip` commands find your containers, detect IP
  drift after a recreation, and can auto-correct `servers.yml`.
- **Name OR IP everywhere**: every command (`status`, `start`, `stop`,
  `get-trace`, etc.) accepts either a configured server's name or its IP
  address.
- **Bash4Edge parity**: a new `bash4edge/discoverConnectivity.sh` script
  brings the same discovery/validation capability to the Linux/Bash side.
- **Performance**: `docker ps`/`docker inspect` results are cached for 5
  seconds within a single run, cutting repeated subprocess launches.
- **120 automated tests** (up from 74), several specifically added to
  catch and prove the fix for real bugs found during this pass (see
  `docs/SOURCE_FILES_REVIEW.md`).

## Two paths — pick the one that matches your environment

| | **Path A: Python Agent** | **Path B: Bash4Edge** |
|---|---|---|
| Where it runs | Windows, native Linux, or WSL | Separate Ubuntu/Debian machine |
| Config file | `config/servers.yml` | `bash4edge/servers.yml` (same file) |
| Requires Python? | No extra install (stdlib only) | No — Python-free by design |
| Discovery/validation | `python run_agent.py discover` / `validate` / `sync-ip` | `./discoverConnectivity.sh [--sync-ip]` |

## Project structure

```
EBO-Agent-Edge01/
├── .vscode/                        Launch/tasks (incl. auto-discover on folder open)
├── agent/                          Path A Python source
│   ├── platform_utils.py            NEW: OS detection, network strategy
│   ├── yaml_mini.py                 NEW: dependency-free YAML reader
│   ├── discovery.py                 NEW: container/IP discovery, connectivity
│   └── ... (config, docker_tools, container_manager, backup_tools, etc.)
├── bash4edge/                      Path B toolkit (+ NEW discoverConnectivity.sh)
├── config/servers.yml              THE single, shared configuration file
├── docs/                           Architecture (+ diagram), source review, assumptions
├── reference/original-uploaded-files/   Originals, preserved for comparison
├── tests/                          120 unit tests (mocked — no live Docker required)
└── run_agent.py                    Path A entry point
```

## Running the agent (Path A)

```powershell
# Plug-and-play (recommended first run)
python run_agent.py auto --once        # single pass, good for first validation
python run_agent.py auto               # continuous monitoring

# Discovery & validation
python run_agent.py list               # shows detected OS + network strategy
python run_agent.py discover           # existence/running/IP-drift report
python run_agent.py validate           # + TCP connectivity check
python run_agent.py sync-ip            # auto-correct drifted IPs in servers.yml

# Lifecycle (name OR IP both work)
python run_agent.py status Edge01
python run_agent.py status 192.168.10.1
python run_agent.py --dry-run start Edge01
python run_agent.py start Edge01
python run_agent.py start Edge01 --test-mode   # force port-forwarding mode

# Backups, password reset, trace logs, GraphDB — unchanged from before
python run_agent.py list-backups Edge01
python run_agent.py password-reset-mode Edge01
python run_agent.py get-trace Edge01 C:\Traces\Edge01
python run_agent.py graphdb create GraphDb01

# Diagnostics
python run_agent.py collect-logs Edge01
python run_agent.py monitor --once
```

## Why the network strategy differs by OS

- **Linux / WSL**: static IP via an IPVLAN network bound to a real host
  NIC — the original, Bash4Edge-compatible behaviour.
- **Native Windows**: Docker Desktop's daemon runs inside a hidden VM with
  no reliable host-NIC access for IPVLAN — so the agent automatically uses
  an ordinary bridge network with published ports instead (reachable at
  `https://localhost:1443`). Override with
  `agentSettings.network.force_strategy: ipvlan` in `config/servers.yml`
  if your Docker Desktop networking setup supports it.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Server unreachable on Windows at its configured LAN IP | Expected — see network-strategy note above. | Connect at `https://localhost:1443` instead, or force `ipvlan` if supported. |
| `discover`/`validate` shows IP drift after recreating a container | Docker assigned a different IP than configured. | Run `python run_agent.py sync-ip` to auto-correct `servers.yml`. |
| `Could not parse config/servers.yml` | An advanced YAML feature was used that `yaml_mini.py` doesn't support. | Simplify to plain nested `key: value` mappings — see `agent/yaml_mini.py`'s docstring. |
| Crash-dump mount missing | `/var/crash` doesn't exist on the host yet. | Follow readme.md's "In case of crash" host setup, matching `start.py`'s own behaviour exactly. |

## Validation and testing

120 automated unit tests, all mocked (no Docker Desktop required):
```powershell
python -m unittest discover -s tests -v
```

See `docs/ARCHITECTURE.md`, `docs/SOURCE_FILES_REVIEW.md`, and
`docs/ASSUMPTIONS.md` for full details.
