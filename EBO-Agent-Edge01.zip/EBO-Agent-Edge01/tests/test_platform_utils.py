"""
tests/test_platform_utils.py
===============================
Purpose: Validate OS detection, cross-platform path translation, and
network-strategy selection, using mocked platform.system()/environment so
these tests pass identically regardless of which OS actually runs them.
"""
import os
import unittest
from unittest.mock import patch

from agent import platform_utils as pf


class TestDetectOs(unittest.TestCase):
    def test_windows(self):
        with patch("platform.system", return_value="Windows"):
            self.assertEqual(pf.detect_os(), "windows")
            self.assertTrue(pf.is_windows())

    def test_macos(self):
        with patch("platform.system", return_value="Darwin"):
            self.assertEqual(pf.detect_os(), "macos")

    def test_native_linux(self):
        with patch("platform.system", return_value="Linux"), \
             patch("platform.release", return_value="5.15.0-generic"), \
             patch.dict(os.environ, {}, clear=True):
            self.assertEqual(pf.detect_os(), "linux")

    def test_wsl_detected_via_kernel_release(self):
        with patch("platform.system", return_value="Linux"), \
             patch("platform.release", return_value="5.15.90.1-microsoft-standard-WSL2"):
            self.assertEqual(pf.detect_os(), "wsl")
            self.assertTrue(pf.is_wsl())

    def test_wsl_detected_via_env_var(self):
        with patch("platform.system", return_value="Linux"), \
             patch("platform.release", return_value="5.15.0-generic"), \
             patch.dict(os.environ, {"WSL_DISTRO_NAME": "Ubuntu"}):
            self.assertEqual(pf.detect_os(), "wsl")


class TestPathTranslation(unittest.TestCase):
    def test_windows_path_translated_under_wsl(self):
        with patch("agent.platform_utils.is_wsl", return_value=True):
            result = pf.to_host_path(r"C:\Users\SESA367373\Downloads")
            self.assertEqual(result, "/mnt/c/Users/SESA367373/Downloads")

    def test_windows_path_unchanged_on_native_windows(self):
        with patch("agent.platform_utils.is_wsl", return_value=False):
            path = r"C:\Users\SESA367373\Downloads"
            self.assertEqual(pf.to_host_path(path), path)

    def test_posix_path_unchanged_on_linux(self):
        with patch("agent.platform_utils.is_wsl", return_value=False):
            self.assertEqual(pf.to_host_path("/home/user/Downloads"), "/home/user/Downloads")

    def test_normalize_bind_source_is_alias(self):
        with patch("agent.platform_utils.is_wsl", return_value=True):
            self.assertEqual(
                pf.normalize_bind_source(r"D:\Backups"),
                pf.to_host_path(r"D:\Backups"),
            )


class TestNetworkStrategy(unittest.TestCase):
    def test_defaults_to_ipvlan_on_linux(self):
        with patch("agent.platform_utils.is_windows", return_value=False):
            self.assertEqual(pf.network_strategy(), "ipvlan")

    def test_defaults_to_bridge_ports_on_windows(self):
        with patch("agent.platform_utils.is_windows", return_value=True):
            self.assertEqual(pf.network_strategy(), "bridge_ports")

    def test_explicit_force_wins(self):
        with patch("agent.platform_utils.is_windows", return_value=True):
            self.assertEqual(pf.network_strategy(force="ipvlan"), "ipvlan")
        with patch("agent.platform_utils.is_windows", return_value=False):
            self.assertEqual(pf.network_strategy(force="bridge_ports"), "bridge_ports")


class TestCidrToNetwork(unittest.TestCase):
    def test_basic_24(self):
        self.assertEqual(pf._cidr_to_network("192.168.1.251/24"), "192.168.1.0/24")

    def test_basic_16(self):
        self.assertEqual(pf._cidr_to_network("10.20.30.40/16"), "10.20.0.0/16")

    def test_invalid_input_returns_none(self):
        self.assertIsNone(pf._cidr_to_network("not-an-ip"))


if __name__ == "__main__":
    unittest.main()
