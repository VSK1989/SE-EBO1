"""
tests/test_discovery.py
==========================
Purpose: Validate the new discovery/caching/IP-sync/connectivity-validation
module using mocked docker_tools calls (no real Docker daemon required).
"""
import unittest
from unittest.mock import patch
import tempfile
from pathlib import Path

from agent import discovery
from agent.config import load_config


class TestListAllContainersCache(unittest.TestCase):
    def setUp(self):
        discovery.clear_cache()

    def test_caches_repeated_calls(self):
        with patch("agent.docker_tools.exe", return_value=(0, "Edge01\tabc123\tUp 2 hours\timg:tag", "")) as mock_exe:
            discovery.list_all_containers()
            discovery.list_all_containers()
            discovery.list_all_containers()
        mock_exe.assert_called_once()

    def test_force_bypasses_cache(self):
        with patch("agent.docker_tools.exe", return_value=(0, "Edge01\tabc123\tUp\timg", "")) as mock_exe:
            discovery.list_all_containers()
            discovery.list_all_containers(force=True)
        self.assertEqual(mock_exe.call_count, 2)

    def test_parses_rows_correctly(self):
        with patch("agent.docker_tools.exe", return_value=(0, "Edge01\tabc123\tUp 2 hours\tmyimg:1.0", "")):
            rows = discovery.list_all_containers(force=True)
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]["name"], "Edge01")
        self.assertEqual(rows[0]["image"], "myimg:1.0")


class TestGetRuntimeIp(unittest.TestCase):
    def setUp(self):
        discovery.clear_cache()

    def test_extracts_ip_from_networks(self):
        fake_info = {"NetworkSettings": {"Networks": {"bridged-net": {"IPAddress": "192.168.10.1"}}}}
        with patch("agent.docker_tools.inspect_container", return_value=fake_info):
            ip = discovery.get_runtime_ip("Edge01", force=True)
        self.assertEqual(ip, "192.168.10.1")

    def test_returns_none_when_missing(self):
        with patch("agent.docker_tools.inspect_container", return_value=None):
            ip = discovery.get_runtime_ip("Edge01", force=True)
        self.assertIsNone(ip)

    def test_caches_result(self):
        fake_info = {"NetworkSettings": {"Networks": {"net": {"IPAddress": "1.2.3.4"}}}}
        with patch("agent.docker_tools.inspect_container", return_value=fake_info) as mock_inspect:
            discovery.get_runtime_ip("Edge01", force=True)
            discovery.get_runtime_ip("Edge01")
            discovery.get_runtime_ip("Edge01")
        mock_inspect.assert_called_once()


class TestDiscoverServers(unittest.TestCase):
    def setUp(self):
        discovery.clear_cache()
        self.cfg = load_config()

    def test_missing_server(self):
        with patch("agent.discovery.list_all_containers", return_value=[]):
            results = discovery.discover_servers(self.cfg, force=True)
        self.assertEqual(len(results), 1)
        self.assertFalse(results[0].exists)
        self.assertFalse(results[0].ip_drifted)

    def test_running_server_no_drift(self):
        with patch("agent.discovery.list_all_containers",
                   return_value=[{"name": "Edge01", "id": "x", "status": "Up", "image": "img"}]), \
             patch("agent.docker_tools.is_running", return_value=True), \
             patch("agent.discovery.get_runtime_ip", return_value="192.168.10.1"):
            results = discovery.discover_servers(self.cfg, force=True)
        self.assertTrue(results[0].exists)
        self.assertTrue(results[0].running)
        self.assertFalse(results[0].ip_drifted)

    def test_running_server_with_drift(self):
        with patch("agent.discovery.list_all_containers",
                   return_value=[{"name": "Edge01", "id": "x", "status": "Up", "image": "img"}]), \
             patch("agent.docker_tools.is_running", return_value=True), \
             patch("agent.discovery.get_runtime_ip", return_value="192.168.10.200"):
            results = discovery.discover_servers(self.cfg, force=True)
        self.assertTrue(results[0].ip_drifted)
        self.assertEqual(results[0].runtime_ip, "192.168.10.200")


class TestSyncIpDrift(unittest.TestCase):
    def setUp(self):
        discovery.clear_cache()
        self.tmpdir = tempfile.TemporaryDirectory()
        self.yml_path = Path(self.tmpdir.name) / "servers.yml"
        self.yml_path.write_text(
            "repos:\n  EdgeServer:\n    repository: ghcr.io/x/ebo-edge-server\n"
            "networks:\n  bridged-net:\n    type: ipvlan\n    subnet: 192.168.10.0/24\n"
            "    gateway: 192.168.10.254\n    interface: eth0\n"
            "serverSettings:\n  accept_eula: Yes\n  network: bridged-net\n"
            "servers:\n  Edge01:\n    version: 1.0\n    ip: 192.168.10.1\n    repo: EdgeServer\n",
            encoding="utf-8",
        )
        from agent.config import load_config as _load
        self.cfg = _load(self.yml_path)

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_report_only_does_not_modify_file(self):
        original = self.yml_path.read_text(encoding="utf-8")
        with patch("agent.discovery.discover_servers") as mock_disc:
            d = discovery.ServerDiscovery(
                name="Edge01", exists=True, running=True,
                configured_ip="192.168.10.1", runtime_ip="192.168.10.200", ip_drifted=True,
            )
            mock_disc.return_value = [d]
            messages = discovery.sync_ip_drift(self.cfg, auto_fix=False)
        self.assertEqual(len(messages), 1)
        self.assertEqual(self.yml_path.read_text(encoding="utf-8"), original)

    def test_auto_fix_updates_file(self):
        with patch("agent.discovery.discover_servers") as mock_disc:
            d = discovery.ServerDiscovery(
                name="Edge01", exists=True, running=True,
                configured_ip="192.168.10.1", runtime_ip="192.168.10.200", ip_drifted=True,
            )
            mock_disc.return_value = [d]
            discovery.sync_ip_drift(self.cfg, auto_fix=True)
        updated = self.yml_path.read_text(encoding="utf-8")
        self.assertIn("ip: 192.168.10.200", updated)


class TestValidateConnectivity(unittest.TestCase):
    def test_unreachable_ip_returns_false(self):
        # 192.0.2.0/24 is TEST-NET-1 (RFC 5737) -- guaranteed non-routable,
        # so this should reliably fail to connect without needing real
        # network access in the test sandbox, and should do so quickly.
        result = discovery.validate_connectivity("192.0.2.1", port=81, timeout=0.5)
        self.assertFalse(result)

    def test_reachable_mocked(self):
        with patch("socket.create_connection"):
            result = discovery.validate_connectivity("127.0.0.1", port=80, timeout=1)
        self.assertTrue(result)


if __name__ == "__main__":
    unittest.main()
