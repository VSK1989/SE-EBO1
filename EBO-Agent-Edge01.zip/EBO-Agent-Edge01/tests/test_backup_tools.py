"""
tests/test_backup_tools.py
=============================
Purpose: Validate the list-backups / copy-backups / restore-backup
equivalents in agent/backup_tools.py using mocked docker_tools calls (no
real Docker daemon required). Confirms the correct underlying `docker
exec` / `docker cp` / ephemeral-container commands are built, matching the
usage contract documented in readme.md's "Backup management" section and
cross-confirmed by Bash4Edge's verified manageBackups.sh (same backup
folder path, same prepare-restore binary name).
"""
import unittest
from unittest.mock import patch

from agent import backup_tools as bt
from agent.config import load_config


class TestListBackups(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_list_backups_parses_output_lines(self):
        with patch("agent.docker_tools.docker_exec",
                   return_value=(0, "Server 1 2022-09-09 14_12_36_5.0.0.1082.xbk\nServer 2 backup.xbk", "")):
            files = bt.list_backups(self.cfg, "Edge01")
        self.assertEqual(len(files), 2)
        self.assertIn("Server 1 2022-09-09 14_12_36_5.0.0.1082.xbk", files)

    def test_list_backups_uses_correct_backup_dir(self):
        with patch("agent.docker_tools.docker_exec", return_value=(0, "", "")) as mock_exec:
            bt.list_backups(self.cfg, "Edge01")
            args = mock_exec.call_args[0]
            self.assertEqual(args[0], "Edge01")
            self.assertEqual(args[1], ["ls", "/var/sbo/db_backup/LocalBackup"])

    def test_list_backups_dry_run_does_not_fail(self):
        files = bt.list_backups(self.cfg, "Edge01", dry_run=True)
        self.assertEqual(files, [])


class TestCopyBackups(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_copy_backups_success(self):
        with patch("agent.docker_tools.copy_from_container", return_value=(0, "", "")) as mock_cp:
            ok = bt.copy_backups(self.cfg, "Edge01", "/tmp/backups")
            self.assertTrue(ok)
            mock_cp.assert_called_once_with(
                "Edge01", "/var/sbo/db_backup/LocalBackup/.", "/tmp/backups", dry_run=False
            )

    def test_copy_backups_failure_returns_false(self):
        with patch("agent.docker_tools.copy_from_container", return_value=(1, "", "no such container")):
            ok = bt.copy_backups(self.cfg, "Edge01", "/tmp/backups")
            self.assertFalse(ok)


class TestRestoreBackup(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_restore_backup_dry_run_succeeds(self):
        ok = bt.restore_backup(
            self.cfg, "Edge01", "hf-712-cp-2-5000-consolidation",
            "Server 1 2022-09-09 14_12_36_5.0.0.1082.xbk", "ConfigurationOnly",
            dry_run=True,
        )
        self.assertTrue(ok)

    def test_restore_backup_rejects_invalid_mode(self):
        ok = bt.restore_backup(
            self.cfg, "Edge01", "hf-712-cp-2-5000-consolidation",
            "backup.xbk", "InvalidMode", dry_run=True,
        )
        self.assertFalse(ok)

    def test_restore_backup_without_from_host_does_not_copy_in(self):
        """Matches readme.md's 'backup already available in the container'
        usage pattern -- no copy-in step, straight to prepare-restore."""
        with patch("agent.docker_tools.run_ephemeral_against_volume") as mock_ephemeral, \
             patch("agent.docker_tools.exe", return_value=(0, "", "")), \
             patch("agent.docker_tools.restart_container", return_value=(0, "", "")):
            bt.restore_backup(
                self.cfg, "Edge01", "hf-712-cp-2-5000-consolidation",
                "backup.xbk", "AllData", dry_run=False,
            )
            mock_ephemeral.assert_not_called()

    def test_restore_backup_from_host_copies_file_in_via_volume_mount(self):
        """Matches Bash4Edge's verified manageBackups.sh: copy-in uses an
        ephemeral container with a bind+volume mount, NOT `docker cp`
        against a (possibly non-running) container."""
        with patch("agent.docker_tools.run_ephemeral_against_volume",
                   return_value=(0, "", "")) as mock_ephemeral, \
             patch("agent.docker_tools.exe", return_value=(0, "", "")), \
             patch("agent.docker_tools.restart_container", return_value=(0, "", "")):
            bt.restore_backup(
                self.cfg, "Edge01", "hf-712-cp-2-5000-consolidation",
                "backup.xbk", "AllData", from_host_path="/tmp/backup.xbk", dry_run=False,
            )
            mock_ephemeral.assert_called_once()
            kwargs = mock_ephemeral.call_args.kwargs
            self.assertEqual(kwargs["bind_source"], "/tmp")
            self.assertEqual(kwargs["bind_target"], "/mnt")
            self.assertIn("backup.xbk", kwargs["shell_command"])

    def test_restore_backup_does_not_stop_container_first(self):
        """Faithfully mirrors Bash4Edge's manageBackups.sh: no explicit
        'docker stop' before prepare-restore, only 'docker restart' at the
        end."""
        with patch("agent.docker_tools.stop_container") as mock_stop, \
             patch("agent.docker_tools.exe", return_value=(0, "", "")), \
             patch("agent.docker_tools.restart_container", return_value=(0, "", "")) as mock_restart:
            bt.restore_backup(
                self.cfg, "Edge01", "hf-712-cp-2-5000-consolidation",
                "backup.xbk", "AllData", dry_run=False,
            )
            mock_stop.assert_not_called()
            mock_restart.assert_called_once()


if __name__ == "__main__":
    unittest.main()
