"""
tests/test_yaml_mini.py
==========================
Purpose: Validate the dependency-free YAML-subset parser against the real
servers.yml schema (nested mappings, comments, commented-out override
lines, Yes/No booleans, null scalars), and validate the surgical
single-line update function used for IP-drift auto-sync.
"""
import tempfile
import unittest
from pathlib import Path

from agent.yaml_mini import YamlMiniError, parse_yaml, update_scalar_in_file


SAMPLE = """\
# a comment line
repos:
  EdgeServer:
    repository: ghcr.io/schneiderelectricbuildings/ebo-edge-server
networks:
  bridged-net:
    type: ipvlan
    subnet: 192.168.10.0/24
    gateway: 192.168.10.254
    interface: eth0
serverSettings:
  accept_eula: Yes
  network: bridged-net
  ca_folder:
  dns_ip:
servers:
  Edge01:
    version: hf-712-cp-2-5000-consolidation
    ip: 192.168.10.1
    repo: EdgeServer
    # network: bridged-net
    # dns_ip: 8.8.8.8
notes:
  A: no spaces allowed
  B:
"""


class TestParseYaml(unittest.TestCase):
    def test_nested_mapping(self):
        data = parse_yaml(SAMPLE)
        self.assertEqual(
            data["repos"]["EdgeServer"]["repository"],
            "ghcr.io/schneiderelectricbuildings/ebo-edge-server",
        )

    def test_boolean_coercion(self):
        data = parse_yaml(SAMPLE)
        self.assertIs(data["serverSettings"]["accept_eula"], True)

    def test_null_scalar_not_empty_dict(self):
        data = parse_yaml(SAMPLE)
        self.assertIsNone(data["serverSettings"]["ca_folder"])
        self.assertIsNone(data["serverSettings"]["dns_ip"])
        self.assertIsNone(data["notes"]["B"])

    def test_commented_out_lines_are_invisible(self):
        data = parse_yaml(SAMPLE)
        # The commented-out "# network: bridged-net" / "# dns_ip: 8.8.8.8"
        # under Edge01 must NOT appear as keys at all.
        self.assertNotIn("network", data["servers"]["Edge01"])
        self.assertNotIn("dns_ip", data["servers"]["Edge01"])

    def test_scalar_values(self):
        data = parse_yaml(SAMPLE)
        self.assertEqual(data["servers"]["Edge01"]["ip"], "192.168.10.1")
        self.assertEqual(data["networks"]["bridged-net"]["gateway"], "192.168.10.254")

    def test_numeric_coercion(self):
        text = "a:\n  b: 7200\n"
        data = parse_yaml(text)
        self.assertEqual(data["a"]["b"], 7200)
        self.assertIsInstance(data["a"]["b"], int)

    def test_unsupported_feature_raises(self):
        with self.assertRaises(YamlMiniError):
            parse_yaml("a: &anchor\nb: *anchor\n")

    def test_tabs_raise(self):
        with self.assertRaises(YamlMiniError):
            parse_yaml("a:\n\tb: 1\n")


class TestUpdateScalarInFile(unittest.TestCase):
    def setUp(self):
        self.tmpdir = tempfile.TemporaryDirectory()
        self.path = Path(self.tmpdir.name) / "servers.yml"
        self.path.write_text(SAMPLE, encoding="utf-8")

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_updates_only_the_targeted_line(self):
        original = self.path.read_text(encoding="utf-8")
        ok = update_scalar_in_file(self.path, "servers.Edge01.ip", "10.0.0.99")
        self.assertTrue(ok)
        updated = self.path.read_text(encoding="utf-8")

        self.assertIn("ip: 10.0.0.99", updated)
        # Every other line must be byte-identical to the original.
        orig_lines = original.splitlines()
        new_lines = updated.splitlines()
        self.assertEqual(len(orig_lines), len(new_lines))
        diffs = [i for i in range(len(orig_lines)) if orig_lines[i] != new_lines[i]]
        self.assertEqual(len(diffs), 1)
        self.assertIn("ip:", orig_lines[diffs[0]])

    def test_comments_and_commented_out_lines_survive(self):
        update_scalar_in_file(self.path, "servers.Edge01.ip", "10.0.0.99")
        updated = self.path.read_text(encoding="utf-8")
        self.assertIn("# network: bridged-net", updated)
        self.assertIn("# a comment line", updated)

    def test_returns_false_for_unknown_path(self):
        ok = update_scalar_in_file(self.path, "servers.DoesNotExist.ip", "1.2.3.4")
        self.assertFalse(ok)
        # File must be untouched.
        self.assertEqual(self.path.read_text(encoding="utf-8"), SAMPLE)

    def test_reparsed_after_update(self):
        update_scalar_in_file(self.path, "networks.bridged-net.gateway", "10.0.0.254")
        data = parse_yaml(self.path.read_text(encoding="utf-8"))
        self.assertEqual(data["networks"]["bridged-net"]["gateway"], "10.0.0.254")
        # Unrelated sibling fields must be unaffected.
        self.assertEqual(data["networks"]["bridged-net"]["subnet"], "192.168.10.0/24")


if __name__ == "__main__":
    unittest.main()
