"""
tests/test_graphdb_tools.py
==============================
Purpose: Validate agent/graphdb_tools.py's create/status/start/stop/remove
functions against the shipped GraphDb01 example, confirming the `docker
run` command shape matches Bash4Edge's verified manageGraphDb.sh "Create"
option exactly (no volume mount, no EULA env var).
"""
import unittest
from unittest.mock import patch

from agent import graphdb_tools as gdt
from agent.config import load_config


class TestGraphDbCreate(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_dry_run_succeeds(self):
        self.assertTrue(gdt.create(self.cfg, "GraphDb01", dry_run=True))

    def test_command_matches_bash4edge_shape(self):
        with patch("agent.docker_tools.pull_image", return_value=(0, "", "")), \
             patch("agent.docker_tools.run_container", return_value=(0, "abc123", "")) as mock_run:
            gdt.create(self.cfg, "GraphDb01", dry_run=False)
            cmd = mock_run.call_args[0][0]
            self.assertEqual(cmd, [
                "docker", "run", "-d",
                "--name=GraphDb01",
                "-h", "GraphDb01",
                "--restart", "always",
                "--network", "bridged-net",
                "--ip", "192.168.10.189",
                "ontotext/graphdb:10.2.4",
            ])

    def test_unknown_graphdb_server_raises(self):
        from agent.config import ConfigError
        with self.assertRaises(ConfigError):
            gdt.create(self.cfg, "DoesNotExist", dry_run=True)


class TestGraphDbLifecycle(unittest.TestCase):
    def test_status_missing(self):
        result = gdt.status("GraphDb01", dry_run=True)
        self.assertFalse(result["exists"])

    def test_start_dry_run(self):
        self.assertTrue(gdt.start("GraphDb01", dry_run=True))

    def test_stop_dry_run(self):
        self.assertTrue(gdt.stop("GraphDb01", dry_run=True))

    def test_remove_dry_run(self):
        self.assertTrue(gdt.remove("GraphDb01", dry_run=True))

    def test_remove_stops_before_removing(self):
        with patch("agent.docker_tools.stop_container", return_value=(0, "", "")) as mock_stop, \
             patch("agent.docker_tools.remove_container", return_value=(0, "", "")) as mock_rm:
            gdt.remove("GraphDb01", dry_run=False)
            mock_stop.assert_called_once()
            mock_rm.assert_called_once()


if __name__ == "__main__":
    unittest.main()
