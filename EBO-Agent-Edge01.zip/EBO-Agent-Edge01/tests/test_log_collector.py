"""
tests/test_log_collector.py
==============================
Purpose: Validate that log_collector.collect_one() writes the three
expected diagnostic files (docker.log, inspect.json, health_report.txt)
plus attempts a trace-log extraction (via trace_tools, mocked here) into a
timestamped folder, using a temporary directory instead of the real
Downloads path so tests never touch the user's actual filesystem folder.
"""
import json
import unittest
from unittest.mock import patch
from pathlib import Path
import tempfile

from agent import log_collector as lc
from agent.config import load_config


class TestLogCollector(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()
        self.tmpdir = tempfile.TemporaryDirectory()
        # Point log collection at a temp dir for this test only.
        self.cfg.raw["log_collection"]["output_dir"] = self.tmpdir.name

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_collect_one_writes_three_files(self):
        with patch("agent.docker_tools.get_logs", return_value="sample log line"), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": True}, "RestartCount": 0}), \
             patch("agent.docker_tools.container_exists", return_value=True), \
             patch("agent.trace_tools.get_trace", return_value=[]):
            snapshot_dir = lc.collect_one(self.cfg, "Edge01")

        self.assertIsNotNone(snapshot_dir)
        files = {p.name for p in snapshot_dir.iterdir() if p.is_file()}
        self.assertEqual(
            files,
            {"Edge01_docker.log", "Edge01_inspect.json", "Edge01_health_report.txt"},
        )
        self.assertEqual(
            (snapshot_dir / "Edge01_docker.log").read_text(encoding="utf-8"),
            "sample log line",
        )
        parsed = json.loads((snapshot_dir / "Edge01_inspect.json").read_text(encoding="utf-8"))
        self.assertTrue(parsed["State"]["Running"])

    def test_trace_extraction_failure_does_not_break_collection(self):
        """A trace-log extraction failure (e.g. volume doesn't exist yet)
        must be swallowed as a warning, not propagate and abort the rest
        of the snapshot."""
        with patch("agent.docker_tools.get_logs", return_value=""), \
             patch("agent.docker_tools.inspect_container", return_value={}), \
             patch("agent.docker_tools.container_exists", return_value=True), \
             patch("agent.trace_tools.get_trace", side_effect=RuntimeError("no such volume")):
            snapshot_dir = lc.collect_one(self.cfg, "Edge01")
        self.assertIsNotNone(snapshot_dir)
        self.assertTrue((snapshot_dir / "Edge01_docker.log").exists())

    def test_disabled_collection_returns_none(self):
        self.cfg.raw["log_collection"]["enabled"] = False
        result = lc.collect_one(self.cfg, "Edge01")
        self.assertIsNone(result)

    def test_prune_keeps_only_latest_n(self):
        container_dir = Path(self.tmpdir.name) / "Edge01"
        for i in range(5):
            (container_dir / f"2026010{i}_000000").mkdir(parents=True)
        lc._prune_old_collections(container_dir, keep=2)
        remaining = sorted(p.name for p in container_dir.iterdir())
        self.assertEqual(len(remaining), 2)
        self.assertEqual(remaining, ["20260103_000000", "20260104_000000"])


if __name__ == "__main__":
    unittest.main()
