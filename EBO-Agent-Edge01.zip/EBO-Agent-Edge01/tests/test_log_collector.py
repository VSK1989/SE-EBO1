"""
tests/test_log_collector.py
==============================
Purpose: Validate collect_one() writes the expected diagnostic files plus
attempts a trace-log extraction, using a temporary directory.
"""
import json
import unittest
from unittest.mock import patch
from pathlib import Path
import tempfile

from agent import log_collector as lc
from agent.config import load_config


class TestLogCollector(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()
        self.tmpdir = tempfile.TemporaryDirectory()
        self.cfg.raw.setdefault("agentSettings", {}).setdefault("log_collection", {})["output_dir"] = self.tmpdir.name

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_collect_one_writes_three_files(self):
        with patch("agent.docker_tools.get_logs", return_value="sample log line"), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": True}, "RestartCount": 0}), \
             patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.discovery.get_runtime_ip", return_value="192.168.10.1"), \
             patch("agent.discovery.validate_connectivity", return_value=True), \
             patch("agent.trace_tools.get_trace", return_value=[]):
            snapshot_dir = lc.collect_one(self.cfg, "Edge01")

        self.assertIsNotNone(snapshot_dir)
        files = {p.name for p in snapshot_dir.iterdir() if p.is_file()}
        self.assertEqual(files, {"Edge01_docker.log", "Edge01_inspect.json", "Edge01_health_report.txt"})
        parsed = json.loads((snapshot_dir / "Edge01_inspect.json").read_text(encoding="utf-8"))
        self.assertTrue(parsed["State"]["Running"])

    def test_trace_extraction_failure_does_not_break_collection(self):
        with patch("agent.docker_tools.get_logs", return_value=""), \
             patch("agent.docker_tools.inspect_container", return_value={}), \
             patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.trace_tools.get_trace", side_effect=RuntimeError("no such volume")):
            snapshot_dir = lc.collect_one(self.cfg, "Edge01")
        self.assertIsNotNone(snapshot_dir)
        self.assertTrue((snapshot_dir / "Edge01_docker.log").exists())

    def test_disabled_collection_returns_none(self):
        self.cfg.raw["agentSettings"]["log_collection"]["enabled"] = False
        result = lc.collect_one(self.cfg, "Edge01")
        self.assertIsNone(result)

    def test_collect_one_by_ip(self):
        with patch("agent.docker_tools.get_logs", return_value=""), \
             patch("agent.docker_tools.inspect_container", return_value={}), \
             patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.trace_tools.get_trace", return_value=[]):
            snapshot_dir = lc.collect_one(self.cfg, "192.168.10.1")
        self.assertIn("Edge01", str(snapshot_dir))

    def test_prune_keeps_only_latest_n(self):
        container_dir = Path(self.tmpdir.name) / "Edge01"
        for i in range(5):
            (container_dir / f"2026010{i}_000000").mkdir(parents=True)
        lc._prune_old_collections(container_dir, keep=2)
        remaining = sorted(p.name for p in container_dir.iterdir())
        self.assertEqual(len(remaining), 2)


if __name__ == "__main__":
    unittest.main()
