"""
tests/test_config.py
=======================
Purpose: Validate that agent/config.py correctly loads the shipped
config/servers.json, resolves the Edge01 server entry and the GraphDb01
graphdb_servers entry, and raises ConfigError (instead of a raw exception)
for missing files/servers. No Docker installation is required to run
these tests.
"""
import unittest
from pathlib import Path

from agent.config import ConfigError, load_config

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class TestConfig(unittest.TestCase):
    def test_loads_shipped_config(self):
        cfg = load_config()
        self.assertIn("Edge01", cfg.list_server_names())

    def test_edge01_matches_environment_spec(self):
        cfg = load_config()
        server = cfg.get_server("Edge01")
        self.assertEqual(server.ip, "192.168.10.1")
        self.assertEqual(server.type, "ebo-enterprise-server")
        self.assertEqual(server.version, "hf-712-cp-2-5000-consolidation")

    def test_missing_file_raises_config_error(self):
        with self.assertRaises(ConfigError):
            load_config(PROJECT_ROOT / "config" / "does_not_exist.json")

    def test_unknown_server_raises_config_error(self):
        cfg = load_config()
        with self.assertRaises(ConfigError):
            cfg.get_server("DoesNotExist")

    def test_repo_image_lookup(self):
        cfg = load_config()
        image = cfg.repo_image("EnterpriseServer")
        self.assertEqual(image, "ghcr.io/schneiderelectricbuildings/ebo-enterprise-server")

    def test_graphdb_server_lookup(self):
        cfg = load_config()
        self.assertIn("GraphDb01", cfg.list_graphdb_server_names())
        gdb = cfg.get_graphdb_server("GraphDb01")
        self.assertEqual(gdb.repository, "ontotext/graphdb")
        self.assertEqual(gdb.version, "10.2.4")
        self.assertEqual(gdb.port, 7200)

    def test_unknown_graphdb_server_raises_config_error(self):
        cfg = load_config()
        with self.assertRaises(ConfigError):
            cfg.get_graphdb_server("DoesNotExist")


if __name__ == "__main__":
    unittest.main()
