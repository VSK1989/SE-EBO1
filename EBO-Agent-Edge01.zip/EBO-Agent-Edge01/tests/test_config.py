"""
tests/test_config.py
=======================
Purpose: Validate that agent/config.py correctly loads config/servers.yml
(the real YAML file, via yaml_mini.py, NOT JSON), resolves Edge01 and
GraphDb01, applies the serverSettings-default-with-per-server-override
pattern, and converts accept_eula's parsed boolean back to the literal
'Yes'/'No' string Docker needs.
"""
import unittest
from pathlib import Path

from agent.config import ConfigError, load_config

PROJECT_ROOT = Path(__file__).resolve().parent.parent


class TestConfig(unittest.TestCase):
    def test_loads_shipped_yaml_config(self):
        cfg = load_config()
        self.assertIn("Edge01", cfg.list_server_names())

    def test_edge01_matches_environment_spec(self):
        cfg = load_config()
        server = cfg.get_server("Edge01")
        self.assertEqual(server.ip, "192.168.10.1")
        self.assertEqual(server.type, "ebo-enterprise-server")
        self.assertEqual(server.version, "hf-712-cp-2-5000-consolidation")

    def test_accept_eula_is_literal_yes_string_not_bool(self):
        """Critical compatibility shim: YAML 1.1 parses 'Yes' as a Python
        bool, but NSP_ACCEPT_EULA needs the literal string 'Yes'."""
        cfg = load_config()
        server = cfg.get_server("Edge01")
        self.assertEqual(server.accept_eula, "Yes")
        self.assertIsInstance(server.accept_eula, str)

    def test_missing_file_raises_config_error(self):
        with self.assertRaises(ConfigError):
            load_config(PROJECT_ROOT / "config" / "does_not_exist.yml")

    def test_unknown_server_raises_config_error(self):
        cfg = load_config()
        with self.assertRaises(ConfigError):
            cfg.get_server("DoesNotExist")

    def test_repo_image_lookup(self):
        cfg = load_config()
        image = cfg.repo_image("EnterpriseServer")
        self.assertEqual(image, "ghcr.io/schneiderelectricbuildings/ebo-enterprise-server")

    def test_graphdb_server_lookup(self):
        cfg = load_config()
        self.assertIn("GraphDb01", cfg.list_graphdb_server_names())
        gdb = cfg.get_graphdb_server("GraphDb01")
        self.assertEqual(gdb.repository, "ontotext/graphdb")
        self.assertEqual(gdb.port, 7200)

    def test_optional_fields_are_none_not_empty_dict(self):
        """Regression test for the yaml_mini empty-dict-vs-None bug found
        and fixed during this enhancement pass."""
        cfg = load_config()
        server = cfg.get_server("Edge01")
        self.assertIsNone(server.dns)
        self.assertIsNone(server.ca_folder)
        self.assertIsNone(server.ca_bundle)

    def test_defaults_section_field_names_normalised(self):
        cfg = load_config()
        d = cfg.defaults
        self.assertEqual(d["db_folder"], "/var/sbo")
        self.assertEqual(d["db_vol_suffix"], "-db")
        self.assertEqual(d["accept_eula"], "Yes")

    def test_network_section(self):
        cfg = load_config()
        net = cfg.network
        self.assertEqual(net["name"], "bridged-net")
        self.assertEqual(net["type"], "ipvlan")

    def test_log_collection_defaults(self):
        cfg = load_config()
        lc = cfg.log_collection
        self.assertTrue(lc["enabled"])
        self.assertIn("output_dir", lc)

    def test_monitor_defaults_include_connectivity_settings(self):
        cfg = load_config()
        mon = cfg.monitor
        self.assertIn("connectivity_check_enabled", mon)
        self.assertIn("connectivity_check_port", mon)


if __name__ == "__main__":
    unittest.main()
