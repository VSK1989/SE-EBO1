"""
tests/test_container_manager.py
==================================
Purpose: Validate build_run_command()'s cross-platform network-strategy
branching (ipvlan vs bridge_ports), the CA-bundle/legacy-folder version
branch, the crash-folder existence check (regression test for a real bug
found and fixed during this enhancement pass), and resolve_target()'s
name-or-IP resolution.
"""
import unittest
from unittest.mock import patch

from agent import container_manager as cm
from agent.config import load_config, ConfigError


class TestBuildRunCommand(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()
        self.server = self.cfg.get_server("Edge01")

    def test_command_contains_expected_core_flags(self):
        with patch("agent.platform_utils.is_windows", return_value=False):
            cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertIn("--name=Edge01", joined)
        self.assertIn("--ip 192.168.10.1", joined)
        self.assertIn("--mount source=Edge01-db,target=/var/sbo", joined)
        self.assertIn("NSP_ACCEPT_EULA=Yes", joined)

    def test_linux_uses_ipvlan_static_ip(self):
        with patch("agent.platform_utils.is_windows", return_value=False):
            cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertIn("--ip 192.168.10.1", joined)
        self.assertNotIn("-p 1080:80", joined)

    def test_windows_uses_bridge_ports_not_static_ip(self):
        with patch("agent.platform_utils.is_windows", return_value=True):
            cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertNotIn("--ip 192.168.10.1", joined)
        self.assertIn("-p 1080:80", joined)
        self.assertIn("-p 1443:443", joined)

    def test_test_mode_forces_bridge_ports_even_on_linux(self):
        with patch("agent.platform_utils.is_windows", return_value=False):
            cmd = cm.build_run_command(self.cfg, self.server, test_mode=True)
        joined = " ".join(cmd)
        self.assertIn("-p 1443:443", joined)
        self.assertNotIn("--ip 192.168.10.1", joined)

    def test_crash_folder_not_mounted_when_path_does_not_exist(self):
        """Regression test: an earlier version of this code force-mounted
        /var/crash on every Linux-like host regardless of whether the path
        actually existed, which would reintroduce the exact
        'bind source path does not exist' error documented in Bash4Edge's
        own Known Issues table."""
        with patch("agent.platform_utils.is_windows", return_value=False), \
             patch("os.path.exists", return_value=False):
            cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertNotIn("/var/crash", joined)

    def test_crash_folder_mounted_when_path_exists(self):
        with patch("agent.platform_utils.is_windows", return_value=False), \
             patch("os.path.exists", return_value=True):
            cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertIn("target=/var/crash", joined)

    def test_ca_bundle_used_for_version_8_and_above(self):
        self.server.ca_bundle = "/path/to/bundle.crt"
        self.server.version = "8.0.1"
        with patch("agent.platform_utils.is_windows", return_value=False):
            cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertIn("target=/opt/sbo/etc/ca-bundle.crt,readonly", joined)

    def test_ca_folder_used_for_version_below_8(self):
        self.server.ca_folder = "/path/to/ca/folder"
        self.server.version = "7.0.3.142"
        with patch("agent.platform_utils.is_windows", return_value=False):
            cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertIn("target=/usr/local/share/ca-certificates", joined)

    def test_is_legacy_ca_folder_version(self):
        self.assertTrue(cm._is_legacy_ca_folder_version("7.0.3.142"))
        self.assertFalse(cm._is_legacy_ca_folder_version("8.0.0"))
        self.assertFalse(cm._is_legacy_ca_folder_version("hf-712-cp-2-5000-consolidation"))


class TestResolveTarget(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_resolves_by_exact_name(self):
        server = cm.resolve_target(self.cfg, "Edge01")
        self.assertEqual(server.name, "Edge01")

    def test_resolves_by_configured_ip(self):
        server = cm.resolve_target(self.cfg, "192.168.10.1")
        self.assertEqual(server.name, "Edge01")

    def test_resolves_by_runtime_ip(self):
        with patch("agent.discovery.get_runtime_ip", return_value="10.0.0.50"):
            server = cm.resolve_target(self.cfg, "10.0.0.50")
        self.assertEqual(server.name, "Edge01")

    def test_unknown_identifier_raises(self):
        with patch("agent.discovery.get_runtime_ip", return_value=None):
            with self.assertRaises(ConfigError):
                cm.resolve_target(self.cfg, "NotAServer")


class TestLifecycleDryRun(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_start_dry_run_succeeds(self):
        self.assertTrue(cm.start(self.cfg, "Edge01", dry_run=True))

    def test_start_by_ip_dry_run_succeeds(self):
        self.assertTrue(cm.start(self.cfg, "192.168.10.1", dry_run=True))

    def test_stop_dry_run_succeeds(self):
        self.assertTrue(cm.stop("Edge01", cfg=self.cfg, dry_run=True))

    def test_status_dry_run_reports_missing(self):
        result = cm.status("Edge01", cfg=self.cfg, dry_run=True)
        self.assertFalse(result["exists"])

    def test_upgrade_dry_run_succeeds(self):
        self.assertTrue(cm.upgrade(self.cfg, "Edge01", "hf-713-cp-1-1000", dry_run=True))


if __name__ == "__main__":
    unittest.main()
