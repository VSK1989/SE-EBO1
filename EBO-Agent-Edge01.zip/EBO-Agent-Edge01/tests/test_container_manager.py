"""
tests/test_container_manager.py
==================================
Purpose: Validate that container_manager.build_run_command() produces a
correct, complete `docker run` argument list for the configured Edge01
server (name, ip, image, mounts, env vars), including the test_mode
port-forwarding branch and the CA bundle / legacy CA folder version-aware
branch ported from start.py, and that start()/upgrade() correctly branch
between "create new" and "start existing" without requiring a real Docker
daemon (achieved via dry_run=True, which still exercises every branch of
the real code, just without subprocess calls).
"""
import unittest

from agent import container_manager as cm
from agent.config import load_config


class TestBuildRunCommand(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()
        self.server = self.cfg.get_server("Edge01")

    def test_command_contains_expected_core_flags(self):
        cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertIn("--name=Edge01", joined)
        self.assertIn("-h Edge01", joined)
        self.assertIn("--ip 192.168.10.1", joined)
        self.assertIn(
            "ghcr.io/schneiderelectricbuildings/ebo-enterprise-server:hf-712-cp-2-5000-consolidation",
            joined,
        )
        self.assertIn("--mount source=Edge01-db,target=/var/sbo", joined)
        self.assertIn("NSP_ACCEPT_EULA=Yes", joined)

    def test_command_is_a_flat_list_of_strings(self):
        cmd = cm.build_run_command(self.cfg, self.server)
        self.assertTrue(all(isinstance(tok, str) for tok in cmd))

    def test_test_mode_uses_port_forwarding_not_ip(self):
        cmd = cm.build_run_command(self.cfg, self.server, test_mode=True)
        joined = " ".join(cmd)
        self.assertNotIn("--ip", joined)
        self.assertNotIn("--network", joined)
        self.assertIn("-p 1080:80", joined)
        self.assertIn("-p 1443:443", joined)
        self.assertIn("-p 14444:4444", joined)

    def test_normal_mode_uses_network_and_ip(self):
        cmd = cm.build_run_command(self.cfg, self.server, test_mode=False)
        joined = " ".join(cmd)
        self.assertIn("--network bridged-net", joined)
        self.assertIn("--ip 192.168.10.1", joined)
        self.assertNotIn("-p 1080:80", joined)

    def test_ca_bundle_used_for_version_8_and_above(self):
        self.server.ca_bundle = "/path/to/bundle.crt"
        self.server.version = "8.0.1"
        cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertIn("target=/opt/sbo/etc/ca-bundle.crt,readonly", joined)

    def test_ca_folder_used_for_version_below_8(self):
        self.server.ca_folder = "/path/to/ca/folder"
        self.server.version = "7.0.3.142"
        cmd = cm.build_run_command(self.cfg, self.server)
        joined = " ".join(cmd)
        self.assertIn("target=/usr/local/share/ca-certificates", joined)

    def test_is_legacy_ca_folder_version(self):
        self.assertTrue(cm._is_legacy_ca_folder_version("7.0.3.142"))
        self.assertFalse(cm._is_legacy_ca_folder_version("8.0.0"))
        self.assertFalse(cm._is_legacy_ca_folder_version("hf-712-cp-2-5000-consolidation"))


class TestLifecycleDryRun(unittest.TestCase):
    """These exercise the full start/stop/restart/upgrade/status code paths
    in dry-run mode: no real docker daemon is touched, but every branch
    (container_exists, is_running, network_exists, etc.) still runs."""

    def setUp(self):
        self.cfg = load_config()

    def test_start_dry_run_succeeds(self):
        self.assertTrue(cm.start(self.cfg, "Edge01", dry_run=True))

    def test_start_test_mode_dry_run_succeeds(self):
        self.assertTrue(cm.start(self.cfg, "Edge01", dry_run=True, test_mode=True))

    def test_stop_dry_run_succeeds(self):
        self.assertTrue(cm.stop("Edge01", dry_run=True))

    def test_restart_dry_run_succeeds(self):
        self.assertTrue(cm.restart("Edge01", dry_run=True))

    def test_status_dry_run_reports_missing(self):
        result = cm.status("Edge01", dry_run=True)
        self.assertFalse(result["exists"])

    def test_upgrade_dry_run_succeeds(self):
        self.assertTrue(cm.upgrade(self.cfg, "Edge01", "hf-713-cp-1-1000", dry_run=True))


if __name__ == "__main__":
    unittest.main()
