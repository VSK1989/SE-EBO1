"""
tests/test_password_reset.py
===============================
Purpose: Validate the marker-file mechanism, PORTED/VERIFIED from
Bash4Edge's manageServers.sh "Password Reset" option, including name-or-IP
resolution.
"""
import unittest
from unittest.mock import patch

from agent import password_reset as pr
from agent.config import load_config


class TestPasswordReset(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_dry_run_succeeds(self):
        self.assertTrue(pr.set_password_reset_mode(self.cfg, "Edge01", dry_run=True))

    def test_resolves_by_ip(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(0, "", "")) as m:
            pr.set_password_reset_mode(self.cfg, "192.168.10.1", dry_run=False)
            self.assertEqual(m.call_args.kwargs["volume"], "Edge01-db")

    def test_does_not_stop_or_restart_container(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(0, "", "")), \
             patch("agent.docker_tools.stop_container") as mock_stop, \
             patch("agent.docker_tools.restart_container") as mock_restart:
            pr.set_password_reset_mode(self.cfg, "Edge01", dry_run=False)
            mock_stop.assert_not_called()
            mock_restart.assert_not_called()

    def test_failure_is_reported(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(1, "", "boom")):
            self.assertFalse(pr.set_password_reset_mode(self.cfg, "Edge01", dry_run=False))


if __name__ == "__main__":
    unittest.main()
