"""
tests/test_password_reset.py
===============================
Purpose: Validate agent/password_reset.py's marker-file mechanism, PORTED
and verified from Bash4Edge's manageServers.sh "Password Reset" option:
an ephemeral container mounts the server's database volume and touches
db/reset/r0.txt -- no stop/restart of the live server container occurs.
"""
import unittest
from unittest.mock import patch

from agent import password_reset as pr
from agent.config import load_config


class TestPasswordReset(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_dry_run_succeeds(self):
        ok = pr.set_password_reset_mode(self.cfg, "Edge01", dry_run=True)
        self.assertTrue(ok)

    def test_uses_ephemeral_container_against_volume_only(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume",
                   return_value=(0, "", "")) as mock_ephemeral:
            ok = pr.set_password_reset_mode(self.cfg, "Edge01", dry_run=False)
            self.assertTrue(ok)
            mock_ephemeral.assert_called_once()
            kwargs = mock_ephemeral.call_args.kwargs
            self.assertEqual(kwargs["volume"], "Edge01-db")
            self.assertEqual(kwargs["bind_source"], None)
            self.assertIn("db/reset/r0.txt", kwargs["shell_command"])

    def test_does_not_stop_or_restart_container(self):
        """Matches the verified Bash4Edge source exactly: no stop, no
        restart -- the live container is left completely untouched."""
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(0, "", "")), \
             patch("agent.docker_tools.stop_container") as mock_stop, \
             patch("agent.docker_tools.restart_container") as mock_restart, \
             patch("agent.docker_tools.start_existing_container") as mock_start:
            pr.set_password_reset_mode(self.cfg, "Edge01", dry_run=False)
            mock_stop.assert_not_called()
            mock_restart.assert_not_called()
            mock_start.assert_not_called()

    def test_failure_is_reported(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume",
                   return_value=(1, "", "boom")):
            ok = pr.set_password_reset_mode(self.cfg, "Edge01", dry_run=False)
            self.assertFalse(ok)


if __name__ == "__main__":
    unittest.main()
