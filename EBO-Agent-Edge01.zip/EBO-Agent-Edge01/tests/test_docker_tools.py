"""
tests/test_docker_tools.py
=============================
Purpose: Validate the low-level Docker CLI wrappers, including the new
retry-on-transient-error logic and cross-platform bind-path normalisation,
WITHOUT requiring a real Docker Desktop installation.
"""
import unittest
from unittest.mock import patch, MagicMock

from agent import docker_tools as dt


class TestValidateToken(unittest.TestCase):
    def test_allows_normal_values(self):
        self.assertEqual(dt.validate_token("Edge01", "name"), "Edge01")
        self.assertEqual(dt.validate_token("192.168.10.1", "ip"), "192.168.10.1")

    def test_allows_none_and_empty(self):
        self.assertIsNone(dt.validate_token(None, "dns"))
        self.assertEqual(dt.validate_token("", "dns"), "")

    def test_allows_comma_separated_no_proxy(self):
        value = "localhost,127.0.0.1,example.local"
        self.assertEqual(dt.validate_token(value, "no_proxy"), value)

    def test_allows_windows_backslash_paths(self):
        value = r"C:\Users\SESA367373\Downloads\DOCKER\CONTAINER1"
        self.assertEqual(dt.validate_token(value, "bind_source"), value)

    def test_rejects_injection_attempts(self):
        for bad in ["Edge01; rm -rf /", "Edge01 && echo pwned", "$(whoami)", "`id`", "a b"]:
            with self.assertRaises(ValueError):
                dt.validate_token(bad, "name")


class TestExeDryRun(unittest.TestCase):
    def test_dry_run_does_not_call_subprocess(self):
        with patch("subprocess.run") as mock_run:
            rc, out, err = dt.exe(["docker", "run", "-d", "whatever"], dry_run=True)
            mock_run.assert_not_called()
            self.assertEqual(rc, 0)


class TestExeRetry(unittest.TestCase):
    def test_transient_error_is_retried(self):
        transient = MagicMock(returncode=1, stdout="", stderr="Error during connect: timeout")
        success = MagicMock(returncode=0, stdout="ok", stderr="")
        with patch("subprocess.run", side_effect=[transient, success]), \
             patch("time.sleep"):
            rc, out, err = dt.exe(["docker", "ps"], retries=1, retry_delay=0)
        self.assertEqual(rc, 0)
        self.assertEqual(out, "ok")

    def test_non_transient_error_is_not_retried(self):
        failure = MagicMock(returncode=1, stdout="", stderr="no such image")
        with patch("subprocess.run", return_value=failure) as mock_run:
            rc, out, err = dt.exe(["docker", "run"], retries=3, retry_delay=0)
        mock_run.assert_called_once()
        self.assertEqual(rc, 1)

    def test_retries_exhausted_returns_last_failure(self):
        transient = MagicMock(returncode=1, stdout="", stderr="cannot connect to the docker daemon")
        with patch("subprocess.run", return_value=transient) as mock_run, \
             patch("time.sleep"):
            rc, out, err = dt.exe(["docker", "ps"], retries=2, retry_delay=0)
        self.assertEqual(mock_run.call_count, 3)  # initial + 2 retries
        self.assertEqual(rc, 1)


class TestInspectContainer(unittest.TestCase):
    def test_parses_inspect_json(self):
        fake_inspect = '[{"State": {"Running": true, "Status": "running"}, "RestartCount": 0}]'
        completed = MagicMock(returncode=0, stdout=fake_inspect, stderr="")
        with patch("subprocess.run", return_value=completed):
            info = dt.inspect_container("Edge01")
            self.assertTrue(info["State"]["Running"])

    def test_returns_none_on_missing_container(self):
        completed = MagicMock(returncode=1, stdout="", stderr="No such object")
        with patch("subprocess.run", return_value=completed):
            info = dt.inspect_container("DoesNotExist")
            self.assertIsNone(info)

    def test_is_running_true(self):
        fake_inspect = '[{"State": {"Running": true}, "RestartCount": 0}]'
        completed = MagicMock(returncode=0, stdout=fake_inspect, stderr="")
        with patch("subprocess.run", return_value=completed):
            self.assertTrue(dt.is_running("Edge01"))


class TestDockerAvailable(unittest.TestCase):
    def test_docker_not_on_path(self):
        with patch("subprocess.run", side_effect=FileNotFoundError()):
            self.assertFalse(dt.docker_available())


class TestCrossPlatformBindPaths(unittest.TestCase):
    def test_copy_from_container_normalizes_windows_path_under_wsl(self):
        with patch("agent.platform_utils.is_wsl", return_value=True), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            dt.copy_from_container("Edge01", "/var/sbo/backup/.", r"C:\Backups\Edge01")
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args[-1], "/mnt/c/Backups/Edge01")

    def test_run_ephemeral_against_volume_normalizes_bind_source(self):
        with patch("agent.platform_utils.is_wsl", return_value=True), \
             patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            dt.run_ephemeral_against_volume(
                image="ubuntu:focal", volume="Edge01-db", volume_target="/var/sbo",
                bind_source=r"C:\Traces\Edge01", bind_target="/mnt",
                shell_command="cp /var/sbo/db/logs/trace* /mnt/",
            )
            called_args = mock_run.call_args[0][0]
            joined = " ".join(called_args)
            self.assertIn("source=/mnt/c/Traces/Edge01", joined)


class TestRunEphemeralAgainstVolume(unittest.TestCase):
    def test_builds_command_matching_get_trace_log(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            dt.run_ephemeral_against_volume(
                image="ubuntu:focal", volume="Edge01-db", volume_target="/var/sbo",
                bind_source="/tmp/dest", bind_target="/mnt",
                shell_command="cp /var/sbo/db/logs/trace* /mnt/",
            )
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, [
                "docker", "run", "--rm",
                "--mount", "type=bind,source=/tmp/dest,target=/mnt",
                "--mount", "source=Edge01-db,target=/var/sbo",
                "ubuntu:focal", "bash", "-c", "cp /var/sbo/db/logs/trace* /mnt/",
            ])


if __name__ == "__main__":
    unittest.main()
