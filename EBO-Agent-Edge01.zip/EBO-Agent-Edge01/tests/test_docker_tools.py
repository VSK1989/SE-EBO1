"""
tests/test_docker_tools.py
=============================
Purpose: Validate the low-level Docker CLI wrappers in agent/docker_tools.py
WITHOUT requiring a real Docker Desktop installation, by:
  (a) exercising dry_run=True paths directly, and
  (b) patching subprocess.run to simulate docker CLI responses for the
      non-dry-run code paths (e.g. JSON parsing of `docker inspect`).
Also validates that validate_token() rejects command-injection attempts
while accepting the two deliberately widened characters (comma, backslash)
needed for no_proxy lists and Windows-style bind-mount paths.
"""
import unittest
from unittest.mock import patch, MagicMock

from agent import docker_tools as dt


class TestValidateToken(unittest.TestCase):
    def test_allows_normal_values(self):
        self.assertEqual(dt.validate_token("Edge01", "name"), "Edge01")
        self.assertEqual(dt.validate_token("192.168.10.1", "ip"), "192.168.10.1")
        self.assertEqual(
            dt.validate_token("hf-712-cp-2-5000-consolidation", "version"),
            "hf-712-cp-2-5000-consolidation",
        )

    def test_allows_none_and_empty(self):
        self.assertIsNone(dt.validate_token(None, "dns"))
        self.assertEqual(dt.validate_token("", "dns"), "")

    def test_allows_comma_separated_no_proxy(self):
        value = "localhost,127.0.0.1,example.local"
        self.assertEqual(dt.validate_token(value, "no_proxy"), value)

    def test_allows_windows_backslash_paths(self):
        value = r"C:\Users\SESA367373\Downloads\DOCKER\CONTAINER1"
        self.assertEqual(dt.validate_token(value, "bind_source"), value)

    def test_rejects_injection_attempts(self):
        for bad in ["Edge01; rm -rf /", "Edge01 && echo pwned", "$(whoami)", "`id`", "a b"]:
            with self.assertRaises(ValueError):
                dt.validate_token(bad, "name")


class TestExeDryRun(unittest.TestCase):
    def test_dry_run_does_not_call_subprocess(self):
        with patch("subprocess.run") as mock_run:
            rc, out, err = dt.exe(["docker", "run", "-d", "whatever"], dry_run=True)
            mock_run.assert_not_called()
            self.assertEqual(rc, 0)


class TestInspectContainer(unittest.TestCase):
    def test_parses_inspect_json(self):
        fake_inspect = '[{"State": {"Running": true, "Status": "running"}, "RestartCount": 0}]'
        completed = MagicMock(returncode=0, stdout=fake_inspect, stderr="")
        with patch("subprocess.run", return_value=completed):
            info = dt.inspect_container("Edge01")
            self.assertTrue(info["State"]["Running"])

    def test_returns_none_on_missing_container(self):
        completed = MagicMock(returncode=1, stdout="", stderr="No such object")
        with patch("subprocess.run", return_value=completed):
            info = dt.inspect_container("DoesNotExist")
            self.assertIsNone(info)

    def test_is_running_true(self):
        fake_inspect = '[{"State": {"Running": true}, "RestartCount": 0}]'
        completed = MagicMock(returncode=0, stdout=fake_inspect, stderr="")
        with patch("subprocess.run", return_value=completed):
            self.assertTrue(dt.is_running("Edge01"))

    def test_is_running_false_when_missing(self):
        completed = MagicMock(returncode=1, stdout="", stderr="No such object")
        with patch("subprocess.run", return_value=completed):
            self.assertFalse(dt.is_running("Edge01"))


class TestDockerAvailable(unittest.TestCase):
    def test_docker_not_on_path(self):
        with patch("subprocess.run", side_effect=FileNotFoundError()):
            self.assertFalse(dt.docker_available())


class TestDockerExecAndCp(unittest.TestCase):
    def test_docker_exec_builds_correct_command(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="file1.xbk", stderr="")
            dt.docker_exec("Edge01", ["ls", "/var/sbo/db_backup/LocalBackup"])
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, ["docker", "exec", "Edge01", "ls", "/var/sbo/db_backup/LocalBackup"])

    def test_docker_exec_rejects_bad_args(self):
        with self.assertRaises(ValueError):
            dt.docker_exec("Edge01", ["ls; rm -rf /"])

    def test_copy_from_container_builds_correct_command(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            dt.copy_from_container("Edge01", "/var/sbo/db_backup/LocalBackup/.", "/tmp/out")
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, ["docker", "cp", "Edge01:/var/sbo/db_backup/LocalBackup/.", "/tmp/out"])

    def test_copy_to_container_builds_correct_command(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            dt.copy_to_container("/tmp/in.xbk", "Edge01", "/var/sbo/db_backup/LocalBackup/in.xbk")
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, ["docker", "cp", "/tmp/in.xbk", "Edge01:/var/sbo/db_backup/LocalBackup/in.xbk"])


class TestRunEphemeralAgainstVolume(unittest.TestCase):
    def test_builds_command_matching_get_trace_log(self):
        """Confirms the command shape matches get-trace.log's verified
        `docker run --rm --mount type=bind,... --mount source=...,target=...
        <image> bash -c "<cmd>"` structure exactly."""
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            dt.run_ephemeral_against_volume(
                image="ubuntu:focal",
                volume="Edge01-db",
                volume_target="/var/sbo",
                bind_source="/tmp/dest",
                bind_target="/mnt",
                shell_command="cp /var/sbo/db/logs/trace* /mnt/",
            )
            called_args = mock_run.call_args[0][0]
            self.assertEqual(called_args, [
                "docker", "run", "--rm",
                "--mount", "type=bind,source=/tmp/dest,target=/mnt",
                "--mount", "source=Edge01-db,target=/var/sbo",
                "ubuntu:focal", "bash", "-c", "cp /var/sbo/db/logs/trace* /mnt/",
            ])

    def test_without_bind_mount(self):
        with patch("subprocess.run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
            dt.run_ephemeral_against_volume(
                image="my-image:1",
                volume="Edge01-db",
                volume_target="/var/sbo",
                bind_source=None,
                bind_target=None,
                shell_command="touch /var/sbo/db/reset/r0.txt",
            )
            called_args = mock_run.call_args[0][0]
            self.assertNotIn("type=bind", " ".join(called_args))


if __name__ == "__main__":
    unittest.main()
