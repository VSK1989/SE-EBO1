"""
tests/test_trace_tools.py
============================
Purpose: Validate agent/trace_tools.py's get_trace(), a PORTED and
verified re-implementation of get-trace.log, using a temporary directory
as the destination and mocked docker_tools calls (no real Docker daemon
required).
"""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from agent import trace_tools as tt
from agent.config import load_config


class TestGetTrace(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()
        self.tmpdir = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_dry_run_succeeds_and_returns_empty_list(self):
        result = tt.get_trace(self.cfg, "Edge01", self.tmpdir.name, dry_run=True)
        self.assertEqual(result, [])

    def test_builds_correct_ephemeral_command(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume",
                   return_value=(0, "", "")) as mock_ephemeral:
            tt.get_trace(self.cfg, "Edge01", self.tmpdir.name, dry_run=False)
            mock_ephemeral.assert_called_once()
            kwargs = mock_ephemeral.call_args.kwargs
            self.assertEqual(kwargs["image"], "ubuntu:focal")
            self.assertEqual(kwargs["volume"], "Edge01-db")
            self.assertEqual(kwargs["volume_target"], "/var/sbo")
            self.assertEqual(kwargs["bind_target"], "/mnt")
            self.assertIn("trace*", kwargs["shell_command"])
            self.assertIn("/mnt/", kwargs["shell_command"])

    def test_creates_destination_folder_if_missing(self):
        new_dest = str(Path(self.tmpdir.name) / "nested" / "trace_out")
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(0, "", "")):
            tt.get_trace(self.cfg, "Edge01", new_dest, dry_run=False)
        self.assertTrue(Path(new_dest).exists())

    def test_returns_none_on_docker_failure(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume",
                   return_value=(1, "", "no such volume")):
            result = tt.get_trace(self.cfg, "Edge01", self.tmpdir.name, dry_run=False)
            self.assertIsNone(result)

    def test_finds_extracted_trace_files(self):
        # Simulate the ephemeral container having "copied" files by writing
        # them directly into the temp destination (standing in for what the
        # real `cp` inside the disposable container would produce).
        (Path(self.tmpdir.name) / "trace.log").write_text("line1\n")
        (Path(self.tmpdir.name) / "trace.log.old").write_text("line0\n")
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(0, "", "")):
            result = tt.get_trace(self.cfg, "Edge01", self.tmpdir.name, dry_run=False)
        self.assertEqual(len(result), 2)


if __name__ == "__main__":
    unittest.main()
