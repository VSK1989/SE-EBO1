"""
tests/test_trace_tools.py
============================
Purpose: Validate get_trace(), PORTED/VERIFIED from get-trace.log, using a
temporary directory and mocked docker_tools calls.
"""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from agent import trace_tools as tt
from agent.config import load_config


class TestGetTrace(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()
        self.tmpdir = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmpdir.cleanup()

    def test_dry_run_succeeds_and_returns_empty_list(self):
        result = tt.get_trace(self.cfg, "Edge01", self.tmpdir.name, dry_run=True)
        self.assertEqual(result, [])

    def test_resolves_by_ip(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(0, "", "")) as m:
            tt.get_trace(self.cfg, "192.168.10.1", self.tmpdir.name, dry_run=False)
            self.assertEqual(m.call_args.kwargs["volume"], "Edge01-db")

    def test_builds_correct_ephemeral_command(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(0, "", "")) as mock_ephemeral:
            tt.get_trace(self.cfg, "Edge01", self.tmpdir.name, dry_run=False)
            kwargs = mock_ephemeral.call_args.kwargs
            self.assertEqual(kwargs["image"], "ubuntu:focal")
            self.assertEqual(kwargs["volume"], "Edge01-db")
            self.assertIn("trace*", kwargs["shell_command"])

    def test_returns_none_on_docker_failure(self):
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(1, "", "no such volume")):
            result = tt.get_trace(self.cfg, "Edge01", self.tmpdir.name, dry_run=False)
            self.assertIsNone(result)

    def test_finds_extracted_trace_files(self):
        (Path(self.tmpdir.name) / "trace.log").write_text("line1\n")
        with patch("agent.docker_tools.run_ephemeral_against_volume", return_value=(0, "", "")):
            result = tt.get_trace(self.cfg, "Edge01", self.tmpdir.name, dry_run=False)
        self.assertEqual(len(result), 1)


if __name__ == "__main__":
    unittest.main()
