"""
tests/test_decision_engine.py
================================
Purpose: Validate the rule-based decision engine's classification logic
(missing / stopped / running / restart_loop) and its log-pattern scanning,
using mocked docker_tools responses so no real Docker daemon is required.
"""
import unittest
from unittest.mock import patch

from agent import decision_engine as de
from agent.config import load_config


class TestDecisionEngine(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_missing_container_recommends_create(self):
        with patch("agent.docker_tools.container_exists", return_value=False):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "missing")
        self.assertEqual(decision.action, "create")

    def test_stopped_container_recommends_restart(self):
        with patch("agent.docker_tools.container_exists", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": False}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs", return_value=""):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "stopped")
        self.assertEqual(decision.action, "restart")

    def test_restart_loop_triggers_alert(self):
        with patch("agent.docker_tools.container_exists", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": False}, "RestartCount": 10}), \
             patch("agent.docker_tools.get_logs", return_value=""):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "restart_loop")
        self.assertEqual(decision.action, "alert")

    def test_healthy_running_container(self):
        with patch("agent.docker_tools.container_exists", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": True}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs", return_value="server started normally"):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "running")
        self.assertEqual(decision.action, "none")

    def test_eula_pattern_detected_and_alerted(self):
        with patch("agent.docker_tools.container_exists", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": True}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs",
                   return_value="Waiting for EULA acceptance before starting..."):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.action, "alert")
        self.assertTrue(any("EULA" in f for f in decision.findings))

    def test_auto_restart_disabled_by_default_does_not_act(self):
        # monitor.auto_restart is False in the shipped config -> decide_and_act
        # must only report, never call container_manager.restart/start.
        counters = {}
        with patch("agent.docker_tools.container_exists", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": False}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs", return_value=""), \
             patch("agent.container_manager.restart") as mock_restart:
            decision = de.decide_and_act(self.cfg, "Edge01", counters)
            mock_restart.assert_not_called()
        self.assertEqual(decision.action, "restart")


if __name__ == "__main__":
    unittest.main()
