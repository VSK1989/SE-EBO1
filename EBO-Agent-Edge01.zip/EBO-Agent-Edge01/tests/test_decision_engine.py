"""
tests/test_decision_engine.py
================================
Purpose: Validate the rule-based decision engine, including the NEW
"unreachable" state driven by connectivity validation.
"""
import unittest
from unittest.mock import patch

from agent import decision_engine as de
from agent.config import load_config


class TestDecisionEngine(unittest.TestCase):
    def setUp(self):
        self.cfg = load_config()

    def test_missing_container_recommends_create(self):
        with patch("agent.discovery.container_exists_cached", return_value=False):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "missing")
        self.assertEqual(decision.action, "create")

    def test_stopped_container_recommends_restart(self):
        with patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": False}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs", return_value=""):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "stopped")
        self.assertEqual(decision.action, "restart")

    def test_restart_loop_triggers_alert(self):
        with patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": False}, "RestartCount": 10}), \
             patch("agent.docker_tools.get_logs", return_value=""):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "restart_loop")

    def test_healthy_running_and_reachable(self):
        with patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": True}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs", return_value="server started normally"), \
             patch("agent.discovery.get_runtime_ip", return_value="192.168.10.1"), \
             patch("agent.discovery.validate_connectivity", return_value=True):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "running")
        self.assertEqual(decision.action, "none")

    def test_running_but_unreachable(self):
        """NEW: a container can be 'running' per Docker, but unreachable
        over the network (e.g. IP drift, firewall) -- this must now be
        surfaced distinctly rather than reported as healthy."""
        with patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": True}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs", return_value=""), \
             patch("agent.discovery.get_runtime_ip", return_value="192.168.10.200"), \
             patch("agent.discovery.validate_connectivity", return_value=False):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.state, "unreachable")
        self.assertEqual(decision.action, "alert")

    def test_eula_pattern_detected_and_alerted(self):
        with patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": True}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs", return_value="Waiting for EULA acceptance..."), \
             patch("agent.discovery.get_runtime_ip", return_value="192.168.10.1"), \
             patch("agent.discovery.validate_connectivity", return_value=True):
            decision = de.evaluate(self.cfg, "Edge01")
        self.assertEqual(decision.action, "alert")
        self.assertTrue(any("EULA" in f for f in decision.findings))

    def test_auto_restart_disabled_by_default_does_not_act(self):
        counters = {}
        with patch("agent.discovery.container_exists_cached", return_value=True), \
             patch("agent.docker_tools.inspect_container",
                   return_value={"State": {"Running": False}, "RestartCount": 0}), \
             patch("agent.docker_tools.get_logs", return_value=""), \
             patch("agent.container_manager.restart") as mock_restart:
            decision = de.decide_and_act(self.cfg, "Edge01", counters)
            mock_restart.assert_not_called()
        self.assertEqual(decision.action, "restart")


if __name__ == "__main__":
    unittest.main()
