#!/usr/bin/env python3
"""
run_agent.py
=============
Purpose
-------
Top-level launcher for the EBO Docker Agent. Adds the project root to
sys.path and delegates to agent.agent.main().

Usage examples
--------------
    python run_agent.py list
    python run_agent.py discover
    python run_agent.py validate
    python run_agent.py sync-ip
    python run_agent.py auto --once
    python run_agent.py status Edge01
    python run_agent.py status 192.168.10.1
    python run_agent.py --dry-run start Edge01
    python run_agent.py monitor --once
"""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent.agent import main  # noqa: E402

if __name__ == "__main__":
    main()
