#!/usr/bin/env python3
"""
run_agent.py
=============
Purpose
-------
Top-level launcher script for the EBO Docker Agent. This is the single file
you (or a VS Code launch/task configuration) run directly; it exists so the
`agent` package can be imported the same way whether you run it from VS
Code's Run/Debug panel, an integrated terminal, or a double-click-style
invocation, without needing to `pip install` the project or fiddle with
PYTHONPATH.

Functionality
-------------
Adds the project root to sys.path (so `import agent` always resolves
regardless of the current working directory) and then delegates
immediately to agent.agent.main().

How it interacts with other modules
------------------------------------
Calls agent.agent.main(), which parses CLI arguments and dispatches to
agent.container_manager / agent.backup_tools / agent.password_reset /
agent.trace_tools / agent.graphdb_tools / agent.decision_engine /
agent.log_collector as appropriate.

Configuration requirements
---------------------------
None directly -- see agent/config.py and config/servers.json.

Usage examples
--------------
    python run_agent.py list
    python run_agent.py status Edge01
    python run_agent.py start Edge01
    python run_agent.py --dry-run start Edge01
    python run_agent.py start Edge01 --test-mode
    python run_agent.py monitor --once
    python run_agent.py collect-logs Edge01
    python run_agent.py list-backups Edge01
    python run_agent.py copy-backups Edge01 C:\\Backups\\Edge01
    python run_agent.py restore-backup Edge01 hf-712-cp-2-5000-consolidation "Server 1 2022-09-09 14_12_36_5.0.0.1082.xbk" ConfigurationOnly
    python run_agent.py password-reset-mode Edge01
    python run_agent.py get-trace Edge01 C:\\Traces\\Edge01
    python run_agent.py graphdb create GraphDb01
"""
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from agent.agent import main  # noqa: E402

if __name__ == "__main__":
    main()
