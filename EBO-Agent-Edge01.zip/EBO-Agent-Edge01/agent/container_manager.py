"""
agent/container_manager.py
============================
Purpose
-------
High-level container LIFECYCLE operations (start / stop / restart / upgrade
/ status / remove) for the EBO servers described in config/servers.json.
This is the Python re-implementation of the logic found in the reviewed
start.py and upgrade.py sample scripts, adapted to:
  - read parameters from config/servers.json instead of requiring them to
    be re-typed as argparse flags every time,
  - build the `docker run` command as a LIST (like start.py, not the
    shell-string approach in teststart.py) and validate every token, and
  - support a --dry-run mode for safe validation (see docker_tools.py).

Line-by-line lineage from start.py
-------------------------------------
build_run_command() below reproduces, in order, every flag start.py's run()
function assembled into its `cmd` list:
  --name=, -h, --ulimit core=-1, --restart always, --network, the two
  mandatory -e vars (NSP_ACCEPT_EULA, Semantic_Db_URL), the proxy -e vars
  (with the same "explicit value wins, else host env var" fallback order),
  --ip, the --mount for the database volume, the optional --mount for
  --ca-bundle OR the legacy --ca-folder (see below), the conditional
  /var/crash mount, the optional --dns, and finally the image tag. The only
  functional difference is that `name`, `version`, `ip`, etc. are now read
  from a ServerConfig object (sourced from config/servers.json) instead of
  argparse.Namespace.

CA bundle vs. legacy CA folder (ported precisely from start.py)
-------------------------------------------------------------------
start.py contains a version-aware branch: for server versions below 8.x, it
mounts a whole --ca-folder at /usr/local/share/ca-certificates (the legacy
behaviour); for version 8.0 and newer, it instead mounts a single
--ca-bundle PEM file, read-only, at /opt/sbo/etc/ca-bundle.crt, and will
refuse to start (SystemExit) if the wrong one of the two is supplied for a
given version. _is_legacy_ca_folder_version() below is a direct port of
start.py's helper of the same purpose.

Test / quick-start mode (from readme.md's "useful docker commands")
-------------------------------------------------------------------
readme.md's "A few useful docker commands" section shows a manual
`docker run` example used "if you want to play with a server without the
need to talk to devices": it omits --network/--ip entirely and instead
publishes ports with -p host:container (e.g. -p 1080:80 -p 1443:443
-p 14444:4444), so the server can be reached at https://localhost:1443
without any IPvlan network being configured at all. build_run_command()
supports this as an optional `test_mode` flag, documented in README.md.

Functionality
-------------
- build_run_command(cfg, server, test_mode=False): see lineage notes above.
- ensure_network(cfg, dry_run): creates the configured ipvlan network
  (bridged-net by default) if it does not already exist, re-implementing
  the repo's ./create-bridged-network <subnet> <gateway> <interface> script.
- start(name, test_mode=False): creates+starts the container if it does not
  exist yet, or simply `docker start`s it if it was previously created and
  is stopped.
- stop(name) / restart(name) / remove(name): thin, validated wrappers.
- status(name): returns a small dict summarising running state, IP,
  restart count and image - used by the CLI `status` command and by
  decision_engine.py.
- upgrade(name, new_version): re-implements upgrade.py's flow (stop old
  container, run its prepare-upgrade helper, remove old container, start
  new version, print the upgrade log) using the JSON config for all other
  parameters, instead of re-invoking argparse via sys.argv like the
  original script did.

How it interacts with other modules
------------------------------------
- Reads server/network/default settings from agent.config.AgentConfig.
- Delegates every actual Docker CLI call to agent.docker_tools (never
  calls subprocess directly).
- Is called by agent.py for the start/stop/restart/upgrade/status CLI
  subcommands, and by decision_engine.py when an auto-restart action is
  decided upon.

Configuration requirements
---------------------------
Needs a valid ServerConfig entry (see agent/config.py) for the container
name being operated on, plus the shared "network" and "defaults" sections
of config/servers.json.
"""
from __future__ import annotations

import logging
import os
import re
from typing import List

from . import docker_tools as dt
from .config import AgentConfig, ServerConfig

logger = logging.getLogger(__name__)

# Default host:container port map used by test_mode, taken verbatim from
# readme.md's example (-p 1080:80 -p 1443:443 -p14444:4444).
TEST_MODE_PORTS = {"80": "1080", "443": "1443", "4444": "14444"}


def _is_legacy_ca_folder_version(version: str) -> bool:
    """Direct port of start.py's _is_legacy_ca_folder_version(): True for
    versions below 8.x, where --ca-folder is still required instead of
    --ca-bundle."""
    match = re.match(r"^\s*(\d+)", version or "")
    if not match:
        return False
    return int(match.group(1)) < 8


def build_run_command(cfg: AgentConfig, server: ServerConfig, test_mode: bool = False) -> List[str]:
    """Build the `docker run ...` argument list for `server`, following the
    same structure as the reviewed start.py script."""
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"
    defaults = cfg.defaults
    db_folder = defaults.get("db_folder", "/var/sbo")
    db_vol_suffix = defaults.get("db_vol_suffix", "-db")
    db_vol = f"{server.name}{db_vol_suffix}"
    network_name = cfg.network.get("name", "bridged-net")

    for value, field_name in (
        (server.name, "name"), (server.version, "version"), (server.ip, "ip"),
        (server.type, "type"), (server.accept_eula, "accept_eula"),
        (server.graphdb, "graphdb"), (server.dns, "dns"),
    ):
        dt.validate_token(value, field_name)

    cmd = [
        "docker", "run", "-d",
        f"--name={server.name}",
        "-h", server.name,
        "--ulimit", "core=-1",
        "--restart", "always",
    ]

    if not test_mode:
        cmd += ["--network", network_name]

    cmd += [
        "-e", f"NSP_ACCEPT_EULA={server.accept_eula}",
        "-e", f"Semantic_Db_URL={server.graphdb}",
    ]

    # Proxy: explicit config value wins, otherwise fall back to host env vars
    # (same precedence as start.py). NOTE: start.py itself never validates
    # these three values -- this project validates them too (see
    # docker_tools.py module docstring for the rationale).
    for cfg_value, lower_env, upper_env in (
        (server.http_proxy, "http_proxy", "HTTP_PROXY"),
        (server.https_proxy, "https_proxy", "HTTPS_PROXY"),
        (server.no_proxy, "no_proxy", "NO_PROXY"),
    ):
        if cfg_value:
            dt.validate_token(cfg_value, lower_env)
            cmd += ["-e", f"{lower_env}={cfg_value}"]
        else:
            if lower_env in os.environ:
                cmd += ["-e", f"{lower_env}={os.environ[lower_env]}"]
            if upper_env in os.environ:
                cmd += ["-e", f"{upper_env}={os.environ[upper_env]}"]

    if test_mode:
        for container_port, host_port in TEST_MODE_PORTS.items():
            cmd += ["-p", f"{host_port}:{container_port}"]
    else:
        cmd += ["--ip", server.ip]

    cmd += ["--mount", f"source={db_vol},target={db_folder}"]

    # CA bundle (version >= 8) vs. legacy CA folder (version < 8) -- ported
    # precisely from start.py's version-aware branch.
    use_legacy_ca_folder = _is_legacy_ca_folder_version(server.version)
    if use_legacy_ca_folder and server.ca_folder:
        dt.validate_token(server.ca_folder, "ca_folder")
        cmd += ["--mount", f"type=bind,source={server.ca_folder},target=/usr/local/share/ca-certificates"]
    if not use_legacy_ca_folder and server.ca_bundle:
        dt.validate_token(server.ca_bundle, "ca_bundle")
        cmd += ["--mount", f"type=bind,source={server.ca_bundle},target=/opt/sbo/etc/ca-bundle.crt,readonly"]

    crash_folder = defaults.get("crash_folder", "/var/crash")
    if os.path.exists(crash_folder):
        cmd += ["--mount", f"type=bind,source={crash_folder},target={crash_folder}"]

    if server.dns:
        cmd += ["--dns", server.dns]

    cmd.append(image)
    return cmd


def ensure_network(cfg: AgentConfig, dry_run: bool = False) -> None:
    net = cfg.network
    name = net.get("name", "bridged-net")
    if dt.network_exists(name, dry_run=dry_run):
        logger.info("Docker network '%s' already exists.", name)
        return
    logger.info("Creating ipvlan network '%s' ...", name)
    rc, out, err = dt.create_ipvlan_network(
        name=name,
        subnet=net.get("subnet", "192.168.10.0/24"),
        gateway=net.get("gateway", "192.168.10.254"),
        parent_interface=net.get("parent_interface", "eth0"),
        dry_run=dry_run,
    )
    if rc != 0:
        logger.error("Failed to create network '%s': %s", name, err)
    else:
        logger.info("Network '%s' created.", name)


def start(cfg: AgentConfig, name: str, dry_run: bool = False, test_mode: bool = False) -> bool:
    server = cfg.get_server(name)
    if dt.container_exists(name, dry_run=dry_run):
        if dt.is_running(name, dry_run=dry_run):
            logger.info("Container '%s' is already running.", name)
            return True
        logger.info("Container '%s' exists but is stopped; starting it.", name)
        rc, _out, err = dt.start_existing_container(name, dry_run=dry_run)
        if rc != 0:
            logger.error("Failed to start '%s': %s", name, err)
            return False
        logger.info("Container '%s' started.", name)
        return True

    if test_mode:
        logger.info(
            "TEST MODE: skipping ipvlan network creation; container will use "
            "port-forwarding (host ports %s) instead of a static IP.",
            ", ".join(f"{h}->{c}" for c, h in TEST_MODE_PORTS.items()),
        )
    else:
        ensure_network(cfg, dry_run=dry_run)

    cmd = build_run_command(cfg, server, test_mode=test_mode)
    logger.info("Creating and starting container '%s' (%s) ...", name, "test-mode ports" if test_mode else server.ip)
    rc, out, err = dt.run_container(cmd, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to start '%s': %s", name, err)
        return False
    logger.info("Container '%s' created and started (id=%s).", name, out[:12] if out else "dry-run")
    if test_mode:
        logger.info(
            "TEST MODE: once running, connect at https://localhost:%s",
            TEST_MODE_PORTS["443"],
        )
    return True


def stop(name: str, dry_run: bool = False) -> bool:
    rc, _out, err = dt.stop_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to stop '%s': %s", name, err)
        return False
    logger.info("Container '%s' stopped.", name)
    return True


def restart(name: str, dry_run: bool = False) -> bool:
    rc, _out, err = dt.restart_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to restart '%s': %s", name, err)
        return False
    logger.info("Container '%s' restarted.", name)
    return True


def remove(name: str, force: bool = False, dry_run: bool = False) -> bool:
    rc, _out, err = dt.remove_container(name, force=force, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to remove '%s': %s", name, err)
        return False
    logger.info("Container '%s' removed.", name)
    return True


def status(name: str, dry_run: bool = False) -> dict:
    if not dt.container_exists(name, dry_run=dry_run):
        return {"name": name, "exists": False}
    info = dt.inspect_container(name, dry_run=dry_run) or {}
    state = info.get("State", {})
    return {
        "name": name,
        "exists": True,
        "running": state.get("Running", False),
        "status": state.get("Status", "unknown"),
        "restart_count": info.get("RestartCount", 0),
        "started_at": state.get("StartedAt", ""),
        "image": info.get("Config", {}).get("Image", ""),
        "ip": info.get("NetworkSettings", {}).get("Networks", {}),
    }


def upgrade(cfg: AgentConfig, name: str, new_version: str, dry_run: bool = False) -> bool:
    """Re-implementation of upgrade.py's flow, driven by config/servers.json
    instead of re-invoking argparse via sys.argv.

    Note: the original upgrade.py actually calls start.py's exe() with
    STRING arguments (e.g. exe(f'docker stop {name}')), even though
    start.py's own exe() expects a LIST -- an inconsistency in the supplied
    reference code (see docs/SOURCE_FILES_REVIEW.md). This implementation
    uses list-based calls consistently throughout, matching the safer
    pattern used everywhere else in this project.
    """
    server = cfg.get_server(name)
    info = dt.inspect_container(name, dry_run=dry_run)
    if not info and not dry_run:
        logger.error("Cannot upgrade '%s': container does not exist. Use 'start' first.", name)
        return False

    old_image = info.get("Config", {}).get("Image", "") if info else "unknown:unknown"
    logger.info("Upgrading '%s' from image '%s' to version '%s' ...", name, old_image, new_version)

    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")

    dt.stop_container(name, dry_run=dry_run)
    dt.remove_container(name, dry_run=dry_run)

    if old_image and old_image != "unknown:unknown":
        dt.exe([
            "docker", "run", "--rm",
            "--mount", f"source={db_vol},target={db_folder}",
            old_image, "/opt/sbo/bin/prepare-upgrade",
        ], dry_run=dry_run)

    server.version = new_version
    cmd = build_run_command(cfg, server)
    rc, out, err = dt.run_container(cmd, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to start upgraded container '%s': %s", name, err)
        return False

    new_info = dt.inspect_container(name, dry_run=dry_run)
    new_image = new_info.get("Config", {}).get("Image", "") if new_info else (
        f"ghcr.io/schneiderelectricbuildings/{server.type}:{new_version}"
    )
    rc2, log_out, _err2 = dt.exe([
        "docker", "run", "--rm",
        "--mount", f"source={db_vol},target={db_folder}",
        new_image, "/opt/sbo/bin/get-upgrade-log",
    ], dry_run=dry_run)
    if log_out:
        logger.info("Upgrade log:\n%s", log_out)
    logger.info("Container '%s' upgraded to '%s'.", name, new_version)
    return True
