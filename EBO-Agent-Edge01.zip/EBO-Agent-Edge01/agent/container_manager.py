r"""
agent/container_manager.py
============================
Purpose
-------
High-level container LIFECYCLE operations (start / stop / restart / upgrade
/ status / remove) for the EBO servers described in config/servers.yml.
Ported from the reviewed start.py / upgrade.py scripts, now additionally
cross-platform: it automatically builds a DIFFERENT `docker run` command
depending on whether it's running on Linux/WSL or native Windows.

Why the network strategy differs by OS (the key cross-platform fix)
-------------------------------------------------------------------------
readme.md's own instructions, and Bash4Edge's setupDockerNetwork.sh, both
assume native Linux Docker Engine, where an IPVLAN network can bind
directly to a real host network adapter (`-o parent=eth0`), giving the
container its own address on the physical LAN. Docker Desktop for Windows
runs the Docker daemon inside a hidden, WSL2-based Linux VM -- there is
usually no real host NIC visible to the daemon for IPVLAN/MACVLAN to bind
to, so attempting the exact same command on Windows tends to fail with a
non-obvious error, or silently not behave as expected.

This module now calls platform_utils.network_strategy() and picks one of
two, clearly different, DOCUMENTED code paths:
  - "ipvlan" (default on Linux/WSL): exactly the previous behaviour --
    static IP on a host-NIC-bound IPVLAN network.
  - "bridge_ports" (default on native Windows): creates (or reuses) an
    ordinary Docker bridge network with NO static host-LAN IP, and instead
    PUBLISHES the three standard EBO ports to the host (matching readme.md's
    own documented port-forwarding example, i.e. what this project already
    called --test-mode) -- so the server is reachable at
    https://localhost:<port> instead of a LAN IP. This is not a
    workaround bolted on top of test-mode; it IS test-mode's mechanism,
    now used as the sensible, correct-by-default behaviour on Windows,
    while --test-mode remains available as an explicit override on any
    platform for ad-hoc testing.
A user who has specifically configured Docker Desktop's WSL2 integration in
a way that DOES expose a usable adapter can force the old behaviour with
`agentSettings.network.force_strategy: ipvlan` in servers.yml.

Functionality
-------------
- build_run_command(cfg, server, test_mode=False): builds the full `docker
  run` command, picking the ipvlan or bridge_ports shape automatically
  (or per test_mode/force_strategy overrides), including the CA-bundle /
  legacy-CA-folder version-aware branch ported from start.py, the proxy
  env-var fallback, and cross-platform path normalisation for every
  bind-mount source.
- ensure_network(cfg, dry_run): creates whichever network type the current
  strategy calls for, if it doesn't already exist.
- start(cfg, name_or_ip, ...): resolves `name_or_ip` to a configured server
  (by exact name, OR by matching a configured/runtime IP address -- see
  resolve_target()), then creates+starts it, or simply starts it if it
  already exists.
- stop/restart/remove/status: thin wrappers, now using discovery.py's
  cached existence/IP lookups instead of a fresh `docker` call every time.
- upgrade(): unchanged lineage from upgrade.py (stop -> prepare-upgrade ->
  start-new -> get-upgrade-log), via list-based subprocess calls throughout.
- resolve_target(cfg, name_or_ip): NEW -- given either a server's
  configured NAME or an IP ADDRESS, returns the matching ServerConfig,
  satisfying the "support both container names and container IP addresses"
  requirement. Raises a clear error if the identifier doesn't match any
  configured server.

How it interacts with other modules
------------------------------------
- Reads server/network/default settings from agent.config.AgentConfig.
- Uses agent.platform_utils for OS detection, path normalisation, and
  network-strategy selection.
- Uses agent.discovery for cached container-existence/IP lookups instead of
  calling agent.docker_tools directly for every check.
- Delegates every actual Docker CLI mutation to agent.docker_tools.

Configuration requirements
---------------------------
Needs a valid ServerConfig entry for the container name being operated on,
plus the shared "network" and "defaults" sections of config/servers.yml.
"""
from __future__ import annotations

import logging
import os
import re
from typing import List, Optional

from . import discovery
from . import docker_tools as dt
from . import platform_utils as pf
from .config import AgentConfig, ConfigError, ServerConfig

logger = logging.getLogger(__name__)

# Default host:container port map used by test_mode / the Windows
# bridge_ports strategy, taken verbatim from readme.md's own example
# (-p 1080:80 -p 1443:443 -p14444:4444).
TEST_MODE_PORTS = {"80": "1080", "443": "1443", "4444": "14444"}


def _is_legacy_ca_folder_version(version: str) -> bool:
    """Direct port of start.py's _is_legacy_ca_folder_version(): True for
    versions below 8.x, where --ca-folder is still required instead of
    --ca-bundle."""
    match = re.match(r"^\s*(\d+)", version or "")
    if not match:
        return False
    return int(match.group(1)) < 8


def resolve_target(cfg: AgentConfig, name_or_ip: str) -> ServerConfig:
    """Resolve `name_or_ip` to a configured server, by exact name match
    first, then by matching a configured OR currently-running IP address.
    This is what lets every CLI command accept either "Edge01" or
    "192.168.10.1" interchangeably."""
    if name_or_ip in cfg.list_server_names():
        return cfg.get_server(name_or_ip)

    # Not a known name -- try matching by IP (configured, then runtime).
    for name in cfg.list_server_names():
        server = cfg.get_server(name)
        if server.ip == name_or_ip:
            return server
        runtime_ip = discovery.get_runtime_ip(name)
        if runtime_ip == name_or_ip:
            return server

    raise ConfigError(
        f"'{name_or_ip}' does not match any configured server's name, configured "
        f"IP, or current runtime IP. Configured servers: {cfg.list_server_names()}"
    )


def build_run_command(cfg: AgentConfig, server: ServerConfig, test_mode: bool = False) -> List[str]:
    """Build the `docker run ...` argument list for `server`, automatically
    choosing the ipvlan or bridge_ports network shape (see module
    docstring), unless `test_mode` explicitly forces bridge_ports."""
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"
    defaults = cfg.defaults
    db_folder = defaults.get("db_folder", "/var/sbo")
    db_vol_suffix = defaults.get("db_vol_suffix", "-db")
    db_vol = f"{server.name}{db_vol_suffix}"

    forced = ((cfg.raw.get("agentSettings") or {}).get("network") or {}).get("force_strategy")
    strategy = "bridge_ports" if test_mode else pf.network_strategy(forced)

    for value, field_name in (
        (server.name, "name"), (server.version, "version"), (server.ip, "ip"),
        (server.type, "type"), (server.accept_eula, "accept_eula"),
        (server.graphdb, "graphdb"), (server.dns, "dns"),
    ):
        dt.validate_token(value, field_name)

    cmd = [
        "docker", "run", "-d",
        f"--name={server.name}",
        "-h", server.name,
        "--ulimit", "core=-1",
        "--restart", "always",
    ]

    # Both strategies attach to a named Docker network -- they differ only
    # in HOW that network was created (ipvlan bound to a host NIC, vs. an
    # ordinary bridge) and in whether a static --ip is used below.
    cmd += ["--network", server.network]

    cmd += [
        "-e", f"NSP_ACCEPT_EULA={server.accept_eula}",
        "-e", f"Semantic_Db_URL={server.graphdb}",
    ]

    for cfg_value, lower_env, upper_env in (
        (server.http_proxy, "http_proxy", "HTTP_PROXY"),
        (server.https_proxy, "https_proxy", "HTTPS_PROXY"),
        (server.no_proxy, "no_proxy", "NO_PROXY"),
    ):
        if cfg_value:
            dt.validate_token(cfg_value, lower_env)
            cmd += ["-e", f"{lower_env}={cfg_value}"]
        else:
            if lower_env in os.environ:
                cmd += ["-e", f"{lower_env}={os.environ[lower_env]}"]
            if upper_env in os.environ:
                cmd += ["-e", f"{upper_env}={os.environ[upper_env]}"]

    if strategy == "ipvlan":
        cmd += ["--ip", server.ip]
    else:
        for container_port, host_port in TEST_MODE_PORTS.items():
            cmd += ["-p", f"{host_port}:{container_port}"]

    cmd += ["--mount", f"source={db_vol},target={db_folder}"]

    use_legacy_ca_folder = _is_legacy_ca_folder_version(server.version)
    if use_legacy_ca_folder and server.ca_folder:
        ca_folder = pf.normalize_bind_source(server.ca_folder)
        dt.validate_token(ca_folder, "ca_folder")
        cmd += ["--mount", f"type=bind,source={ca_folder},target=/usr/local/share/ca-certificates"]
    if not use_legacy_ca_folder and server.ca_bundle:
        ca_bundle = pf.normalize_bind_source(server.ca_bundle)
        dt.validate_token(ca_bundle, "ca_bundle")
        cmd += ["--mount", f"type=bind,source={ca_bundle},target=/opt/sbo/etc/ca-bundle.crt,readonly"]

    # Matches start.py exactly: only mount /var/crash if that host path
    # actually exists. This is deliberately NOT overridden per-platform --
    # forcing the mount on Linux regardless of existence would reintroduce
    # precisely the "bind source path does not exist: /var/crash" error
    # documented in Bash4Edge's own Known Issues table. On native Windows
    # there usually is no equivalent path unless the user has configured
    # one explicitly via crash_folder in servers.yml.
    crash_folder = defaults.get("crash_folder", "/var/crash")
    crash_folder_host = pf.normalize_bind_source(crash_folder)
    if os.path.exists(crash_folder_host):
        cmd += ["--mount", f"type=bind,source={crash_folder_host},target=/var/crash"]

    if server.dns:
        cmd += ["--dns", server.dns]

    cmd.append(image)
    return cmd


def ensure_network(cfg: AgentConfig, test_mode: bool = False, dry_run: bool = False) -> None:
    net = cfg.network
    name = net.get("name", "bridged-net")
    forced = ((cfg.raw.get("agentSettings") or {}).get("network") or {}).get("force_strategy")
    strategy = "bridge_ports" if test_mode else pf.network_strategy(forced)

    if dt.network_exists(name, dry_run=dry_run):
        logger.info("Docker network '%s' already exists.", name)
        return

    if strategy == "ipvlan":
        logger.info("Creating ipvlan network '%s' (Linux/WSL strategy) ...", name)
        rc, out, err = dt.create_ipvlan_network(
            name=name,
            subnet=net.get("subnet", "192.168.10.0/24"),
            gateway=net.get("gateway", "192.168.10.254"),
            parent_interface=net.get("interface", net.get("parent_interface", "eth0")),
            dry_run=dry_run,
        )
    else:
        logger.info(
            "Creating ordinary bridge network '%s' (Windows/Docker Desktop strategy -- "
            "no static host-LAN IP; ports will be published instead, see docs/ASSUMPTIONS.md).",
            name,
        )
        rc, out, err = dt.create_bridge_network(name, dry_run=dry_run)

    if rc != 0:
        logger.error("Failed to create network '%s': %s", name, err)
    else:
        logger.info("Network '%s' created.", name)


def start(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False, test_mode: bool = False) -> bool:
    server = resolve_target(cfg, name_or_ip)
    name = server.name
    if discovery.container_exists_cached(name, dry_run=dry_run):
        if dt.is_running(name, dry_run=dry_run):
            logger.info("Container '%s' is already running.", name)
            return True
        logger.info("Container '%s' exists but is stopped; starting it.", name)
        rc, _out, err = dt.start_existing_container(name, dry_run=dry_run)
        if rc != 0:
            logger.error("Failed to start '%s': %s", name, err)
            return False
        logger.info("Container '%s' started.", name)
        discovery.clear_cache()
        return True

    ensure_network(cfg, test_mode=test_mode, dry_run=dry_run)
    cmd = build_run_command(cfg, server, test_mode=test_mode)
    logger.info("Creating and starting container '%s' ...", name)
    rc, out, err = dt.run_container(cmd, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to start '%s': %s", name, err)
        return False
    logger.info("Container '%s' created and started (id=%s).", name, out[:12] if out else "dry-run")
    discovery.clear_cache()

    strategy = "bridge_ports" if test_mode else pf.network_strategy(
        ((cfg.raw.get("agentSettings") or {}).get("network") or {}).get("force_strategy")
    )
    if strategy == "bridge_ports":
        logger.info("Once running, connect at https://localhost:%s", TEST_MODE_PORTS["443"])
    return True


def stop(name_or_ip: str, cfg: Optional[AgentConfig] = None, dry_run: bool = False) -> bool:
    name = resolve_target(cfg, name_or_ip).name if cfg else name_or_ip
    rc, _out, err = dt.stop_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to stop '%s': %s", name, err)
        return False
    logger.info("Container '%s' stopped.", name)
    discovery.clear_cache()
    return True


def restart(name_or_ip: str, cfg: Optional[AgentConfig] = None, dry_run: bool = False) -> bool:
    name = resolve_target(cfg, name_or_ip).name if cfg else name_or_ip
    rc, _out, err = dt.restart_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to restart '%s': %s", name, err)
        return False
    logger.info("Container '%s' restarted.", name)
    discovery.clear_cache()
    return True


def remove(name_or_ip: str, cfg: Optional[AgentConfig] = None, force: bool = False, dry_run: bool = False) -> bool:
    name = resolve_target(cfg, name_or_ip).name if cfg else name_or_ip
    rc, _out, err = dt.remove_container(name, force=force, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to remove '%s': %s", name, err)
        return False
    logger.info("Container '%s' removed.", name)
    discovery.clear_cache()
    return True


def status(name_or_ip: str, cfg: Optional[AgentConfig] = None, dry_run: bool = False) -> dict:
    name = resolve_target(cfg, name_or_ip).name if cfg else name_or_ip
    if not discovery.container_exists_cached(name, dry_run=dry_run):
        return {"name": name, "exists": False}
    info = dt.inspect_container(name, dry_run=dry_run) or {}
    state = info.get("State", {})
    return {
        "name": name,
        "exists": True,
        "running": state.get("Running", False),
        "status": state.get("Status", "unknown"),
        "restart_count": info.get("RestartCount", 0),
        "started_at": state.get("StartedAt", ""),
        "image": info.get("Config", {}).get("Image", ""),
        "ip": info.get("NetworkSettings", {}).get("Networks", {}),
    }


def upgrade(cfg: AgentConfig, name_or_ip: str, new_version: str, dry_run: bool = False) -> bool:
    """Ported from upgrade.py's flow, driven by config/servers.yml."""
    server = resolve_target(cfg, name_or_ip)
    name = server.name
    info = dt.inspect_container(name, dry_run=dry_run)
    if not info and not dry_run:
        logger.error("Cannot upgrade '%s': container does not exist. Use 'start' first.", name)
        return False

    old_image = info.get("Config", {}).get("Image", "") if info else "unknown:unknown"
    logger.info("Upgrading '%s' from image '%s' to version '%s' ...", name, old_image, new_version)

    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")

    dt.stop_container(name, dry_run=dry_run)
    dt.remove_container(name, dry_run=dry_run)

    if old_image and old_image != "unknown:unknown":
        dt.exe([
            "docker", "run", "--rm",
            "--mount", f"source={db_vol},target={db_folder}",
            old_image, "/opt/sbo/bin/prepare-upgrade",
        ], dry_run=dry_run)

    server.version = new_version
    cmd = build_run_command(cfg, server)
    rc, out, err = dt.run_container(cmd, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to start upgraded container '%s': %s", name, err)
        return False

    new_info = dt.inspect_container(name, dry_run=dry_run)
    new_image = new_info.get("Config", {}).get("Image", "") if new_info else (
        f"ghcr.io/schneiderelectricbuildings/{server.type}:{new_version}"
    )
    rc2, log_out, _err2 = dt.exe([
        "docker", "run", "--rm",
        "--mount", f"source={db_vol},target={db_folder}",
        new_image, "/opt/sbo/bin/get-upgrade-log",
    ], dry_run=dry_run)
    if log_out:
        logger.info("Upgrade log:\n%s", log_out)
    logger.info("Container '%s' upgraded to '%s'.", name, new_version)
    discovery.clear_cache()
    return True
