"""
agent/backup_tools.py
=======================
Purpose
-------
Python equivalents of the three backup-management scripts referenced (but
not included as reviewable source) in the official image readme.md's
"Backup management" section:

    list-backups cs3
    copy-backups cs3 /tmp
    restore-backup cs3 5.0.0.82 "Server 1 2022-09-09 14_12_36_5.0.0.1082.xbk" ConfigurationOnly
    restore-backup cs3 5.0.0.82 /home/user/"Server 1 ....xbk" ConfigurationOnly

readme.md documents their USAGE and sample OUTPUT precisely (e.g.
"Server 1 2022-09-09 14_12_36_5.0.0.1082.xbk" as a sample listed backup,
and the choice between the "ConfigurationOnly" and "AllData" restore
modes), but says explicitly "for more details look in the scripts" --
i.e. it points at script files that were not supplied for review. This
module is therefore a clearly-labelled RECONSTRUCTION of that documented
contract -- see docs/SOURCE_FILES_REVIEW.md ("Reconstructed vs. ported")
for full disclosure. It is built on the one concrete pattern this project
DOES have fully verified source for: upgrade.py's use of an ephemeral
`docker run --rm --mount ...` container to invoke binaries under
/opt/sbo/bin against the container's database volume (prepare-upgrade,
get-upgrade-log). Backup listing/copying is implemented instead via
`docker exec`/`docker cp` against the LIVE container, since backups are
normal runtime artifacts of a running EBO server (unlike upgrade, which
requires the container to be stopped).

The Bash4Edge toolkit's manageBackups.sh (full, verified source -- see
reference/original-uploaded-files/bash4edge/manageBackups.sh) independently
confirms the same overall shape for Linux: it lists a $server_backups path
(/var/sbo/db_backup/LocalBackup) via `docker exec`, copies it out via
`docker cp`, and restores via an ephemeral container running
/opt/sbo/bin/prepare-restore. This module mirrors that confirmed shape.

Functionality
-------------
- list_backups(cfg, name): runs `docker exec <name> ls -1 <path>` against
  the backup folder (matching manageBackups.sh's $server_backups path:
  /var/sbo/db_backup/LocalBackup) and returns the listing as a list of
  filenames.
- copy_backups(cfg, name, destination): `docker cp`s the backup folder from
  the container to a host destination directory.
- restore_backup(cfg, name, version, backup, mode): stops the container,
  runs an ephemeral container (same --mount pattern as upgrade.py)
  invoking /opt/sbo/bin/prepare-restore (matching the binary name actually
  used by Bash4Edge's manageBackups.sh), then restarts the container --
  mirroring upgrade.py's stop/ephemeral-run/restart sequence.

How it interacts with other modules
------------------------------------
- Uses agent.docker_tools for all Docker CLI calls (docker_exec,
  copy_from_container, copy_to_container, stop_container,
  start_existing_container, exe).
- Reads server config (name, version, db_folder) from agent.config.
- Is exposed via agent.agent's `list-backups` / `copy-backups` /
  `restore-backup` CLI subcommands.

Configuration requirements
---------------------------
Uses the same defaults.db_folder setting as container_manager.py
(default: /var/sbo). No additional configuration is required.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)

# Matches the $server_backups path hard-coded in Bash4Edge's manageBackups.sh
# (createServerVars() in functions.sh): /var/sbo/db_backup/LocalBackup
BACKUP_SUBPATH = "db_backup/LocalBackup"


def list_backups(cfg: AgentConfig, name: str, dry_run: bool = False) -> List[str]:
    db_folder = cfg.defaults.get("db_folder", "/var/sbo")
    backup_dir = f"{db_folder}/{BACKUP_SUBPATH}"
    # Each argv token is validated individually by docker_exec(), so pass
    # "ls" and the path as separate tokens rather than a shell command
    # string (no shell layer is needed for a plain directory listing).
    rc, out, err = dt.docker_exec(name, ["ls", backup_dir], dry_run=dry_run)
    if dry_run:
        logger.info("[DRY-RUN] Would list backups in %s on '%s'.", backup_dir, name)
        return []
    if rc != 0:
        logger.error("Failed to list backups for '%s': %s", name, err)
        return []
    files = [line.strip().strip('"') for line in out.splitlines() if line.strip()]
    for f in files:
        logger.info("  %s", f)
    return files


def copy_backups(cfg: AgentConfig, name: str, destination: str, dry_run: bool = False) -> bool:
    db_folder = cfg.defaults.get("db_folder", "/var/sbo")
    backup_dir = f"{db_folder}/{BACKUP_SUBPATH}/."  # trailing /. copies contents, not the folder itself
    rc, _out, err = dt.copy_from_container(name, backup_dir, destination, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to copy backups from '%s' to '%s': %s", name, destination, err)
        return False
    logger.info("Copied backups from '%s:%s' to '%s'.", name, backup_dir, destination)
    return True


def restore_backup(
    cfg: AgentConfig,
    name: str,
    version: str,
    backup: str,
    mode: str = "ConfigurationOnly",
    from_host_path: Optional[str] = None,
    dry_run: bool = False,
) -> bool:
    """Restore `backup` using `mode` (ConfigurationOnly | AllData).

    Two usage patterns, both documented in readme.md:
      1. backup is "already available in the container" (readme.md's own
         phrase) -- i.e. already sitting in db_backup/LocalBackup, perhaps
         from a previous copy-backups/restore-backup cycle. No copy-in step
         needed; proceed straight to prepare-restore.
      2. from_host_path is given -- a backup file living on the HOST that
         needs to be copied into the container's backup folder first.

    For (2), the copy-in step mirrors Bash4Edge's manageBackups.sh exactly:
    an ephemeral container bind-mounts the HOST FOLDER containing the file
    (not just the single file) to /mnt and the server's database VOLUME to
    db_folder, then runs `cp '/mnt/<filename>' <db_folder>/db_backup/LocalBackup/`
    inside it. This deliberately does NOT require the live EBO container to
    be running (consistent with get-trace.log's volume-based approach),
    which is both safer and more flexible than copying into a live
    container with `docker cp`.

    Note: matching Bash4Edge's manageBackups.sh precisely, this does NOT
    stop the server container before running prepare-restore -- the
    original script only issues `docker restart $server` at the very end.
    This implementation mirrors that faithfully rather than silently adding
    an un-sourced safety step.
    """
    if mode not in ("ConfigurationOnly", "AllData"):
        logger.error("Invalid restore mode '%s'. Must be 'ConfigurationOnly' or 'AllData'.", mode)
        return False

    server = cfg.get_server(name)
    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"

    if from_host_path:
        host_folder = str(Path(from_host_path).parent)
        filename = Path(from_host_path).name
        rc, _out, err = dt.run_ephemeral_against_volume(
            image=image,
            volume=db_vol,
            volume_target=db_folder,
            bind_source=host_folder,
            bind_target="/mnt",
            shell_command=f"cp '/mnt/{filename}' {db_folder}/{BACKUP_SUBPATH}/",
            dry_run=dry_run,
        )
        if rc != 0:
            logger.error("Failed to copy host backup '%s' into container volume: %s", from_host_path, err)
            return False
        backup = filename

    rc, out, err = dt.exe([
        "docker", "run", "--rm",
        "--mount", f"source={db_vol},target={db_folder}",
        image, "/opt/sbo/bin/prepare-restore", backup, mode,
    ], dry_run=dry_run)
    if rc != 0:
        logger.error("Restore (prepare-restore) failed for '%s': %s", name, err)
        return False
    if out:
        logger.info("Restore output:\n%s", out)

    logger.info("Restarting '%s' after restore ...", name)
    dt.restart_container(name, dry_run=dry_run)
    logger.info("Restore of '%s' (%s, mode=%s) complete.", name, backup, mode)
    return True
