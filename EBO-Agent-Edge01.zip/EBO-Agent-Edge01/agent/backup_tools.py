"""
agent/backup_tools.py
=======================
Purpose
-------
Python equivalents of the backup-management functionality documented in
readme.md's "Backup management" section, CORRECTED to match Bash4Edge's
verified manageBackups.sh exactly (see docs/SOURCE_FILES_REVIEW.md for the
full history: an earlier version of this module, based only on readme.md's
usage examples, assumed a simpler `docker cp` against a live container;
reading Bash4Edge's actual, working source showed the real mechanism uses
an ephemeral container with a combined bind+volume mount instead, which
also works when the server container isn't currently running).

Functionality
-------------
- list_backups(cfg, name_or_ip): lists the backup files inside the
  container's backup folder.
- copy_backups(cfg, name_or_ip, destination): copies them out to a host
  folder (path auto-normalised for the current OS).
- restore_backup(cfg, name_or_ip, version, backup, mode, from_host_path):
  restores a backup, optionally copying it in from a host-side file first
  via the same ephemeral bind+volume-mount pattern Bash4Edge uses, then
  running /opt/sbo/bin/prepare-restore, then restarting the server (NOT
  stopping it first -- matching the verified script exactly).

How it interacts with other modules
------------------------------------
- Uses agent.container_manager.resolve_target() so every function accepts
  either a server's configured NAME or its IP ADDRESS.
- Uses agent.docker_tools for all Docker CLI calls.

Configuration requirements
---------------------------
Uses the same defaults.db_folder setting as container_manager.py.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from . import container_manager as cm
from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)

# Matches the $server_backups path hard-coded in Bash4Edge's manageBackups.sh
# (createServerVars() in functions.sh): /var/sbo/db_backup/LocalBackup
BACKUP_SUBPATH = "db_backup/LocalBackup"


def list_backups(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False) -> List[str]:
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    db_folder = cfg.defaults.get("db_folder", "/var/sbo")
    backup_dir = f"{db_folder}/{BACKUP_SUBPATH}"
    rc, out, err = dt.docker_exec(name, ["ls", backup_dir], dry_run=dry_run)
    if dry_run:
        logger.info("[DRY-RUN] Would list backups in %s on '%s'.", backup_dir, name)
        return []
    if rc != 0:
        logger.error("Failed to list backups for '%s': %s", name, err)
        return []
    files = [line.strip().strip('"') for line in out.splitlines() if line.strip()]
    for f in files:
        logger.info("  %s", f)
    return files


def copy_backups(cfg: AgentConfig, name_or_ip: str, destination: str, dry_run: bool = False) -> bool:
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    db_folder = cfg.defaults.get("db_folder", "/var/sbo")
    backup_dir = f"{db_folder}/{BACKUP_SUBPATH}/."
    rc, _out, err = dt.copy_from_container(name, backup_dir, destination, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to copy backups from '%s' to '%s': %s", name, destination, err)
        return False
    logger.info("Copied backups from '%s:%s' to '%s'.", name, backup_dir, destination)
    return True


def restore_backup(
    cfg: AgentConfig,
    name_or_ip: str,
    version: str,
    backup: str,
    mode: str = "ConfigurationOnly",
    from_host_path: Optional[str] = None,
    dry_run: bool = False,
) -> bool:
    """Restore `backup` using `mode` (ConfigurationOnly | AllData).
    See module docstring for the two usage patterns and why no stop/restart
    occurs before prepare-restore (matches verified Bash4Edge source)."""
    if mode not in ("ConfigurationOnly", "AllData"):
        logger.error("Invalid restore mode '%s'. Must be 'ConfigurationOnly' or 'AllData'.", mode)
        return False

    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"

    if from_host_path:
        host_folder = str(Path(from_host_path).parent)
        filename = Path(from_host_path).name
        rc, _out, err = dt.run_ephemeral_against_volume(
            image=image,
            volume=db_vol,
            volume_target=db_folder,
            bind_source=host_folder,
            bind_target="/mnt",
            shell_command=f"cp '/mnt/{filename}' {db_folder}/{BACKUP_SUBPATH}/",
            dry_run=dry_run,
        )
        if rc != 0:
            logger.error("Failed to copy host backup '%s' into container volume: %s", from_host_path, err)
            return False
        backup = filename

    rc, out, err = dt.exe([
        "docker", "run", "--rm",
        "--mount", f"source={db_vol},target={db_folder}",
        image, "/opt/sbo/bin/prepare-restore", backup, mode,
    ], dry_run=dry_run)
    if rc != 0:
        logger.error("Restore (prepare-restore) failed for '%s': %s", name, err)
        return False
    if out:
        logger.info("Restore output:\n%s", out)

    logger.info("Restarting '%s' after restore ...", name)
    dt.restart_container(name, dry_run=dry_run)
    logger.info("Restore of '%s' (%s, mode=%s) complete.", name, backup, mode)
    return True
