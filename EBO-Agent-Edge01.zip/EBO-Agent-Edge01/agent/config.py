"""
agent/config.py
================
Purpose
-------
Loads and validates the agent's JSON configuration file
(config/servers.json). This module exists so that every other module in the
package has a single, trusted source of configuration data and never has to
parse JSON (or, deliberately, YAML) itself.

This module is the direct JSON replacement for the Bash4Edge toolkit's
servers.yml (see reference/original-uploaded-files/bash4edge/servers.yml):
every section (repos, networks, serverSettings, servers, semanticsDbs) was
preserved, just re-expressed without a YAML parser.

Functionality
-------------
- Locates config/servers.json relative to the project root (works no matter
  which directory the agent is launched from in VS Code).
- Parses the file with the Python standard library's json module only.
  PyYAML and any other YAML library are intentionally NOT used anywhere in
  this project, per your explicit requirement.
- Performs light-weight schema validation (required keys, types) and raises
  a clear ConfigError with an actionable message if something is missing or
  malformed, instead of failing with a raw KeyError/TypeError deep inside
  the call stack.
- Exposes convenience accessors (get_server(), get_log_settings(),
  get_graphdb_server(), etc.) used by the other modules.

How it interacts with other modules
------------------------------------
- container_manager.py calls get_server() to build the `docker run` command
  for a given container name.
- backup_tools.py / password_reset.py / trace_tools.py call get_server()
  for name/ip/version needed to target the right container.
- graphdb_tools.py calls get_graphdb_server() for the semantics database
  entry matching Bash4Edge's semanticsDbs section.
- log_collector.py calls get_log_settings() to know where to write
  collected logs and how many lines to tail.
- agent.py calls load_config() once at start-up and passes the resulting
  AgentConfig object to every other component (dependency injection, no
  module re-reads the file independently).

Configuration requirements
---------------------------
config/servers.json must exist and contain, at minimum, a "servers" object
with one entry (see config/servers.json for the shipped example configured
for container "Edge01" / 192.168.10.1). All other sections
(network, defaults, log_collection, monitor, graphdb_servers) have sensible
fallbacks if omitted, documented inline below.
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional


class ConfigError(Exception):
    """Raised when config/servers.json is missing, malformed, or incomplete."""


# Default project root = two levels up from this file (agent/config.py -> project root)
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config" / "servers.json"


@dataclass
class ServerConfig:
    name: str
    repo: str
    type: str
    version: str
    ip: str
    accept_eula: str = "Yes"
    dns: Optional[str] = None
    http_proxy: Optional[str] = None
    https_proxy: Optional[str] = None
    no_proxy: Optional[str] = None
    ca_bundle: Optional[str] = None
    ca_folder: Optional[str] = None
    graphdb: str = ""


@dataclass
class GraphDbServerConfig:
    name: str
    repository: str
    version: str
    port: int
    network: str
    ip: str


@dataclass
class AgentConfig:
    raw: Dict[str, Any] = field(repr=False)
    path: Path

    # ---- convenience accessors -------------------------------------------------
    @property
    def network(self) -> Dict[str, Any]:
        return self.raw.get("network", {})

    @property
    def defaults(self) -> Dict[str, Any]:
        return self.raw.get("defaults", {})

    @property
    def log_collection(self) -> Dict[str, Any]:
        lc = self.raw.get("log_collection", {})
        lc.setdefault("enabled", True)
        lc.setdefault("output_dir", str(Path.home() / "Downloads" / "DOCKER" / "CONTAINER1"))
        lc.setdefault("tail_lines", 500)
        lc.setdefault("interval_seconds", 300)
        lc.setdefault("keep_last_n_collections", 20)
        return lc

    @property
    def monitor(self) -> Dict[str, Any]:
        mon = self.raw.get("monitor", {})
        mon.setdefault("poll_interval_seconds", 60)
        mon.setdefault("auto_restart", False)
        mon.setdefault("max_auto_restart_attempts", 3)
        return mon

    def repo_image(self, repo_name: str) -> str:
        repos = self.raw.get("repos", {})
        if repo_name not in repos:
            raise ConfigError(
                f"repos.{repo_name} not found in {self.path}. "
                f"Known repos: {list(repos.keys())}"
            )
        return repos[repo_name]["repository"]

    def list_server_names(self):
        return list(self.raw.get("servers", {}).keys())

    def get_server(self, name: str) -> ServerConfig:
        servers = self.raw.get("servers", {})
        if name not in servers:
            raise ConfigError(
                f"Server '{name}' not found in {self.path}. "
                f"Configured servers: {list(servers.keys())}"
            )
        s = servers[name]
        d = self.defaults
        try:
            return ServerConfig(
                name=name,
                repo=s["repo"],
                type=s.get("type", "ebo-edge-server"),
                version=s["version"],
                ip=s["ip"],
                accept_eula=s.get("accept_eula", d.get("accept_eula", "Yes")),
                dns=s.get("dns", d.get("dns")),
                http_proxy=s.get("http_proxy", d.get("http_proxy")),
                https_proxy=s.get("https_proxy", d.get("https_proxy")),
                no_proxy=s.get("no_proxy", d.get("no_proxy")),
                ca_bundle=s.get("ca_bundle", d.get("ca_bundle")),
                ca_folder=s.get("ca_folder", d.get("ca_folder")),
                graphdb=s.get("graphdb", d.get("graphdb", "")),
            )
        except KeyError as exc:
            raise ConfigError(
                f"Server '{name}' in {self.path} is missing required field {exc}. "
                "Required fields: repo, version, ip"
            ) from exc

    def list_graphdb_server_names(self):
        gds = self.raw.get("graphdb_servers", {})
        return [k for k in gds.keys() if not k.startswith("_")]

    def get_graphdb_server(self, name: str) -> GraphDbServerConfig:
        gds = self.raw.get("graphdb_servers", {})
        if name not in gds:
            raise ConfigError(
                f"GraphDB server '{name}' not found in {self.path}. "
                f"Configured graphdb_servers: {self.list_graphdb_server_names()}"
            )
        g = gds[name]
        try:
            return GraphDbServerConfig(
                name=name,
                repository=g["repository"],
                version=g["version"],
                port=int(g["port"]),
                network=g.get("network", self.network.get("name", "bridged-net")),
                ip=g["ip"],
            )
        except KeyError as exc:
            raise ConfigError(
                f"GraphDB server '{name}' in {self.path} is missing required field {exc}. "
                "Required fields: repository, version, port, ip"
            ) from exc


def load_config(path: Optional[os.PathLike] = None) -> AgentConfig:
    """Load and lightly validate config/servers.json.

    Raises ConfigError with a human-readable message on any problem so the
    CLI can print something actionable instead of a stack trace.
    """
    cfg_path = Path(path) if path else DEFAULT_CONFIG_PATH
    if not cfg_path.exists():
        raise ConfigError(
            f"Configuration file not found: {cfg_path}\n"
            "Expected it at <project_root>/config/servers.json. "
            "Copy/rename the sample file if you deleted it by mistake."
        )
    try:
        with open(cfg_path, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"Invalid JSON in {cfg_path}: {exc}") from exc

    if "servers" not in raw or not raw["servers"]:
        raise ConfigError(
            f"No 'servers' defined in {cfg_path}. Add at least one entry, "
            "e.g. the shipped 'Edge01' example."
        )

    return AgentConfig(raw=raw, path=cfg_path)
