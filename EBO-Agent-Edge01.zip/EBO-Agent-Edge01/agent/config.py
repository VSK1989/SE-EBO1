"""
agent/config.py
================
Purpose
-------
Loads and validates the agent's configuration from config/servers.yml --
the SAME file format, and now literally the SAME schema, as Bash4Edge's own
servers.yml. This is the central change in this enhancement pass: previously
the Python agent (Path A) read a JSON re-expression of Bash4Edge's schema;
now it reads servers.yml directly, via the dependency-free parser in
yaml_mini.py, so there is exactly ONE configuration file format across both
platforms (the user can literally copy the same config/servers.yml into
bash4edge/ and both sides will understand it).

Schema (matches Bash4Edge's real servers.yml, confirmed field-for-field)
----------------------------------------------------------------------------
    repos:              <RepoName>: {repository: <image path>}
    networks:           <NetworkName>: {type, subnet, gateway, interface}
    semanticsDbs:       <DbName>: {repository, version, port, network, ip}
    serverSettings:     shared defaults for every server (accept_eula,
                        network, db_vol_suffix, db_folder, crash_folder,
                        working_dir, ca_folder, dns_ip, graphdb_URL)
    servers:            <ServerName>: {version, ip, repo, [any
                        serverSettings field as a per-server override]}
    agentSettings:      NEW, Python-agent-only section (log_collection,
                        monitor, network.force_strategy) -- see below.

The `agentSettings` section is the one addition not present in Bash4Edge's
own servers.yml; it is deliberately kept separate and optional so that the
exact same file remains 100% valid, unmodified input to the Bash4Edge shell
scripts (which simply ignore keys they don't look up via `yq`).

Functionality
-------------
- load_config(path): reads and parses config/servers.yml via yaml_mini.py,
  validates the minimum required structure, and returns an AgentConfig.
- AgentConfig.get_server(name) / get_graphdb_server(name): resolve a named
  entry, applying serverSettings defaults for any field the entry itself
  doesn't override -- the same "per-server override, else shared default"
  behaviour as Bash4Edge's functions.sh checkDefaultSettings().
- A compatibility shim converts accept_eula's parsed boolean (yaml_mini
  parses YAML 1.1 Yes/No as Python bool, same as real `yq` would) back to
  the literal string "Yes"/"No" that NSP_ACCEPT_EULA actually needs on the
  Docker command line -- documented in-line below, since this is a subtle
  but important detail: passing Python's str(True) ("True") or a
  lower-cased "true" would NOT match what start.py's readme.md documents
  (`--accept-eula=Yes`).

How it interacts with other modules
------------------------------------
- Every other module that previously called `cfg.get_server()` /
  `cfg.list_server_names()` / `cfg.defaults` / `cfg.network` /
  `cfg.log_collection` / `cfg.monitor` continues to work unchanged -- this
  file keeps the exact same public AgentConfig API as before, only the
  underlying file format changed.
- agent/discovery.py calls AgentConfig.path to know which file to
  surgically patch when auto-syncing a drifted IP address.

Configuration requirements
---------------------------
config/servers.yml must exist and contain a non-empty `servers:` section.
Everything else has sensible fallbacks, documented per-field below.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

from . import platform_utils as pf
from .yaml_mini import YamlMiniError, load_yaml_file


class ConfigError(Exception):
    """Raised when config/servers.yml is missing, malformed, or incomplete."""


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config" / "servers.yml"


def _eula_str(value) -> str:
    """Convert a parsed accept_eula value back to the literal 'Yes'/'No'
    string the NSP_ACCEPT_EULA Docker env var requires (see module
    docstring for why this conversion is necessary)."""
    if isinstance(value, bool):
        return "Yes" if value else "No"
    if value is None:
        return "Yes"
    return str(value)


@dataclass
class ServerConfig:
    name: str
    repo: str
    type: str
    version: str
    ip: str
    accept_eula: str = "Yes"
    network: str = "bridged-net"
    dns: Optional[str] = None
    http_proxy: Optional[str] = None
    https_proxy: Optional[str] = None
    no_proxy: Optional[str] = None
    ca_bundle: Optional[str] = None
    ca_folder: Optional[str] = None
    graphdb: str = ""


@dataclass
class GraphDbServerConfig:
    name: str
    repository: str
    version: str
    port: int
    network: str
    ip: str


@dataclass
class AgentConfig:
    raw: Dict[str, Any] = field(repr=False)
    path: Path

    # ---- shared-default resolution (mirrors Bash4Edge's checkDefaultSettings) ---
    def _server_raw(self, name: str) -> Dict[str, Any]:
        servers = self.raw.get("servers", {})
        if name not in servers:
            raise ConfigError(
                f"Server '{name}' not found in {self.path}. "
                f"Configured servers: {list(servers.keys())}"
            )
        return servers[name] or {}

    def _resolve(self, server_raw: Dict[str, Any], field_name: str, fallback=None):
        """Per-server value if present, else serverSettings' shared default,
        else `fallback`. Mirrors functions.sh's checkDefaultSettings()."""
        if field_name in server_raw and server_raw[field_name] is not None:
            return server_raw[field_name]
        settings = self.raw.get("serverSettings", {}) or {}
        if field_name in settings and settings[field_name] is not None:
            return settings[field_name]
        return fallback

    # ---- convenience accessors (kept for backward API compatibility) -----------
    @property
    def network(self) -> Dict[str, Any]:
        """Returns the FIRST network entry under `networks:` (matching this
        project's single-network default usage), merged with a few
        Python-agent-only extras from agentSettings.network if present."""
        networks = self.raw.get("networks", {}) or {}
        if not networks:
            return {}
        name, body = next(iter(networks.items()))
        out = {"name": name, **(body or {})}
        extra = ((self.raw.get("agentSettings") or {}).get("network") or {})
        out.update({k: v for k, v in extra.items() if k not in out or k == "force_strategy"})
        return out

    @property
    def defaults(self) -> Dict[str, Any]:
        """Backward-compatible alias for the real `serverSettings` section,
        with field names normalised to what container_manager.py expects
        (db_folder, db_vol_suffix, crash_folder, ca_bundle, ca_folder, dns,
        graphdb, accept_eula) instead of Bash4Edge's own naming
        (dns_ip, graphdb_URL)."""
        s = self.raw.get("serverSettings", {}) or {}
        return {
            "accept_eula": _eula_str(s.get("accept_eula", "Yes")),
            "db_folder": s.get("db_folder", "/var/sbo"),
            "db_vol_suffix": s.get("db_vol_suffix", "-db"),
            "crash_folder": s.get("crash_folder", "/var/crash"),
            "dns": s.get("dns_ip"),
            "http_proxy": s.get("http_proxy"),
            "https_proxy": s.get("https_proxy"),
            "no_proxy": s.get("no_proxy"),
            "ca_bundle": s.get("ca_bundle"),
            "ca_folder": s.get("ca_folder"),
            "graphdb": s.get("graphdb_URL", "") or "",
            "working_dir": s.get("working_dir", "~/Edge"),
        }

    @property
    def log_collection(self) -> Dict[str, Any]:
        lc = dict(((self.raw.get("agentSettings") or {}).get("log_collection")) or {})
        lc.setdefault("enabled", True)
        lc.setdefault("output_dir", pf.default_downloads_dir() + os.sep + "DOCKER" + os.sep + "CONTAINER1")
        lc.setdefault("tail_lines", 500)
        lc.setdefault("interval_seconds", 300)
        lc.setdefault("keep_last_n_collections", 20)
        return lc

    @property
    def monitor(self) -> Dict[str, Any]:
        mon = dict(((self.raw.get("agentSettings") or {}).get("monitor")) or {})
        mon.setdefault("poll_interval_seconds", 60)
        mon.setdefault("auto_restart", False)
        mon.setdefault("max_auto_restart_attempts", 3)
        mon.setdefault("connectivity_check_enabled", True)
        mon.setdefault("connectivity_check_port", 443)
        mon.setdefault("connectivity_timeout_seconds", 3)
        return mon

    def repo_image(self, repo_name: str) -> str:
        repos = self.raw.get("repos", {}) or {}
        if repo_name not in repos:
            raise ConfigError(
                f"repos.{repo_name} not found in {self.path}. Known repos: {list(repos.keys())}"
            )
        return repos[repo_name]["repository"]

    def list_server_names(self):
        return list((self.raw.get("servers") or {}).keys())

    def get_server(self, name: str) -> ServerConfig:
        s = self._server_raw(name)
        try:
            repo_ref = s["repo"]
        except KeyError as exc:
            raise ConfigError(f"Server '{name}' in {self.path} is missing required field 'repo'.") from exc
        repos = self.raw.get("repos", {}) or {}
        if repo_ref not in repos:
            raise ConfigError(f"Server '{name}' references unknown repo '{repo_ref}'.")
        image_type = repo_ref[0].lower() + repo_ref[1:]  # EdgeServer -> edgeServer (unused directly)
        # Map the repo reference to the actual image "type" suffix used in
        # the ghcr.io path (ebo-edge-server / ebo-enterprise-server /
        # ebo-enterprise-central), by inspecting the repository URL itself
        # rather than hard-coding a name->type table, so a user-renamed repo
        # key (e.g. "MyEdge") still resolves correctly.
        repo_url = repos[repo_ref]["repository"]
        type_suffix = repo_url.rsplit("/", 1)[-1]

        try:
            version = s["version"]
            ip = s["ip"]
        except KeyError as exc:
            raise ConfigError(f"Server '{name}' in {self.path} is missing required field {exc}.") from exc

        return ServerConfig(
            name=name,
            repo=repo_ref,
            type=type_suffix,
            version=version,
            ip=ip,
            accept_eula=_eula_str(self._resolve(s, "accept_eula", "Yes")),
            network=self._resolve(s, "network", self.network.get("name", "bridged-net")),
            dns=self._resolve(s, "dns_ip"),
            http_proxy=self._resolve(s, "http_proxy"),
            https_proxy=self._resolve(s, "https_proxy"),
            no_proxy=self._resolve(s, "no_proxy"),
            ca_bundle=self._resolve(s, "ca_bundle"),
            ca_folder=self._resolve(s, "ca_folder"),
            graphdb=self._resolve(s, "graphdb_URL", "") or "",
        )

    def list_graphdb_server_names(self):
        return list((self.raw.get("semanticsDbs") or {}).keys())

    def get_graphdb_server(self, name: str) -> GraphDbServerConfig:
        gds = self.raw.get("semanticsDbs", {}) or {}
        if name not in gds:
            raise ConfigError(
                f"GraphDB server '{name}' not found in {self.path}. "
                f"Configured semanticsDbs: {self.list_graphdb_server_names()}"
            )
        g = gds[name]
        try:
            return GraphDbServerConfig(
                name=name,
                repository=g["repository"],
                version=str(g["version"]),
                port=int(g["port"]),
                network=g.get("network", self.network.get("name", "bridged-net")),
                ip=g["ip"],
            )
        except KeyError as exc:
            raise ConfigError(
                f"GraphDB server '{name}' in {self.path} is missing required field {exc}."
            ) from exc


def load_config(path: Optional[os.PathLike] = None) -> AgentConfig:
    """Load and lightly validate config/servers.yml.

    Raises ConfigError with a human-readable message on any problem so the
    CLI can print something actionable instead of a stack trace.
    """
    cfg_path = Path(path) if path else DEFAULT_CONFIG_PATH
    if not cfg_path.exists():
        raise ConfigError(
            f"Configuration file not found: {cfg_path}\n"
            "Expected it at <project_root>/config/servers.yml. "
            "Copy/rename the sample file if you deleted it by mistake."
        )
    try:
        raw = load_yaml_file(cfg_path)
    except YamlMiniError as exc:
        raise ConfigError(
            f"Could not parse {cfg_path} with this project's dependency-free YAML "
            f"reader: {exc}\nIf you added an advanced YAML feature (anchors, flow "
            f"collections, multi-line scalars), simplify it to plain nested "
            f"'key: value' mappings -- see agent/yaml_mini.py's docstring for the "
            f"exact supported subset."
        ) from exc

    if not raw.get("servers"):
        raise ConfigError(
            f"No 'servers' defined in {cfg_path}. Add at least one entry, "
            "e.g. the shipped 'Edge01' example."
        )

    return AgentConfig(raw=raw, path=cfg_path)
