"""
agent/decision_engine.py
==========================
Purpose
-------
This is the "AI" part of the AI Agent: a lightweight, transparent,
RULE-BASED decision system (an expert system, not a machine-learning model)
that inspects a container's state and recent logs, then recommends -- and
optionally executes -- a corrective action. It was deliberately kept
rule-based rather than ML-based to satisfy the "simple, lightweight, and
easy to maintain" requirement: every decision can be read, understood, and
extended by adding one more `if` rule, with no model files, training data,
or extra dependencies. Neither the Windows/Python scripts nor the Bash4Edge
toolkit contained any automated health-check or monitoring logic -- this
module is new functionality added specifically to fulfil the "AI Agent"
(rather than plain automation script) part of the brief.

Functionality
-------------
- KNOWN_LOG_PATTERNS: a small table of (regex, severity, advice) tuples
  used to scan recent container logs for well-known conditions (EULA not
  accepted, license/activation problems, out-of-memory, database errors,
  network/DNS failures, crash/core dumps). The EULA and crash-dump patterns
  are directly informed by the corresponding sections of readme.md ("EULA
  must be accepted before the server can start", "In case of crash").
- evaluate(name): inspects the container (via docker_tools) and scans its
  logs, returning a Decision object with:
    - state: "missing" | "stopped" | "running" | "restart_loop"
    - action: "create" | "restart" | "none" | "alert"
    - reasons: list[str] human-readable explanations for the decision
    - findings: list[str] any matched log patterns with advice
- decide_and_act(name, auto_restart, max_attempts): applies evaluate() and,
  if auto_restart is enabled in config/servers.json (monitor.auto_restart)
  and the attempt budget is not exhausted, calls container_manager.restart()
  or .start(); otherwise it only logs/returns the recommendation so a human
  can decide (safe default: auto_restart is OFF unless explicitly enabled).

How it interacts with other modules
------------------------------------
- Uses agent.docker_tools for read-only state inspection (inspect_container,
  get_logs) -- it never mutates container state directly.
- Delegates any actual remediation (start/restart) to
  agent.container_manager, so all Docker mutation logic stays in one place.
- Is called by agent.py's `status` (report-only) and `monitor` (loop with
  optional auto-remediation) subcommands.
- Its findings are embedded by log_collector.py into each diagnostic
  snapshot written to the Downloads folder.

Configuration requirements
---------------------------
Reads monitor.auto_restart and monitor.max_auto_restart_attempts from
config/servers.json. No other configuration is required.
"""
from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import List

from . import container_manager as cm
from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)

# (regex, severity, advice) -- checked against the tail of `docker logs`.
KNOWN_LOG_PATTERNS = [
    (re.compile(r"accept.*eula|EULA", re.IGNORECASE),
     "warning", "Server is waiting for EULA acceptance. Confirm accept_eula='Yes' in config/servers.json."),
    (re.compile(r"license|activation", re.IGNORECASE),
     "warning", "Possible licensing/activation issue detected in logs. Review server licensing in WorkStation."),
    (re.compile(r"out of memory|oom", re.IGNORECASE),
     "critical", "Out-of-memory condition detected. Check Docker Desktop resource limits (Settings > Resources)."),
    (re.compile(r"connection refused|network is unreachable|dns", re.IGNORECASE),
     "warning", "Network/DNS connectivity issue detected. Verify --dns / ipvlan network configuration."),
    (re.compile(r"database.*(error|corrupt)|db.*(error|corrupt)", re.IGNORECASE),
     "critical", "Possible database error detected. Consider restoring from backup (see 'restore-backup')."),
    (re.compile(r"traceback|unhandled exception|fatal", re.IGNORECASE),
     "critical", "Unhandled exception/fatal error detected in container logs."),
]

RESTART_LOOP_THRESHOLD = 5  # Config.RestartCount at/above this => treat as a restart loop


@dataclass
class Decision:
    name: str
    state: str
    action: str
    reasons: List[str] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)

    def summary(self) -> str:
        lines = [f"[{self.name}] state={self.state} action={self.action}"]
        lines += [f"  reason: {r}" for r in self.reasons]
        lines += [f"  finding: {f}" for f in self.findings]
        return "\n".join(lines)


def _scan_logs(log_text: str) -> List[str]:
    findings = []
    for pattern, severity, advice in KNOWN_LOG_PATTERNS:
        if pattern.search(log_text or ""):
            findings.append(f"({severity}) {advice}")
    return findings


def evaluate(cfg: AgentConfig, name: str, dry_run: bool = False) -> Decision:
    if not dt.container_exists(name, dry_run=dry_run):
        return Decision(
            name=name, state="missing", action="create",
            reasons=["Container does not exist yet."],
        )

    info = dt.inspect_container(name, dry_run=dry_run) or {}
    running = info.get("State", {}).get("Running", False)
    restart_count = info.get("RestartCount", 0)
    logs_tail = dt.get_logs(name, tail=cfg.log_collection.get("tail_lines", 500), dry_run=dry_run)
    findings = _scan_logs(logs_tail)

    if restart_count >= RESTART_LOOP_THRESHOLD:
        return Decision(
            name=name, state="restart_loop", action="alert",
            reasons=[f"RestartCount={restart_count} >= threshold={RESTART_LOOP_THRESHOLD}; "
                     "Docker's own --restart=always policy is looping. Manual intervention required."],
            findings=findings,
        )

    if not running:
        return Decision(
            name=name, state="stopped", action="restart",
            reasons=["Container exists but is not running."],
            findings=findings,
        )

    if findings:
        return Decision(
            name=name, state="running", action="alert",
            reasons=["Container is running, but potential issues were found in recent logs."],
            findings=findings,
        )

    return Decision(name=name, state="running", action="none", reasons=["Healthy."])


def decide_and_act(
    cfg: AgentConfig,
    name: str,
    attempt_counters: dict,
    dry_run: bool = False,
) -> Decision:
    """Evaluate and, only if monitor.auto_restart is enabled in config,
    perform the recommended remediation (bounded by max_auto_restart_attempts
    per container per agent run, tracked in `attempt_counters`)."""
    decision = evaluate(cfg, name, dry_run=dry_run)
    monitor_cfg = cfg.monitor
    auto_restart = monitor_cfg.get("auto_restart", False)
    max_attempts = monitor_cfg.get("max_auto_restart_attempts", 3)

    if decision.action in ("restart", "create") and auto_restart:
        attempts = attempt_counters.get(name, 0)
        if attempts >= max_attempts:
            decision.action = "alert"
            decision.reasons.append(
                f"Auto-restart attempt budget exhausted ({attempts}/{max_attempts}); "
                "manual intervention required."
            )
            logger.warning(decision.summary())
            return decision

        attempt_counters[name] = attempts + 1
        logger.info("Auto-remediation enabled: attempting '%s' for '%s' (attempt %d/%d).",
                    decision.action, name, attempt_counters[name], max_attempts)
        if decision.action == "create":
            cm.start(cfg, name, dry_run=dry_run)
        else:
            cm.restart(name, dry_run=dry_run)
    else:
        if decision.action != "none":
            logger.warning(decision.summary())
        else:
            logger.info(decision.summary())

    return decision
