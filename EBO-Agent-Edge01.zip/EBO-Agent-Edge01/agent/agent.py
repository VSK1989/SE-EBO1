"""
agent/agent.py
================
Purpose
-------
The orchestrator and command-line interface (CLI) for the whole project.
This is the single entry point you (or a VS Code launch/task
configuration) invoke; it wires together config, logging, container
management, backup management, password-reset, trace-log extraction,
GraphDB management, the decision engine, and log collection.

Functionality
-------------
Provides the following subcommands (run `python run_agent.py --help`):

  list                    List all containers defined in config/servers.json
  status   <name>         Show current state + health assessment for a container
  start    <name>         Create (if needed) and start a container
           [--test-mode]  Use port-forwarding instead of a static IP (see
                           readme.md's "useful docker commands" example --
                           no IPvlan network required, connect via
                           https://localhost:1443)
  stop     <name>         Stop a container
  restart  <name>         Restart a container
  remove   <name>         Remove a stopped container
  upgrade  <name> <ver>   Upgrade a container to a new image version
  list-backups <name>     List available backups inside the container
  copy-backups <name> <dest>
                          Copy the container's backups to a host folder
  restore-backup <name> <version> <backup> <mode> [--from-host PATH]
                          Restore a backup (mode: ConfigurationOnly|AllData)
  password-reset-mode <name>
                          Put the container into password reset mode
                          (ported from Bash4Edge's verified implementation)
  get-trace <name> <destination>
                          Pull trace.log/trace.log.old directly out of the
                          server's database volume (ported from
                          get-trace.log) -- works even if the container
                          itself isn't running
  graphdb create|status|start|stop|remove <name>
                          Manage a Semantics/GraphDB companion container
  collect-logs [name]     Collect a diagnostic snapshot now (all containers if
                           name omitted) into the configured Downloads folder
  monitor  [--once]       Run the health-check + auto-remediation + log
                           collection loop (Ctrl+C to stop, or --once to run
                           a single pass -- useful for VS Code tasks/tests)

Every subcommand accepts --dry-run, which causes every Docker CLI command
to be logged instead of executed -- use this to validate the whole project
without needing a live Docker Desktop / EBO container (see
docs/VALIDATION.md).

How it interacts with other modules
------------------------------------
agent.py is the only module that imports every other module in the
package. It never talks to Docker or the filesystem directly itself --
all of that is delegated to container_manager.py, backup_tools.py,
password_reset.py, trace_tools.py, graphdb_tools.py, decision_engine.py,
and log_collector.py, keeping this file focused purely on argument parsing
and orchestration.

Configuration requirements
---------------------------
Loads config/servers.json via agent.config.load_config() at start-up. All
subcommands operate on the "servers" entries defined there (e.g. the
shipped "Edge01" example, pre-configured for IP 192.168.10.1 and image
ghcr.io/schneiderelectricbuildings/ebo-enterprise-server:
hf-712-cp-2-5000-consolidation).
"""
from __future__ import annotations

import argparse
import logging
import sys
import time

from . import backup_tools as bt
from . import container_manager as cm
from . import decision_engine as de
from . import graphdb_tools as gdt
from . import log_collector as lc
from . import password_reset as pr
from . import trace_tools as tt
from .config import ConfigError, load_config
from .logging_setup import configure_logging

logger = logging.getLogger(__name__)


def _print_status(status: dict, decision) -> None:
    print(f"\nContainer: {status['name']}")
    if not status.get("exists"):
        print("  Exists:   No")
    else:
        print(f"  Exists:        Yes")
        print(f"  Running:       {status['running']}")
        print(f"  Docker status: {status['status']}")
        print(f"  Restart count: {status['restart_count']}")
        print(f"  Image:         {status['image']}")
        print(f"  Started at:    {status['started_at']}")
    print(f"  Agent decision: state={decision.state} action={decision.action}")
    for r in decision.reasons:
        print(f"    - {r}")
    for f in decision.findings:
        print(f"    ! {f}")


def cmd_list(args, cfg):
    names = cfg.list_server_names()
    print("Configured servers:")
    for n in names:
        s = cfg.get_server(n)
        print(f"  - {n}: type={s.type} version={s.version} ip={s.ip}")
    gdb_names = cfg.list_graphdb_server_names()
    if gdb_names:
        print("Configured GraphDB servers:")
        for n in gdb_names:
            g = cfg.get_graphdb_server(n)
            print(f"  - {n}: {g.repository}:{g.version} ip={g.ip} port={g.port}")


def cmd_status(args, cfg):
    status = cm.status(args.name, dry_run=args.dry_run)
    decision = de.evaluate(cfg, args.name, dry_run=args.dry_run)
    _print_status(status, decision)


def cmd_start(args, cfg):
    ok = cm.start(cfg, args.name, dry_run=args.dry_run, test_mode=args.test_mode)
    sys.exit(0 if ok else 1)


def cmd_stop(args, cfg):
    ok = cm.stop(args.name, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_restart(args, cfg):
    ok = cm.restart(args.name, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_remove(args, cfg):
    ok = cm.remove(args.name, force=args.force, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_upgrade(args, cfg):
    ok = cm.upgrade(cfg, args.name, args.version, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_list_backups(args, cfg):
    files = bt.list_backups(cfg, args.name, dry_run=args.dry_run)
    if not files and not args.dry_run:
        print("No backups found (or container unreachable).")


def cmd_copy_backups(args, cfg):
    ok = bt.copy_backups(cfg, args.name, args.destination, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_restore_backup(args, cfg):
    ok = bt.restore_backup(
        cfg, args.name, args.version, args.backup, args.mode,
        from_host_path=args.from_host, dry_run=args.dry_run,
    )
    sys.exit(0 if ok else 1)


def cmd_password_reset_mode(args, cfg):
    ok = pr.set_password_reset_mode(cfg, args.name, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_get_trace(args, cfg):
    result = tt.get_trace(cfg, args.name, args.destination, dry_run=args.dry_run)
    sys.exit(0 if result is not None else 1)


def cmd_graphdb(args, cfg):
    if args.gdb_action == "create":
        ok = gdt.create(cfg, args.name, dry_run=args.dry_run)
    elif args.gdb_action == "status":
        s = gdt.status(args.name, dry_run=args.dry_run)
        print(s)
        return
    elif args.gdb_action == "start":
        ok = gdt.start(args.name, dry_run=args.dry_run)
    elif args.gdb_action == "stop":
        ok = gdt.stop(args.name, dry_run=args.dry_run)
    elif args.gdb_action == "remove":
        ok = gdt.remove(args.name, dry_run=args.dry_run)
    else:
        logger.error("Unknown graphdb action: %s", args.gdb_action)
        sys.exit(2)
    sys.exit(0 if ok else 1)


def cmd_collect_logs(args, cfg):
    if args.name:
        lc.collect_one(cfg, args.name, dry_run=args.dry_run)
    else:
        lc.collect_all(cfg, dry_run=args.dry_run)


def cmd_monitor(args, cfg):
    interval = cfg.monitor.get("poll_interval_seconds", 60)
    attempt_counters: dict = {}
    logger.info(
        "Starting monitor loop (interval=%ss, auto_restart=%s). Press Ctrl+C to stop.",
        interval, cfg.monitor.get("auto_restart", False),
    )
    try:
        while True:
            for name in cfg.list_server_names():
                de.decide_and_act(cfg, name, attempt_counters, dry_run=args.dry_run)
                lc.collect_one(cfg, name, dry_run=args.dry_run)
            if args.once:
                break
            time.sleep(interval)
    except KeyboardInterrupt:
        logger.info("Monitor loop stopped by user.")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ebo-agent",
        description="Lightweight rule-based AI Agent for managing EBO Docker containers "
                    "(e.g. Edge01) from VS Code / Docker Desktop.",
    )
    parser.add_argument("--dry-run", action="store_true",
                        help="Log Docker commands instead of executing them (safe validation mode).")
    parser.add_argument("--verbose", action="store_true", help="Enable debug-level console logging.")
    parser.add_argument("--config", default=None, help="Path to servers.json (default: config/servers.json).")

    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list", help="List configured servers.").set_defaults(func=cmd_list)

    p = sub.add_parser("status", help="Show status + health assessment for a container.")
    p.add_argument("name")
    p.set_defaults(func=cmd_status)

    p = sub.add_parser("start", help="Create (if needed) and start a container.")
    p.add_argument("name")
    p.add_argument("--test-mode", action="store_true",
                   help="Use port-forwarding (1080/1443/14444) instead of a static IP; "
                        "no IPvlan network required. See readme.md 'useful docker commands'.")
    p.set_defaults(func=cmd_start)

    p = sub.add_parser("stop", help="Stop a container.")
    p.add_argument("name")
    p.set_defaults(func=cmd_stop)

    p = sub.add_parser("restart", help="Restart a container.")
    p.add_argument("name")
    p.set_defaults(func=cmd_restart)

    p = sub.add_parser("remove", help="Remove a container.")
    p.add_argument("name")
    p.add_argument("--force", action="store_true")
    p.set_defaults(func=cmd_remove)

    p = sub.add_parser("upgrade", help="Upgrade a container to a new version.")
    p.add_argument("name")
    p.add_argument("version")
    p.set_defaults(func=cmd_upgrade)

    p = sub.add_parser("list-backups", help="List backups available inside the container.")
    p.add_argument("name")
    p.set_defaults(func=cmd_list_backups)

    p = sub.add_parser("copy-backups", help="Copy the container's backups to a host folder.")
    p.add_argument("name")
    p.add_argument("destination")
    p.set_defaults(func=cmd_copy_backups)

    p = sub.add_parser("restore-backup", help="Restore a backup (ConfigurationOnly or AllData).")
    p.add_argument("name")
    p.add_argument("version")
    p.add_argument("backup", help="Backup filename, e.g. 'Server 1 2022-09-09 14_12_36_5.0.0.1082.xbk'")
    p.add_argument("mode", choices=["ConfigurationOnly", "AllData"])
    p.add_argument("--from-host", default=None,
                   help="Path on the host to a backup file to copy in before restoring.")
    p.set_defaults(func=cmd_restore_backup)

    p = sub.add_parser("password-reset-mode", help="Put the container into password reset mode.")
    p.add_argument("name")
    p.set_defaults(func=cmd_password_reset_mode)

    p = sub.add_parser("get-trace", help="Pull trace.log files directly from the server's database volume.")
    p.add_argument("name")
    p.add_argument("destination", help="Host folder to copy trace.log/trace.log.old into.")
    p.set_defaults(func=cmd_get_trace)

    p = sub.add_parser("graphdb", help="Manage a Semantics/GraphDB companion container.")
    p.add_argument("gdb_action", choices=["create", "status", "start", "stop", "remove"])
    p.add_argument("name", help="Name of the graphdb_servers entry in config/servers.json, e.g. GraphDb01")
    p.set_defaults(func=cmd_graphdb)

    p = sub.add_parser("collect-logs", help="Collect a diagnostic snapshot into the Downloads folder.")
    p.add_argument("name", nargs="?", default=None, help="Omit to collect for all configured servers.")
    p.set_defaults(func=cmd_collect_logs)

    p = sub.add_parser("monitor", help="Run the continuous health-check / auto-remediation / log-collection loop.")
    p.add_argument("--once", action="store_true", help="Run a single pass instead of looping forever.")
    p.set_defaults(func=cmd_monitor)

    return parser


def main(argv=None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    configure_logging(verbose=args.verbose)

    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        logger.error(str(exc))
        sys.exit(2)

    args.func(args, cfg)


if __name__ == "__main__":
    main()
