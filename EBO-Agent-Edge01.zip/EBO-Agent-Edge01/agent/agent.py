"""
agent/agent.py
================
Purpose
-------
The orchestrator and command-line interface (CLI) for the whole project.
This is the single entry point you (or a VS Code launch/task
configuration) invoke.

New in this cross-platform / plug-and-play enhancement pass
-----------------------------------------------------------------
  discover          Auto-detect which configured servers exist, are
                     running, and whether their IP has drifted from
                     config/servers.yml -- the Python-side equivalent of
                     Bash4Edge's own discovery-style menu options.
  validate          Run discover + a TCP connectivity check against every
                     configured server.
  sync-ip           Like discover, but automatically corrects any drifted
                     IP address directly in config/servers.yml (a single,
                     surgical line edit per server -- every comment and
                     every other line is left untouched).
  auto              The full "plug-and-play" one-shot: load config ->
                     discover -> validate connectivity -> start monitoring.
                     This is the ONE command a brand-new user needs to run
                     after installing Docker and editing servers.yml.

Every subcommand accepts --dry-run and --verbose as before. Commands that
previously took a container NAME (start, stop, restart, remove, status,
upgrade, list-backups, copy-backups, restore-backup, password-reset-mode,
get-trace) now accept EITHER a configured server's name OR its IP address
(see container_manager.resolve_target()).

How it interacts with other modules
------------------------------------
agent.py is the only module that imports every other module in the
package; it never talks to Docker or the filesystem directly itself.

Configuration requirements
---------------------------
Loads config/servers.yml via agent.config.load_config() at start-up.
"""
from __future__ import annotations

import argparse
import logging
import sys
import time

from . import backup_tools as bt
from . import container_manager as cm
from . import decision_engine as de
from . import discovery
from . import graphdb_tools as gdt
from . import log_collector as lc
from . import password_reset as pr
from . import platform_utils as pf
from . import trace_tools as tt
from .config import ConfigError, load_config
from .logging_setup import configure_logging

logger = logging.getLogger(__name__)


def _print_status(status: dict, decision) -> None:
    print(f"\nContainer: {status['name']}")
    if not status.get("exists"):
        print("  Exists:   No")
    else:
        print(f"  Exists:        Yes")
        print(f"  Running:       {status['running']}")
        print(f"  Docker status: {status['status']}")
        print(f"  Restart count: {status['restart_count']}")
        print(f"  Image:         {status['image']}")
        print(f"  Started at:    {status['started_at']}")
    print(f"  Agent decision: state={decision.state} action={decision.action}")
    for r in decision.reasons:
        print(f"    - {r}")
    for f in decision.findings:
        print(f"    ! {f}")


def _print_discovery(results) -> None:
    for d in results:
        print(f"\n{d.name}:")
        print(f"  Exists:        {d.exists}")
        print(f"  Running:       {d.running}")
        print(f"  Configured IP: {d.configured_ip}")
        print(f"  Runtime IP:    {d.runtime_ip or '(not running)'}")
        if d.ip_drifted:
            print(f"  \u26a0 IP DRIFT DETECTED -- run 'sync-ip' to correct config/servers.yml")
        if d.reachable is not None:
            print(f"  Connectivity:  {d.reachable_detail}")


def cmd_list(args, cfg):
    names = cfg.list_server_names()
    print(f"Host OS detected: {pf.detect_os()}  (network strategy: {pf.network_strategy()})")
    print("Configured servers:")
    for n in names:
        s = cfg.get_server(n)
        print(f"  - {n}: type={s.type} version={s.version} ip={s.ip}")
    gdb_names = cfg.list_graphdb_server_names()
    if gdb_names:
        print("Configured GraphDB servers:")
        for n in gdb_names:
            g = cfg.get_graphdb_server(n)
            print(f"  - {n}: {g.repository}:{g.version} ip={g.ip} port={g.port}")


def cmd_status(args, cfg):
    status = cm.status(args.name, cfg=cfg, dry_run=args.dry_run)
    decision = de.evaluate(cfg, args.name, dry_run=args.dry_run)
    _print_status(status, decision)


def cmd_start(args, cfg):
    ok = cm.start(cfg, args.name, dry_run=args.dry_run, test_mode=args.test_mode)
    sys.exit(0 if ok else 1)


def cmd_stop(args, cfg):
    ok = cm.stop(args.name, cfg=cfg, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_restart(args, cfg):
    ok = cm.restart(args.name, cfg=cfg, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_remove(args, cfg):
    ok = cm.remove(args.name, cfg=cfg, force=args.force, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_upgrade(args, cfg):
    ok = cm.upgrade(cfg, args.name, args.version, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_list_backups(args, cfg):
    files = bt.list_backups(cfg, args.name, dry_run=args.dry_run)
    if not files and not args.dry_run:
        print("No backups found (or container unreachable).")


def cmd_copy_backups(args, cfg):
    ok = bt.copy_backups(cfg, args.name, args.destination, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_restore_backup(args, cfg):
    ok = bt.restore_backup(cfg, args.name, args.version, args.backup, args.mode,
                            from_host_path=args.from_host, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_password_reset_mode(args, cfg):
    ok = pr.set_password_reset_mode(cfg, args.name, dry_run=args.dry_run)
    sys.exit(0 if ok else 1)


def cmd_get_trace(args, cfg):
    result = tt.get_trace(cfg, args.name, args.destination, dry_run=args.dry_run)
    sys.exit(0 if result is not None else 1)


def cmd_graphdb(args, cfg):
    if args.gdb_action == "create":
        ok = gdt.create(cfg, args.name, dry_run=args.dry_run)
    elif args.gdb_action == "status":
        print(gdt.status(args.name, dry_run=args.dry_run)); return
    elif args.gdb_action == "start":
        ok = gdt.start(args.name, dry_run=args.dry_run)
    elif args.gdb_action == "stop":
        ok = gdt.stop(args.name, dry_run=args.dry_run)
    elif args.gdb_action == "remove":
        ok = gdt.remove(args.name, dry_run=args.dry_run)
    else:
        logger.error("Unknown graphdb action: %s", args.gdb_action); sys.exit(2)
    sys.exit(0 if ok else 1)


def cmd_collect_logs(args, cfg):
    if args.name:
        lc.collect_one(cfg, args.name, dry_run=args.dry_run)
    else:
        lc.collect_all(cfg, dry_run=args.dry_run)


def cmd_discover(args, cfg):
    results = discovery.discover_servers(cfg, dry_run=args.dry_run, force=True)
    _print_discovery(results)


def cmd_validate(args, cfg):
    results = discovery.validate_all(cfg, dry_run=args.dry_run)
    _print_discovery(results)
    unreachable = [d for d in results if d.reachable is False]
    sys.exit(1 if unreachable else 0)


def cmd_sync_ip(args, cfg):
    messages = discovery.sync_ip_drift(cfg, auto_fix=not args.report_only, dry_run=args.dry_run)
    if not messages:
        print("No IP drift detected -- config/servers.yml already matches Docker's runtime state.")
    for m in messages:
        print(m)


def cmd_monitor(args, cfg):
    interval = cfg.monitor.get("poll_interval_seconds", 60)
    attempt_counters: dict = {}
    logger.info("Starting monitor loop (interval=%ss, auto_restart=%s). Press Ctrl+C to stop.",
                interval, cfg.monitor.get("auto_restart", False))
    try:
        while True:
            for name in cfg.list_server_names():
                de.decide_and_act(cfg, name, attempt_counters, dry_run=args.dry_run)
                lc.collect_one(cfg, name, dry_run=args.dry_run)
            if args.once:
                break
            time.sleep(interval)
    except KeyboardInterrupt:
        logger.info("Monitor loop stopped by user.")


def cmd_auto(args, cfg):
    """The one-shot plug-and-play command: discover -> validate -> (sync-ip
    if requested) -> start monitoring. This is the single command a
    brand-new user needs after installing Docker and editing servers.yml."""
    logger.info("=== Step 1/4: Host detection ===")
    logger.info("Detected OS: %s | Network strategy: %s", pf.detect_os(), pf.network_strategy())

    logger.info("=== Step 2/4: Discovering configured servers ===")
    results = discovery.discover_servers(cfg, dry_run=args.dry_run, force=True)
    _print_discovery(results)

    if args.sync_ip:
        logger.info("=== Step 2b/4: Syncing any drifted IP addresses ===")
        for m in discovery.sync_ip_drift(cfg, auto_fix=True, dry_run=args.dry_run):
            logger.info(m)

    logger.info("=== Step 3/4: Validating connectivity ===")
    results = discovery.validate_all(cfg, dry_run=args.dry_run)
    _print_discovery(results)

    logger.info("=== Step 4/4: Starting monitor loop (Ctrl+C to stop) ===")
    cmd_monitor(args, cfg)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="ebo-agent",
        description="Cross-platform, rule-based AI Agent for managing EBO Docker containers "
                    "defined in config/servers.yml (Windows Docker Desktop + Linux + Bash4Edge).",
    )
    parser.add_argument("--dry-run", action="store_true", help="Log Docker commands instead of executing them.")
    parser.add_argument("--verbose", action="store_true", help="Enable debug-level console logging.")
    parser.add_argument("--config", default=None, help="Path to servers.yml (default: config/servers.yml).")

    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("list", help="List configured servers and detected host OS/network strategy.").set_defaults(func=cmd_list)

    p = sub.add_parser("status", help="Show status + health assessment for a container (name or IP).")
    p.add_argument("name"); p.set_defaults(func=cmd_status)

    p = sub.add_parser("start", help="Create (if needed) and start a container.")
    p.add_argument("name")
    p.add_argument("--test-mode", action="store_true", help="Force port-forwarding instead of a static IP.")
    p.set_defaults(func=cmd_start)

    p = sub.add_parser("stop", help="Stop a container (name or IP).")
    p.add_argument("name"); p.set_defaults(func=cmd_stop)

    p = sub.add_parser("restart", help="Restart a container (name or IP).")
    p.add_argument("name"); p.set_defaults(func=cmd_restart)

    p = sub.add_parser("remove", help="Remove a container (name or IP).")
    p.add_argument("name"); p.add_argument("--force", action="store_true"); p.set_defaults(func=cmd_remove)

    p = sub.add_parser("upgrade", help="Upgrade a container to a new version.")
    p.add_argument("name"); p.add_argument("version"); p.set_defaults(func=cmd_upgrade)

    p = sub.add_parser("list-backups", help="List backups available inside the container.")
    p.add_argument("name"); p.set_defaults(func=cmd_list_backups)

    p = sub.add_parser("copy-backups", help="Copy the container's backups to a host folder.")
    p.add_argument("name"); p.add_argument("destination"); p.set_defaults(func=cmd_copy_backups)

    p = sub.add_parser("restore-backup", help="Restore a backup (ConfigurationOnly or AllData).")
    p.add_argument("name"); p.add_argument("version")
    p.add_argument("backup", help="Backup filename")
    p.add_argument("mode", choices=["ConfigurationOnly", "AllData"])
    p.add_argument("--from-host", default=None, help="Path on the host to a backup file to copy in before restoring.")
    p.set_defaults(func=cmd_restore_backup)

    p = sub.add_parser("password-reset-mode", help="Put the container into password reset mode.")
    p.add_argument("name"); p.set_defaults(func=cmd_password_reset_mode)

    p = sub.add_parser("get-trace", help="Pull trace.log files directly from the server's database volume.")
    p.add_argument("name"); p.add_argument("destination"); p.set_defaults(func=cmd_get_trace)

    p = sub.add_parser("graphdb", help="Manage a Semantics/GraphDB companion container.")
    p.add_argument("gdb_action", choices=["create", "status", "start", "stop", "remove"])
    p.add_argument("name"); p.set_defaults(func=cmd_graphdb)

    p = sub.add_parser("collect-logs", help="Collect a diagnostic snapshot into the Downloads folder.")
    p.add_argument("name", nargs="?", default=None); p.set_defaults(func=cmd_collect_logs)

    p = sub.add_parser("discover", help="Auto-detect configured servers' existence, running state, and IP drift.")
    p.set_defaults(func=cmd_discover)

    p = sub.add_parser("validate", help="Discover + run a TCP connectivity check against every configured server.")
    p.set_defaults(func=cmd_validate)

    p = sub.add_parser("sync-ip", help="Detect and correct IP drift between Docker and config/servers.yml.")
    p.add_argument("--report-only", action="store_true", help="Report drift without editing servers.yml.")
    p.set_defaults(func=cmd_sync_ip)

    p = sub.add_parser("monitor", help="Run the continuous health-check / auto-remediation / log-collection loop.")
    p.add_argument("--once", action="store_true", help="Run a single pass instead of looping forever.")
    p.set_defaults(func=cmd_monitor)

    p = sub.add_parser("auto", help="Plug-and-play: discover + validate + (optionally sync-ip) + monitor, in one command.")
    p.add_argument("--once", action="store_true", help="Run a single monitor pass instead of looping forever.")
    p.add_argument("--sync-ip", action="store_true", help="Also auto-correct any drifted IPs in servers.yml.")
    p.set_defaults(func=cmd_auto)

    return parser


def main(argv=None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    configure_logging(verbose=args.verbose)

    try:
        cfg = load_config(args.config)
    except ConfigError as exc:
        logger.error(str(exc))
        sys.exit(2)

    args.func(args, cfg)


if __name__ == "__main__":
    main()
