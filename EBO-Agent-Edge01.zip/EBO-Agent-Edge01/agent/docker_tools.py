r"""
agent/docker_tools.py
=======================
Purpose
-------
The ONLY module in this project that talks to the Docker CLI directly.
Every other module that needs to interact with Docker goes through the
functions defined here. This keeps subprocess/security handling
(argument validation, list-form subprocess calls, dry-run support) in one
place, instead of duplicated across the codebase.

Direct lineage from the uploaded files
-----------------------------------------
The two uploaded start scripts used two DIFFERENT subprocess patterns:
  - start.py:      subprocess.check_output(cmd)              where cmd is a LIST
  - teststart.py:  subprocess.check_output(shlex.split(cmd))  where cmd is a STRING
Both were reviewed and this project deliberately standardises on start.py's
list-based pattern everywhere (see exe() below), because building a single
shell STRING (as teststart.py does, with an f-string) and then re-splitting
it with shlex is more prone to subtle quoting/injection bugs than keeping
arguments as a list from end to end.

start.py's own _validate_arg() whitelist function was kept, with its EXACT
original character class (`[A-Za-z0-9._:/@=-]+`), reused here as
validate_token(). One deliberate, documented improvement was made: the
original start.py only calls _validate_arg() on --name, --version, --ip,
--type, --accept-eula, --graphdb, --dns, and --ca-folder/--ca-bundle -- it
never validates --http-proxy/--https-proxy/--no-proxy at all. This project
validates EVERY value that reaches a Docker command line, including proxy
values, and widens the whitelist by exactly two characters beyond the
original:
  - comma, so that legitimate comma-separated no_proxy host lists (e.g.
    "localhost,127.0.0.1,example.local") are not rejected;
  - backslash, because this project (unlike start.py's Linux-oriented
    example paths) targets Windows + Docker Desktop, where bind-mount
    SOURCE paths are naturally written as "C:\Users\...\Downloads\..." and
    Docker Desktop's CLI integration expects/accepts that format directly.
Neither comma nor backslash is a shell metacharacter capable of command
injection in the list-based subprocess calls used throughout this project
(no shell=True is ever used); see docs/SOURCE_FILES_REVIEW.md for this
specific, called-out decision.

Also ported, verified, from get-trace.log: the pattern of mounting a named
Docker volume (read-only is not required by the original, so not assumed)
into a short-lived, disposable `ubuntu:focal` container to extract files
from it without needing the actual EBO server container to be running.
This is exposed generically here as run_ephemeral_against_volume() and used
by trace_tools.py.

Functionality
-------------
- exe(): runs a command given as a LIST of arguments (never a shell string,
  never shell=True) and returns (return_code, stdout, stderr).
- validate_token(): whitelist validation (see above) applied to any value
  that ends up in a Docker command line (names, IPs, versions, image tags,
  paths, proxy values).
- Thin, purpose-built wrappers: docker_available(), image_exists_locally(),
  pull_image(), container_exists(), inspect_container(), is_running(),
  get_logs(), start_container_cmd(), stop_container(), restart_container(),
  remove_container(), network_exists(), create_ipvlan_network(),
  docker_exec() (used by backup_tools.py / password_reset.py to run
  commands inside a LIVE container, analogous to how upgrade.py runs
  `/opt/sbo/bin/prepare-upgrade` inside an ephemeral one), and
  run_ephemeral_against_volume() (used by trace_tools.py, ported from
  get-trace.log).
- DRY_RUN mode: when dry_run=True is passed (or the CLI --dry-run flag is
  used), every mutating command is printed/logged instead of executed. This
  lets the whole agent be validated end-to-end without touching a real
  Docker Desktop installation (see docs/VALIDATION.md).

How it interacts with other modules
------------------------------------
- container_manager.py uses these wrappers to implement start/stop/restart/
  upgrade/status.
- trace_tools.py uses run_ephemeral_against_volume() to reproduce
  get-trace.log's behaviour exactly.
- backup_tools.py, password_reset.py, and graphdb_tools.py use docker_exec()/
  exe() to reproduce the behaviour described for the Bash4Edge/readme.md
  documented scripts.
- decision_engine.py uses inspect_container()/get_logs() to evaluate
  container health.
- log_collector.py uses get_logs()/inspect_container() to gather the
  diagnostic snapshot written to the Downloads folder.

Configuration requirements
---------------------------
Requires the `docker` executable to be on PATH (Docker Desktop, with the
"Expose daemon on tcp/CLI integration" default settings, satisfies this on
Windows/VS Code). No Python package (e.g. the `docker` PyPI SDK) is
required; only the standard library `subprocess` module is used, so there
is nothing to `pip install` for this file to work.
"""
from __future__ import annotations

import json
import logging
import re
import subprocess
from typing import List, Optional, Tuple

logger = logging.getLogger(__name__)

# Original start.py whitelist is r'[A-Za-z0-9._:/@=\-]+' (no comma, no
# backslash). Widened by exactly two characters (comma, backslash) to
# safely support comma-separated no_proxy host lists and Windows-style
# "C:\Users\..." bind-mount source paths; see module docstring for the
# full rationale.
_TOKEN_RE = re.compile(r"^[A-Za-z0-9._:/@=,\\\-]+$")


class DockerError(Exception):
    """Raised for any docker CLI invocation failure."""


def validate_token(value: Optional[str], field_name: str) -> Optional[str]:
    """Whitelist-validate a value destined for a docker command line.

    Ports start.py's _validate_arg(), with the character class widened by
    two characters (comma, backslash) as documented in the module
    docstring. Rejects whitespace and shell metacharacters so a
    malicious/malformed config value cannot be used for command/argument
    injection.
    """
    if value is None or value == "":
        return value
    if not _TOKEN_RE.fullmatch(value):
        raise ValueError(f"Invalid characters in {field_name}: {value!r}")
    return value


def exe(cmd: List[str], dry_run: bool = False, check: bool = False) -> Tuple[int, str, str]:
    """Run `cmd` (a list of args, never a shell string) and return
    (returncode, stdout, stderr).

    If dry_run is True, the command is logged but NOT executed, and a
    synthetic success result is returned. This is what allows the agent to
    be tested/validated without a real Docker Desktop instance.
    """
    printable = " ".join(cmd)
    if dry_run:
        logger.info("[DRY-RUN] %s", printable)
        return 0, "", ""

    logger.debug("Running: %s", printable)
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=False)
    except FileNotFoundError as exc:
        raise DockerError(
            "Could not execute 'docker'. Is Docker Desktop installed and is "
            "'docker' on your PATH? See README.md > Troubleshooting."
        ) from exc

    if check and result.returncode != 0:
        raise DockerError(
            f"Command failed ({result.returncode}): {printable}\n{result.stderr.strip()}"
        )
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def docker_available(dry_run: bool = False) -> bool:
    """Return True if the docker CLI responds and the daemon is reachable.

    Deliberately swallows DockerError (e.g. 'docker' not on PATH at all) and
    returns False instead, since this function is meant to be a safe,
    non-throwing health pre-check used by the CLI/monitor loop.
    """
    try:
        rc, _out, _err = exe(["docker", "version", "--format", "{{.Server.Version}}"], dry_run=dry_run)
    except DockerError:
        return False
    return rc == 0


def container_exists(name: str, dry_run: bool = False) -> bool:
    validate_token(name, "container name")
    rc, out, _err = exe(["docker", "ps", "-a", "--format", "{{.Names}}"], dry_run=dry_run)
    if dry_run:
        return False
    return name in out.splitlines()


def inspect_container(name: str, dry_run: bool = False) -> Optional[dict]:
    """Return the parsed `docker inspect` output for a container, or None if
    it does not exist."""
    validate_token(name, "container name")
    rc, out, err = exe(["docker", "inspect", name], dry_run=dry_run)
    if dry_run or rc != 0 or not out:
        return None
    try:
        data = json.loads(out)
        return data[0] if data else None
    except (json.JSONDecodeError, IndexError) as exc:
        logger.warning("Could not parse 'docker inspect %s' output: %s", name, exc)
        return None


def is_running(name: str, dry_run: bool = False) -> bool:
    info = inspect_container(name, dry_run=dry_run)
    if not info:
        return False
    return bool(info.get("State", {}).get("Running", False))


def get_logs(name: str, tail: int = 500, dry_run: bool = False) -> str:
    validate_token(name, "container name")
    rc, out, err = exe(["docker", "logs", "--tail", str(int(tail)), name], dry_run=dry_run)
    if dry_run:
        return "[DRY-RUN] no logs retrieved"
    return out if rc == 0 else f"<error retrieving logs: {err}>"


def stop_container(name: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    return exe(["docker", "stop", name], dry_run=dry_run)


def start_existing_container(name: str, dry_run: bool = False) -> Tuple[int, str, str]:
    """Start a container that was previously created (docker start), as
    opposed to creating a brand-new one with `docker run` (see
    container_manager.build_run_command)."""
    validate_token(name, "container name")
    return exe(["docker", "start", name], dry_run=dry_run)


def restart_container(name: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    return exe(["docker", "restart", name], dry_run=dry_run)


def remove_container(name: str, force: bool = False, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    cmd = ["docker", "rm"]
    if force:
        cmd.append("-f")
    cmd.append(name)
    return exe(cmd, dry_run=dry_run)


def run_container(cmd: List[str], dry_run: bool = False) -> Tuple[int, str, str]:
    """Execute a fully-built `docker run ...` command list (see
    container_manager.build_run_command)."""
    return exe(cmd, dry_run=dry_run)


def docker_exec(name: str, args: List[str], dry_run: bool = False) -> Tuple[int, str, str]:
    """Run a command INSIDE an already-running container (`docker exec`).

    Used by backup_tools.py to reach the server's own backup-management
    binaries (as implied by readme.md's list-backups/copy-backups/
    restore-backup scripts), the same way upgrade.py reaches
    /opt/sbo/bin/prepare-upgrade and /opt/sbo/bin/get-upgrade-log inside an
    ephemeral container.
    """
    validate_token(name, "container name")
    for a in args:
        validate_token(a, "exec argument")
    return exe(["docker", "exec", name] + args, dry_run=dry_run)


def copy_from_container(name: str, container_path: str, host_path: str, dry_run: bool = False) -> Tuple[int, str, str]:
    """`docker cp <container>:<path> <host_path>` -- used by
    backup_tools.copy_backups()."""
    validate_token(name, "container name")
    return exe(["docker", "cp", f"{name}:{container_path}", host_path], dry_run=dry_run)


def copy_to_container(host_path: str, name: str, container_path: str, dry_run: bool = False) -> Tuple[int, str, str]:
    """`docker cp <host_path> <container>:<path>` -- used by
    backup_tools.restore_backup() when restoring from a host-side backup
    file, matching the 'path to a backup on the host' usage shown in
    readme.md's restore-backup examples."""
    validate_token(name, "container name")
    return exe(["docker", "cp", host_path, f"{name}:{container_path}"], dry_run=dry_run)


def run_ephemeral_against_volume(
    image: str,
    volume: str,
    volume_target: str,
    bind_source: Optional[str],
    bind_target: Optional[str],
    shell_command: str,
    dry_run: bool = False,
) -> Tuple[int, str, str]:
    """Run a disposable container that mounts a named Docker VOLUME and
    (optionally) a host-folder BIND mount, executes `shell_command` inside
    it, and is removed immediately afterwards (`docker run --rm`).

    This is a direct, verified port of get-trace.log's pattern:
        docker run --rm \\
            --mount type=bind,source=<DEST_FOLDER>,target=/mnt \\
            --mount source=<NAME>-db,target=/var/sbo \\
            ubuntu:focal bash -c "cp /var/sbo/db/logs/trace* /mnt/"

    It works even if the actual EBO server container has been stopped or
    removed, because it only needs the named VOLUME to still exist -- not
    the container. Used by trace_tools.get_trace().
    """
    validate_token(image, "image")
    validate_token(volume, "volume")
    validate_token(volume_target, "volume_target")
    cmd = ["docker", "run", "--rm"]
    if bind_source and bind_target:
        validate_token(bind_source, "bind_source")
        validate_token(bind_target, "bind_target")
        cmd += ["--mount", f"type=bind,source={bind_source},target={bind_target}"]
    cmd += ["--mount", f"source={volume},target={volume_target}", image, "bash", "-c", shell_command]
    return exe(cmd, dry_run=dry_run)


def network_exists(name: str, dry_run: bool = False) -> bool:
    validate_token(name, "network name")
    rc, out, _err = exe(["docker", "network", "ls", "--format", "{{.Name}}"], dry_run=dry_run)
    if dry_run:
        return True
    return name in out.splitlines()


def create_ipvlan_network(
    name: str, subnet: str, gateway: str, parent_interface: str, dry_run: bool = False
) -> Tuple[int, str, str]:
    """Python re-implementation of the repo's ./create-bridged-network
    <subnet> <gateway> <interface> shell script, as documented in
    readme.md's 'Network' section."""
    for value, field_name in (
        (name, "network name"),
        (subnet, "subnet"),
        (gateway, "gateway"),
        (parent_interface, "parent_interface"),
    ):
        validate_token(value, field_name)
    cmd = [
        "docker", "network", "create",
        "-d", "ipvlan",
        "--subnet", subnet,
        "--gateway", gateway,
        "-o", f"parent={parent_interface}",
        name,
    ]
    return exe(cmd, dry_run=dry_run)


def pull_image(image: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(image, "image")
    return exe(["docker", "pull", image], dry_run=dry_run)
