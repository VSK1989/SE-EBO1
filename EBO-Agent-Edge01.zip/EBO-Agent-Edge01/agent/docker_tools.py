r"""
agent/docker_tools.py
=======================
Purpose
-------
The ONLY module in this project that talks to the Docker CLI directly.
Every other module that needs to interact with Docker goes through the
functions defined here. This keeps subprocess/security handling
(argument validation, list-form subprocess calls, dry-run support,
cross-platform path handling, and lightweight retry logic) in one place.

Direct lineage from the uploaded files
-----------------------------------------
The two uploaded start scripts used two DIFFERENT subprocess patterns:
  - start.py:      subprocess.check_output(cmd)              where cmd is a LIST
  - teststart.py:  subprocess.check_output(shlex.split(cmd))  where cmd is a STRING
Both were reviewed and this project deliberately standardises on start.py's
list-based pattern everywhere (see exe() below).

start.py's own _validate_arg() whitelist function was kept, with its EXACT
original character class (`[A-Za-z0-9._:/@=-]+`), reused here as
validate_token(), widened by exactly two characters (comma, backslash) for
reasons documented below.

Also ported, verified, from get-trace.log: the pattern of mounting a named
Docker volume into a short-lived, disposable `ubuntu:focal` container to
extract files from it without needing the actual EBO server container to
be running. This is exposed generically here as
run_ephemeral_against_volume() and used by trace_tools.py, backup_tools.py,
and password_reset.py.

What changed in this cross-platform enhancement pass
---------------------------------------------------------
- Every function that accepts a host-side bind-mount SOURCE path now runs
  it through platform_utils.normalize_bind_source() before it reaches the
  Docker CLI, so a path written in config/servers.yml as a Windows path
  (e.g. the Downloads folder) still works correctly when the agent happens
  to be launched from inside WSL, and vice versa.
- exe() gained an optional `retries` parameter: a small, bounded retry with
  a short backoff for the narrow class of genuinely transient failures
  (the Docker daemon briefly not responding), improving "error handling
  and recovery" without masking real, persistent errors (non-transient
  failures still return immediately on the first attempt).

Functionality
-------------
- exe(): runs a command given as a LIST of arguments (never a shell
  string, never shell=True) and returns (return_code, stdout, stderr).
- validate_token(): whitelist validation applied to any value that ends up
  in a Docker command line.
- Thin, purpose-built wrappers: docker_available(), pull_image(),
  container_exists(), inspect_container(), is_running(), get_logs(),
  start/stop/restart/remove_container(), run_container(), docker_exec(),
  copy_from_container(), copy_to_container(), run_ephemeral_against_volume(),
  network_exists(), create_ipvlan_network().
- DRY_RUN mode: when dry_run=True, every mutating command is logged
  instead of executed.

How it interacts with other modules
------------------------------------
- agent/discovery.py wraps several of these calls with a short-lived cache
  to avoid repeated subprocess launches (performance).
- container_manager.py, trace_tools.py, backup_tools.py, password_reset.py,
  and graphdb_tools.py all delegate every actual Docker CLI call here.

Configuration requirements
---------------------------
Requires the `docker` executable to be on PATH. No Python package (e.g.
the `docker` PyPI SDK) is required; only the standard library `subprocess`
module is used.
"""
from __future__ import annotations

import json
import logging
import re
import subprocess
import time
from typing import List, Optional, Tuple

from . import platform_utils as pf

logger = logging.getLogger(__name__)

# Original start.py whitelist is r'[A-Za-z0-9._:/@=\-]+' (no comma, no
# backslash). Widened by exactly two characters (comma, backslash) to
# safely support comma-separated no_proxy host lists and Windows-style
# "C:\Users\..." bind-mount source paths. Neither character enables shell
# injection in this project's list-based, shell=True-free subprocess calls.
_TOKEN_RE = re.compile(r"^[A-Za-z0-9._:/@=,\\\-]+$")


class DockerError(Exception):
    """Raised for any docker CLI invocation failure."""


def validate_token(value: Optional[str], field_name: str) -> Optional[str]:
    """Whitelist-validate a value destined for a docker command line."""
    if value is None or value == "":
        return value
    if not _TOKEN_RE.fullmatch(value):
        raise ValueError(f"Invalid characters in {field_name}: {value!r}")
    return value


# Transient-error substrings worth a short, bounded retry. Deliberately
# narrow: a typo'd image name or an injection-blocked value must NEVER be
# retried, only genuinely transient daemon/communication hiccups.
_TRANSIENT_MARKERS = (
    "error during connect",
    "cannot connect to the docker daemon",
    "the system cannot find the file specified",  # Windows named-pipe hiccup
    "timeout",
)


def exe(
    cmd: List[str],
    dry_run: bool = False,
    check: bool = False,
    retries: int = 0,
    retry_delay: float = 1.0,
) -> Tuple[int, str, str]:
    """Run `cmd` (a list of args, never a shell string) and return
    (returncode, stdout, stderr).

    If dry_run is True, the command is logged but NOT executed.

    If `retries` > 0, a failed attempt whose stderr matches one of the
    narrow _TRANSIENT_MARKERS strings is retried up to `retries` times
    with `retry_delay` seconds between attempts; any other failure (or the
    final attempt) is returned immediately without masking the error.
    """
    printable = " ".join(cmd)
    if dry_run:
        logger.info("[DRY-RUN] %s", printable)
        return 0, "", ""

    attempt = 0
    while True:
        logger.debug("Running: %s", printable)
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
        except FileNotFoundError as exc:
            raise DockerError(
                "Could not execute 'docker'. Is Docker Desktop installed and is "
                "'docker' on your PATH? See README.md > Troubleshooting."
            ) from exc

        if result.returncode == 0:
            return result.returncode, result.stdout.strip(), result.stderr.strip()

        is_transient = any(marker in result.stderr.lower() for marker in _TRANSIENT_MARKERS)
        if is_transient and attempt < retries:
            attempt += 1
            logger.warning(
                "Transient Docker error (attempt %d/%d), retrying in %.1fs: %s",
                attempt, retries, retry_delay, result.stderr.strip()[:200],
            )
            time.sleep(retry_delay)
            continue

        if check:
            raise DockerError(
                f"Command failed ({result.returncode}): {printable}\n{result.stderr.strip()}"
            )
        return result.returncode, result.stdout.strip(), result.stderr.strip()


def docker_available(dry_run: bool = False) -> bool:
    """Return True if the docker CLI responds and the daemon is reachable."""
    try:
        rc, _out, _err = exe(["docker", "version", "--format", "{{.Server.Version}}"], dry_run=dry_run)
    except DockerError:
        return False
    return rc == 0


def container_exists(name: str, dry_run: bool = False) -> bool:
    validate_token(name, "container name")
    rc, out, _err = exe(["docker", "ps", "-a", "--format", "{{.Names}}"], dry_run=dry_run)
    if dry_run:
        return False
    return name in out.splitlines()


def inspect_container(name: str, dry_run: bool = False) -> Optional[dict]:
    validate_token(name, "container name")
    rc, out, err = exe(["docker", "inspect", name], dry_run=dry_run)
    if dry_run or rc != 0 or not out:
        return None
    try:
        data = json.loads(out)
        return data[0] if data else None
    except (json.JSONDecodeError, IndexError) as exc:
        logger.warning("Could not parse 'docker inspect %s' output: %s", name, exc)
        return None


def is_running(name: str, dry_run: bool = False) -> bool:
    info = inspect_container(name, dry_run=dry_run)
    if not info:
        return False
    return bool(info.get("State", {}).get("Running", False))


def get_logs(name: str, tail: int = 500, dry_run: bool = False) -> str:
    validate_token(name, "container name")
    rc, out, err = exe(["docker", "logs", "--tail", str(int(tail)), name], dry_run=dry_run)
    if dry_run:
        return "[DRY-RUN] no logs retrieved"
    return out if rc == 0 else f"<error retrieving logs: {err}>"


def stop_container(name: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    return exe(["docker", "stop", name], dry_run=dry_run)


def start_existing_container(name: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    return exe(["docker", "start", name], dry_run=dry_run)


def restart_container(name: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    return exe(["docker", "restart", name], dry_run=dry_run)


def remove_container(name: str, force: bool = False, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    cmd = ["docker", "rm"]
    if force:
        cmd.append("-f")
    cmd.append(name)
    return exe(cmd, dry_run=dry_run)


def run_container(cmd: List[str], dry_run: bool = False) -> Tuple[int, str, str]:
    return exe(cmd, dry_run=dry_run, retries=2)


def docker_exec(name: str, args: List[str], dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    for a in args:
        validate_token(a, "exec argument")
    return exe(["docker", "exec", name] + args, dry_run=dry_run)


def copy_from_container(name: str, container_path: str, host_path: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    host_path = pf.normalize_bind_source(host_path)
    return exe(["docker", "cp", f"{name}:{container_path}", host_path], dry_run=dry_run)


def copy_to_container(host_path: str, name: str, container_path: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(name, "container name")
    host_path = pf.normalize_bind_source(host_path)
    return exe(["docker", "cp", host_path, f"{name}:{container_path}"], dry_run=dry_run)


def run_ephemeral_against_volume(
    image: str,
    volume: str,
    volume_target: str,
    bind_source: Optional[str],
    bind_target: Optional[str],
    shell_command: str,
    dry_run: bool = False,
) -> Tuple[int, str, str]:
    """Run a disposable container that mounts a named Docker VOLUME and
    (optionally) a host-folder BIND mount, executes `shell_command` inside
    it, and is removed immediately afterwards. Ported, verified, from
    get-trace.log's pattern. Works even if the EBO server container has
    been stopped or removed, because it only needs the named VOLUME.
    """
    validate_token(image, "image")
    validate_token(volume, "volume")
    validate_token(volume_target, "volume_target")
    cmd = ["docker", "run", "--rm"]
    if bind_source and bind_target:
        bind_source = pf.normalize_bind_source(bind_source)
        validate_token(bind_source, "bind_source")
        validate_token(bind_target, "bind_target")
        cmd += ["--mount", f"type=bind,source={bind_source},target={bind_target}"]
    cmd += ["--mount", f"source={volume},target={volume_target}", image, "bash", "-c", shell_command]
    return exe(cmd, dry_run=dry_run)


def network_exists(name: str, dry_run: bool = False) -> bool:
    validate_token(name, "network name")
    rc, out, _err = exe(["docker", "network", "ls", "--format", "{{.Name}}"], dry_run=dry_run)
    if dry_run:
        return True
    return name in out.splitlines()


def create_ipvlan_network(
    name: str, subnet: str, gateway: str, parent_interface: str, dry_run: bool = False
) -> Tuple[int, str, str]:
    for value, field_name in (
        (name, "network name"), (subnet, "subnet"),
        (gateway, "gateway"), (parent_interface, "parent_interface"),
    ):
        validate_token(value, field_name)
    cmd = [
        "docker", "network", "create", "-d", "ipvlan",
        "--subnet", subnet, "--gateway", gateway,
        "-o", f"parent={parent_interface}", name,
    ]
    return exe(cmd, dry_run=dry_run)


def create_bridge_network(name: str, dry_run: bool = False) -> Tuple[int, str, str]:
    """A plain, ordinary Docker bridge network (no static host-LAN IP) --
    the default strategy on native Windows/Docker Desktop. See
    platform_utils.network_strategy() for why this differs from
    create_ipvlan_network() on that platform."""
    validate_token(name, "network name")
    return exe(["docker", "network", "create", name], dry_run=dry_run)


def pull_image(image: str, dry_run: bool = False) -> Tuple[int, str, str]:
    validate_token(image, "image")
    return exe(["docker", "pull", image], dry_run=dry_run, retries=1, retry_delay=2.0)
