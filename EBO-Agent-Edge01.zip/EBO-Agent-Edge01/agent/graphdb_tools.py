"""
agent/graphdb_tools.py
=========================
Purpose
-------
Equivalent of the Semantics/GraphDB companion container management
documented in readme.md's "GraphDB" section (usage only) and CONFIRMED,
command-for-command, against Bash4Edge's verified manageGraphDb.sh: no
volume mount, no EULA/env vars -- just a plain `docker run` with a static
IP on the configured network.

Functionality
-------------
- create(cfg, name): pulls the configured GraphDB image:version (from the
  `semanticsDbs` section of config/servers.yml -- the SAME section name
  Bash4Edge itself uses) and runs it with the exact flags Bash4Edge's
  verified script uses.
- status(name) / start(name) / stop(name) / remove(name): thin wrappers.
- Upgrade is deliberately NOT implemented, matching Bash4Edge's own
  manageGraphDb.sh, which shows "Upgrade option not available at this
  time" for every GraphDB entry (pinned to tagged version 10.2.4).

How it interacts with other modules
------------------------------------
- Reads a named entry from config/servers.yml's `semanticsDbs` section via
  agent.config.AgentConfig.get_graphdb_server().
- Uses agent.docker_tools for all Docker CLI calls.
- Exposed via agent.agent's `graphdb` CLI subcommand group.

Configuration requirements
---------------------------
Requires an entry under `semanticsDbs` in config/servers.yml. Not required
for -- and not used by -- the shipped Edge01 example, which has no
GraphDB configured (graphdb_URL left blank).
"""
from __future__ import annotations

import logging

from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def create(cfg: AgentConfig, name: str, dry_run: bool = False) -> bool:
    gdb = cfg.get_graphdb_server(name)
    image = f"{gdb.repository}:{gdb.version}"

    dt.pull_image(image, dry_run=dry_run)

    cmd = [
        "docker", "run", "-d",
        f"--name={gdb.name}",
        "-h", gdb.name,
        "--restart", "always",
        "--network", gdb.network,
        "--ip", gdb.ip,
        image,
    ]
    rc, out, err = dt.run_container(cmd, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to create GraphDB container '%s': %s", name, err)
        return False
    logger.info("Created and running '%s' container (id=%s).", name, out[:12] if out else "dry-run")
    logger.info("Once running, access it at http://%s:%s", gdb.ip, gdb.port)
    return True


def status(name: str, dry_run: bool = False) -> dict:
    if not dt.container_exists(name, dry_run=dry_run):
        return {"name": name, "exists": False}
    info = dt.inspect_container(name, dry_run=dry_run) or {}
    state = info.get("State", {})
    return {"name": name, "exists": True, "running": state.get("Running", False), "status": state.get("Status", "unknown")}


def start(name: str, dry_run: bool = False) -> bool:
    rc, _out, err = dt.start_existing_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to start GraphDB container '%s': %s", name, err)
        return False
    logger.info("Started '%s' container.", name)
    return True


def stop(name: str, dry_run: bool = False) -> bool:
    rc, _out, err = dt.stop_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to stop GraphDB container '%s': %s", name, err)
        return False
    logger.info("Stopped '%s' container.", name)
    return True


def remove(name: str, dry_run: bool = False) -> bool:
    dt.stop_container(name, dry_run=dry_run)
    rc, _out, err = dt.remove_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to remove GraphDB container '%s': %s", name, err)
        return False
    logger.info("Removed '%s' container.", name)
    return True
