"""
agent/graphdb_tools.py
=========================
Purpose
-------
Equivalent of the Semantics/GraphDB companion container management
documented in two places:
  - readme.md's "GraphDB" section (official image readme, usage only):
    "./start-graphdb 192.168.1.6" to start it, then create a GraphDB
    repository with id "nsp" (with context index enabled) via its web UI
    at http://<ip>:7200, then start the EBO server with
    --graphdb=http://<ip>:7200 so it uploads its ontologies.
  - Bash4Edge's manageGraphDb.sh (full, VERIFIED source, reviewed
    line-by-line), which manages the exact same ontotext/graphdb container
    via a "Create / Check Status & Logs / Start / Stop / Stop & Remove /
    Upgrade (not available)" menu.

This module is a RECONSTRUCTION of the Windows-side ./start-graphdb script
(its own source was not supplied, only its usage), but its command shape
is directly CONFIRMED by Bash4Edge's verified manageGraphDb.sh, which this
module mirrors precisely:

    docker run -d --name=<db_server> -h <db_server> --restart always \
        --network <network> --ip <ip> <image>

Notably, this command has NO volume mount and NO EULA/env vars at all --
confirmed by reading manageGraphDb.sh's "Create" case directly. This is
intentionally reproduced as-is rather than "improved" with an assumed
volume mount, since the verified source shows GraphDB is run without one
here.

Functionality
-------------
- create(cfg, name): pulls the configured GraphDB image:version and runs
  it with the exact flags shown above.
- status(name): returns running state via docker_tools.inspect_container().
- start(name) / stop(name): thin wrappers.
- remove(name): stops and removes the container (matching Bash4Edge's
  "Stop & Remove": leaves no volume behind to clean up, since none is
  created in the first place).
- Upgrade is deliberately NOT implemented, matching Bash4Edge's own
  manageGraphDb.sh, which shows "Upgrade option not available at this
  time because uses tagged version 10.2.4" for every GraphDB entry.

How it interacts with other modules
------------------------------------
- Reads a named entry from config/servers.json's graphdb_servers section
  (see agent.config.AgentConfig.get_graphdb_server()), which mirrors
  Bash4Edge's own semanticsDbs section in servers.yml.
- Uses agent.docker_tools for all Docker CLI calls.
- Exposed via agent.agent's `graphdb` CLI subcommand group.

Configuration requirements
---------------------------
Requires an entry under graphdb_servers in config/servers.json (repository,
version, port, network, ip). The shipped config/servers.json includes a
commented/example GraphDb01 entry; it is not required or used by the
default Edge01 example, which has graphdb="" (no Semantics/GraphDB
configured).
"""
from __future__ import annotations

import logging

from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def create(cfg: AgentConfig, name: str, dry_run: bool = False) -> bool:
    gdb = cfg.get_graphdb_server(name)
    image = f"{gdb.repository}:{gdb.version}"

    dt.pull_image(image, dry_run=dry_run)

    cmd = [
        "docker", "run", "-d",
        f"--name={gdb.name}",
        "-h", gdb.name,
        "--restart", "always",
        "--network", gdb.network,
        "--ip", gdb.ip,
        image,
    ]
    rc, out, err = dt.run_container(cmd, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to create GraphDB container '%s': %s", name, err)
        return False
    logger.info("Created and running '%s' container (id=%s).", name, out[:12] if out else "dry-run")
    logger.info("Once running, access it at http://%s:%s", gdb.ip, gdb.port)
    return True


def status(name: str, dry_run: bool = False) -> dict:
    if not dt.container_exists(name, dry_run=dry_run):
        return {"name": name, "exists": False}
    info = dt.inspect_container(name, dry_run=dry_run) or {}
    state = info.get("State", {})
    return {
        "name": name,
        "exists": True,
        "running": state.get("Running", False),
        "status": state.get("Status", "unknown"),
    }


def start(name: str, dry_run: bool = False) -> bool:
    rc, _out, err = dt.start_existing_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to start GraphDB container '%s': %s", name, err)
        return False
    logger.info("Started '%s' container.", name)
    return True


def stop(name: str, dry_run: bool = False) -> bool:
    rc, _out, err = dt.stop_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to stop GraphDB container '%s': %s", name, err)
        return False
    logger.info("Stopped '%s' container.", name)
    return True


def remove(name: str, dry_run: bool = False) -> bool:
    """Matches Bash4Edge's "Stop & Remove" (stop then rm). No volume is
    created by create(), so there is nothing further to delete."""
    dt.stop_container(name, dry_run=dry_run)
    rc, _out, err = dt.remove_container(name, dry_run=dry_run)
    if rc != 0:
        logger.error("Failed to remove GraphDB container '%s': %s", name, err)
        return False
    logger.info("Removed '%s' container.", name)
    return True
