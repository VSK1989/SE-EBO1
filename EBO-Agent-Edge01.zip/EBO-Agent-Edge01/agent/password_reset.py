"""
agent/password_reset.py
==========================
Purpose
-------
Python equivalent of putting an EBO server into Password Reset Mode, so an
administrator can reconnect via WorkStation and provide the Session ID to
PSS. The official image readme.md documents only the USAGE of this
feature (./password-reset-mode cs3 5.0.1.128) without showing its source.
However, Bash4Edge's manageServers.sh -- full, verified source, reviewed
line-by-line -- implements the exact same feature as its own "Password
Reset" menu option:

    "Password Reset")
        echo "Starting temporary container to reset password"
        docker run --rm --mount source=$db_vol,target=$db_folder $image_id \
            bash -c "mkdir -p /var/sbo/db/reset && touch /var/sbo/db/reset/r0.txt"
        echo "Password reset complete"
        ;;

This is notably SIMPLER than first assumed: it does NOT stop or restart the
server container at all. It simply runs a disposable container against the
SAME named database volume the live server is already using, and creates a
marker file (db/reset/r0.txt) inside it. The running EBO server process is
presumably watching for this marker and reacts by entering password reset
mode on its own -- no restart needed. This module is therefore marked as
PORTED (from the verified Bash4Edge source), not reconstructed, since the
exact mechanism has now been directly observed in reviewed source code.

Functionality
-------------
- set_password_reset_mode(cfg, name): runs an ephemeral container mounting
  the server's database volume and creates the db/reset/r0.txt marker file,
  exactly matching Bash4Edge's verified implementation. No stop/restart is
  performed, matching the original.

How it interacts with other modules
------------------------------------
- Uses agent.docker_tools.run_ephemeral_against_volume() for the ephemeral
  container invocation.
- Reads server config (type, version, db volume/folder) from agent.config.
- Exposed via agent.agent's `password-reset-mode` CLI subcommand.

Configuration requirements
---------------------------
Uses the same defaults.db_folder / db_vol_suffix settings as
container_manager.py. No additional configuration required.
"""
from __future__ import annotations

import logging

from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def set_password_reset_mode(cfg: AgentConfig, name: str, dry_run: bool = False) -> bool:
    """Port of Bash4Edge manageServers.sh's "Password Reset" option: creates
    a reset marker file inside the server's database volume via a
    disposable container. The live server container is left running and is
    NOT stopped or restarted, matching the verified original."""
    server = cfg.get_server(name)
    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"

    logger.info("Starting temporary container to reset password...")  # matches original log line
    rc, out, err = dt.run_ephemeral_against_volume(
        image=image,
        volume=db_vol,
        volume_target=db_folder,
        bind_source=None,
        bind_target=None,
        shell_command=f"mkdir -p {db_folder}/db/reset && touch {db_folder}/db/reset/r0.txt",
        dry_run=dry_run,
    )
    if rc != 0:
        logger.error("Failed to set password reset mode for '%s': %s", name, err)
        return False
    if out:
        logger.info(out)
    logger.info("Password reset complete.")  # matches original log line
    logger.info(
        "'%s' should now be in password reset mode. Reconnect via WorkStation "
        "and provide the Session ID to PSS.",
        name,
    )
    return True
