"""
agent/password_reset.py
==========================
Purpose
-------
Python equivalent of putting an EBO server into Password Reset Mode,
PORTED and VERIFIED from Bash4Edge's manageServers.sh "Password Reset"
case: an ephemeral container mounts the server's database volume and
touches a marker file (db/reset/r0.txt) -- no stop/restart of the live
server container occurs at all.

Functionality
-------------
- set_password_reset_mode(cfg, name_or_ip): resolves `name_or_ip` to a
  configured server (by name OR IP), then reproduces Bash4Edge's verified
  mechanism exactly.

How it interacts with other modules
------------------------------------
- Uses agent.container_manager.resolve_target() for name/IP flexibility.
- Uses agent.docker_tools.run_ephemeral_against_volume().
- Exposed via agent.agent's `password-reset-mode` CLI subcommand.

Configuration requirements
---------------------------
Uses the same defaults.db_folder / db_vol_suffix settings as
container_manager.py.
"""
from __future__ import annotations

import logging

from . import container_manager as cm
from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def set_password_reset_mode(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False) -> bool:
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    defaults = cfg.defaults
    db_vol = f"{name}{defaults.get('db_vol_suffix', '-db')}"
    db_folder = defaults.get("db_folder", "/var/sbo")
    image = f"ghcr.io/schneiderelectricbuildings/{server.type}:{server.version}"

    logger.info("Starting temporary container to reset password...")
    rc, out, err = dt.run_ephemeral_against_volume(
        image=image,
        volume=db_vol,
        volume_target=db_folder,
        bind_source=None,
        bind_target=None,
        shell_command=f"mkdir -p {db_folder}/db/reset && touch {db_folder}/db/reset/r0.txt",
        dry_run=dry_run,
    )
    if rc != 0:
        logger.error("Failed to set password reset mode for '%s': %s", name, err)
        return False
    if out:
        logger.info(out)
    logger.info("Password reset complete.")
    logger.info(
        "'%s' should now be in password reset mode. Reconnect via WorkStation "
        "and provide the Session ID to PSS.",
        name,
    )
    return True
