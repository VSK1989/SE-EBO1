"""
agent/discovery.py
=====================
Purpose
-------
The new "plug-and-play" engine: automatically discovers which configured
containers actually exist and are running on this Docker host, finds each
one's REAL current IP address (which may differ from what's written in
servers.yml, especially after a container recreation), validates that each
one is actually reachable over the network, and -- optionally -- writes a
corrected IP back into servers.yml when it has drifted. This is what lets a
brand-new user go from "installed Docker + edited servers.yml" straight to
"agent is monitoring my containers" with no other manual steps.

Performance design (why this file exists as ONE module)
------------------------------------------------------------
Earlier versions of this agent called `docker ps -a` and `docker inspect`
freshly, every single time any module needed to know about a container --
including once per server, per monitor loop iteration. For an installation
managing several servers, that is one full `docker` subprocess launch per
server per check, repeated forever. This module introduces a small,
explicit, time-boxed cache (default 5 seconds) for the two most expensive,
most frequently repeated calls (`docker ps -a` and `docker inspect`), so a
single discovery/validation/monitor pass only pays the subprocess cost once
per unique piece of information, not once per server that happens to share
it. This directly addresses the "faster container discovery" and "lower
resource consumption" requirements.

Functionality
-------------
- list_all_containers(force=False): ONE `docker ps -a` call (cached for
  `CACHE_TTL_SECONDS`), parsed into a list of {name, id, status, image}
  dicts. Every other function in this module, and container_manager.py,
  can reuse this instead of invoking Docker again.
- get_runtime_ip(name, force=False): ONE cached `docker inspect` call per
  container, returning the actual IP address Docker assigned on ANY
  network the container is attached to (not assuming a particular network
  name), so this works whether the container is using the configured
  ipvlan network (Path A/B Linux) or a Windows bridge network
  (Path A Windows -- see platform_utils.network_strategy()).
- discover_servers(cfg): for every server in servers.yml, reports whether
  it exists, is running, and what its configured vs. actual runtime IP is.
- sync_ip_drift(cfg, auto_fix=False): compares configured vs. actual IP for
  every server; if `auto_fix` is True and a mismatch is found, calls
  yaml_mini.update_scalar_in_file() to correct just that one line in
  servers.yml, exactly like Bash4Edge's own `yq -i eval` in-place edits.
- validate_connectivity(ip, port, timeout): a simple, dependency-free TCP
  connect test (works identically on Windows and Linux, unlike ICMP ping,
  which often needs elevated privileges on Windows and may be firewalled
  regardless) -- used to confirm a server is not just "a container that
  exists" but is actually answering network traffic.
- validate_all(cfg): runs validate_connectivity() for every configured
  server (by its ACTUAL runtime IP if the container is running, else its
  configured IP) and returns a structured report used by the `discover`
  and `auto` CLI commands and by decision_engine.py.

How it interacts with other modules
------------------------------------
- container_manager.py calls list_all_containers()/get_runtime_ip() instead
  of calling docker_tools directly for existence/IP checks, so it benefits
  from the same cache.
- decision_engine.py incorporates validate_connectivity() results into its
  health assessment (a container can be "running" per Docker yet still be
  unreachable, e.g. a wrong IP or a firewall -- this is now visible).
- agent.py's new `discover`, `validate`, and `auto` CLI commands are thin
  wrappers around discover_servers()/validate_all()/sync_ip_drift().

Configuration requirements
---------------------------
Reads monitor.connectivity_check_port / connectivity_timeout_seconds from
config/servers.yml's agentSettings section (see agent/config.py).
"""
from __future__ import annotations

import logging
import socket
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from . import docker_tools as dt
from . import yaml_mini
from .config import AgentConfig

logger = logging.getLogger(__name__)

CACHE_TTL_SECONDS = 5.0

# Module-level cache: {cache_key: (timestamp, value)}. Deliberately simple
# (no external cache library) -- this is a short-lived, in-process cache
# for the lifetime of a single CLI invocation or monitor loop, not a
# persistent store.
_cache: Dict[str, tuple] = {}


def _cached(key: str, producer, force: bool = False):
    now = time.monotonic()
    if not force and key in _cache:
        ts, value = _cache[key]
        if now - ts < CACHE_TTL_SECONDS:
            return value
    value = producer()
    _cache[key] = (now, value)
    return value


def clear_cache() -> None:
    """Drop all cached discovery data -- used by tests and by callers that
    know something changed (e.g. right after creating a new container)."""
    _cache.clear()


def list_all_containers(dry_run: bool = False, force: bool = False) -> List[dict]:
    """ONE cached `docker ps -a` call, parsed into structured rows."""
    def _producer():
        rc, out, err = dt.exe(
            ["docker", "ps", "-a", "--format", "{{.Names}}\t{{.ID}}\t{{.Status}}\t{{.Image}}"],
            dry_run=dry_run,
        )
        if dry_run or rc != 0:
            return []
        rows = []
        for line in out.splitlines():
            parts = line.split("\t")
            if len(parts) >= 4:
                rows.append({"name": parts[0], "id": parts[1], "status": parts[2], "image": parts[3]})
        return rows

    return _cached(f"ps_all:{dry_run}", _producer, force=force)


def container_exists_cached(name: str, dry_run: bool = False, force: bool = False) -> bool:
    return any(row["name"] == name for row in list_all_containers(dry_run=dry_run, force=force))


def get_runtime_ip(name: str, dry_run: bool = False, force: bool = False) -> Optional[str]:
    """Return the IP address Docker actually assigned to `name`, on
    whichever network it's attached to (works regardless of network name,
    so it's correct for both the ipvlan strategy and the Windows
    bridge_ports strategy -- see platform_utils.network_strategy())."""
    def _producer():
        info = dt.inspect_container(name, dry_run=dry_run)
        if not info:
            return None
        networks = info.get("NetworkSettings", {}).get("Networks", {}) or {}
        for _net_name, net_info in networks.items():
            ip = net_info.get("IPAddress")
            if ip:
                return ip
        # Fall back to the legacy top-level IPAddress field some older
        # Docker API responses use for default-bridge-only containers.
        return info.get("NetworkSettings", {}).get("IPAddress") or None

    return _cached(f"ip:{name}:{dry_run}", _producer, force=force)


@dataclass
class ServerDiscovery:
    name: str
    exists: bool
    running: bool
    configured_ip: str
    runtime_ip: Optional[str]
    ip_drifted: bool
    reachable: Optional[bool] = None
    reachable_detail: str = ""


def discover_servers(cfg: AgentConfig, dry_run: bool = False, force: bool = False) -> List[ServerDiscovery]:
    """Report, for every configured server: does it exist, is it running,
    and does its configured IP match what Docker actually assigned."""
    results = []
    for name in cfg.list_server_names():
        server = cfg.get_server(name)
        exists = container_exists_cached(name, dry_run=dry_run, force=force)
        running = dt.is_running(name, dry_run=dry_run) if exists else False
        runtime_ip = get_runtime_ip(name, dry_run=dry_run, force=force) if running else None
        drifted = bool(runtime_ip and runtime_ip != server.ip)
        results.append(ServerDiscovery(
            name=name, exists=exists, running=running,
            configured_ip=server.ip, runtime_ip=runtime_ip, ip_drifted=drifted,
        ))
    return results


def sync_ip_drift(cfg: AgentConfig, auto_fix: bool = False, dry_run: bool = False) -> List[str]:
    """For every server whose runtime IP has drifted from servers.yml,
    either just report it (auto_fix=False) or surgically patch
    servers.yml's one "ip:" line for that server (auto_fix=True), mirroring
    Bash4Edge's own `yq -i eval '.servers.$server.ip = ...'` in-place edit
    style -- every other line/comment in the file is left untouched.

    Returns a list of human-readable messages describing what was found
    and (if applicable) corrected.
    """
    messages = []
    for disc in discover_servers(cfg, dry_run=dry_run):
        if not disc.ip_drifted:
            continue
        msg = (
            f"{disc.name}: configured IP {disc.configured_ip} does not match "
            f"the IP Docker actually assigned ({disc.runtime_ip})."
        )
        if auto_fix and not dry_run:
            ok = yaml_mini.update_scalar_in_file(
                cfg.path, f"servers.{disc.name}.ip", disc.runtime_ip
            )
            if ok:
                msg += f" Corrected servers.yml automatically to {disc.runtime_ip}."
                logger.info(msg)
            else:
                msg += " Could not locate the exact line to patch -- please update servers.yml by hand."
                logger.warning(msg)
        else:
            msg += " Run with --auto-fix-ip (or the 'sync-ip' command) to correct this automatically."
            logger.warning(msg)
        messages.append(msg)
    return messages


def validate_connectivity(ip: str, port: int = 443, timeout: float = 3.0) -> bool:
    """A simple, dependency-free TCP connect test -- works identically on
    Windows and Linux, unlike ICMP ping (often blocked by firewalls or
    requiring elevated privileges on Windows). Returns True if a TCP
    connection to ip:port succeeds within `timeout` seconds."""
    try:
        with socket.create_connection((ip, port), timeout=timeout):
            return True
    except OSError:
        return False


def validate_all(cfg: AgentConfig, dry_run: bool = False) -> List[ServerDiscovery]:
    """Run discover_servers() and then layer a connectivity check onto each
    result, using the server's runtime IP if running, else its configured
    IP (so you still get a meaningful answer for a not-yet-started
    server)."""
    mon = cfg.monitor
    if not mon.get("connectivity_check_enabled", True):
        return discover_servers(cfg, dry_run=dry_run)

    port = int(mon.get("connectivity_check_port", 443))
    timeout = float(mon.get("connectivity_timeout_seconds", 3))

    results = discover_servers(cfg, dry_run=dry_run)
    for disc in results:
        if dry_run:
            disc.reachable = None
            disc.reachable_detail = "skipped (dry-run)"
            continue
        target_ip = disc.runtime_ip or disc.configured_ip
        if not disc.exists:
            disc.reachable = False
            disc.reachable_detail = "container does not exist"
            continue
        ok = validate_connectivity(target_ip, port=port, timeout=timeout)
        disc.reachable = ok
        disc.reachable_detail = (
            f"TCP {target_ip}:{port} {'reachable' if ok else 'UNREACHABLE'}"
        )
    return results
