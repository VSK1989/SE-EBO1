r"""
agent/platform_utils.py
==========================
Purpose
-------
The single place in the whole agent that knows "what OS am I running on,
and what does that mean for how I talk to Docker and the filesystem."
Every other module asks THIS module instead of calling `platform.system()`
or checking `os.name` itself, so the cross-platform logic lives in exactly
one, well-tested location.

Why this module exists (what it fixes)
-----------------------------------------
Before this module existed, the agent had several silent, Windows-only
assumptions baked into other files:
  - `config/servers.json`'s default log_collection.output_dir was a literal
    Windows path, with WSL/Linux handled only by a note in
    docs/ASSUMPTIONS.md telling the user to edit it by hand.
  - `container_manager.ensure_network()` always tried to create a Docker
    IPVLAN network bound to a *physical host network adapter*
    (`-o parent=<interface>`). This works great on native Linux Docker
    Engine, but Docker Desktop for Windows runs the Docker daemon inside a
    hidden, WSL2-based Linux VM -- there usually is no host adapter visible
    to the daemon that IPVLAN/MACVLAN can bind to the way the Bash4Edge
    scripts (written for native Ubuntu) expect. Attempting it anyway tends
    to fail with a non-obvious Docker error.
This module gives the agent a single, honest way to detect which situation
it's in and react sensibly, instead of assuming Linux-like networking
everywhere or requiring the user to discover the problem by trial and
error.

Functionality
-------------
- detect_os(): returns "windows", "linux", "macos", or "wsl" (WSL is
  reported distinctly from "linux" because, although `platform.system()`
  reports "Linux" inside WSL, the filesystem bridge back to the Windows
  host behaves differently and matters for path translation below).
- is_windows() / is_linux() / is_wsl(): convenience booleans.
- default_downloads_dir(): returns the correct "Downloads" folder for
  log_collection.output_dir on whichever OS/shell the agent is actually
  running under right now, instead of a hard-coded Windows path.
- to_host_path(path) / normalize_bind_source(path): makes a configured
  bind-mount SOURCE path usable by the Docker CLI on the current host,
  translating a Windows-style path to its WSL mount equivalent (and back)
  when running under WSL, so the same config/servers.yml value works
  whether the agent is launched from a native Windows Python, or from
  Python running inside WSL talking to the same Docker Desktop engine.
- network_strategy(): returns "ipvlan" (bind a static IP to a real host
  NIC -- works on native Linux Docker Engine) or "bridge_ports" (use an
  ordinary Docker bridge network and publish ports instead -- the safe
  default on Windows/Docker Desktop, where a real host NIC usually isn't
  reachable for IPVLAN/MACVLAN). Can be overridden explicitly in
  config/servers.yml (`network.force_strategy: ipvlan`) for the case where
  a user HAS configured Docker Desktop's WSL2 integration in a way that
  does expose a usable adapter.
- get_local_adapter_info(): cross-platform re-implementation of Bash4Edge's
  setupDockerNetwork.sh "Get Local Adapter Settings" menu option -- auto-
  detects the local default-route network adapter name, gateway, and
  subnet (CIDR), using `ip route`/`ip addr` on Linux and PowerShell's
  `Get-NetRoute`/`Get-NetIPConfiguration` on Windows.

How it interacts with other modules
------------------------------------
- container_manager.py calls network_strategy() to decide whether to build
  an ipvlan `docker run` command (static IP) or a bridge+port-publish one.
- log_collector.py calls default_downloads_dir() when config/servers.yml
  doesn't explicitly set log_collection.output_dir.
- docker_tools.py calls normalize_bind_source() before handing a bind-mount
  source path to the Docker CLI.
- agent.py's `discover` command calls get_local_adapter_info() to implement
  the Python-side equivalent of Bash4Edge's adapter-detection feature.

Configuration requirements
---------------------------
None required. Everything here is derived from the running environment
itself (`platform.system()`, environment variables, and -- only for
adapter detection -- a single, read-only OS command).
"""
from __future__ import annotations

import logging
import os
import platform
import re
import subprocess
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def detect_os() -> str:
    """Return 'windows', 'wsl', 'linux', or 'macos'."""
    system = platform.system().lower()
    if system == "windows":
        return "windows"
    if system == "darwin":
        return "macos"
    if system == "linux":
        # WSL exposes itself via a kernel release string containing
        # "microsoft" (e.g. "5.15.90.1-microsoft-standard-WSL2"), and/or the
        # WSL_DISTRO_NAME / WSL_INTEROP environment variables set by WSL
        # itself. Checking both makes this robust across WSL1 and WSL2.
        release = platform.release().lower()
        if "microsoft" in release or "WSL_DISTRO_NAME" in os.environ or "WSL_INTEROP" in os.environ:
            return "wsl"
        return "linux"
    return system or "unknown"


def is_windows() -> bool:
    return detect_os() == "windows"


def is_wsl() -> bool:
    return detect_os() == "wsl"


def is_linux_like() -> bool:
    """True for native Linux OR WSL -- i.e. anywhere a POSIX shell and
    `/proc`-style tools are available, as opposed to native Windows."""
    return detect_os() in ("linux", "wsl", "macos")


def default_downloads_dir() -> str:
    """Return this host's real Downloads folder, cross-platform.

    - Native Windows: %USERPROFILE%\\Downloads
    - WSL: the Linux-side home's Downloads if it exists, else falls back to
      the Windows user's Downloads reached via /mnt/c/Users/<name>/Downloads
      (best-effort: WSL doesn't expose the Windows username directly, so
      this only applies the /mnt/c translation to a path the caller already
      has -- see to_host_path() -- rather than guessing a username here).
    - Linux / macOS: ~/Downloads
    """
    osname = detect_os()
    if osname == "windows":
        userprofile = os.environ.get("USERPROFILE")
        if userprofile:
            return str(Path(userprofile) / "Downloads")
    return str(Path.home() / "Downloads")


_WINDOWS_PATH_RE = re.compile(r"^([A-Za-z]):[\\/](.*)$")


def to_host_path(path: str) -> str:
    """Translate a configured path so it is usable by the Docker CLI on
    THIS host, bridging the common Windows-path-under-WSL mismatch.

    - If running under WSL and given a Windows-style path like
      "C:\\Users\\Name\\Downloads", returns "/mnt/c/Users/Name/Downloads".
    - If running on native Windows, returns the path unchanged (Docker
      Desktop's CLI integration accepts native Windows paths directly for
      bind mounts).
    - If running on native Linux/macOS and given a POSIX path, returns it
      unchanged.
    - If given a Windows-style path while NOT under WSL (e.g. running
      natively on Linux against a remote/misconfigured path), the path is
      returned unchanged -- translating it would be a guess this module
      should not make silently.
    """
    m = _WINDOWS_PATH_RE.match(path)
    if m and is_wsl():
        drive, rest = m.group(1).lower(), m.group(2).replace("\\", "/")
        return f"/mnt/{drive}/{rest}"
    return path


def normalize_bind_source(path: str) -> str:
    """Alias of to_host_path(), named for call sites that are specifically
    preparing a Docker --mount type=bind source= value."""
    return to_host_path(path)


def network_strategy(force: Optional[str] = None) -> str:
    """Return 'ipvlan' or 'bridge_ports'.

    `force`, if given (from config/servers.yml's network.force_strategy),
    always wins. Otherwise: Linux/WSL defaults to 'ipvlan' (matches both
    the Windows-side readme.md's own IPVLAN instructions and Bash4Edge's
    native-Ubuntu design); native Windows defaults to 'bridge_ports',
    because Docker Desktop's hidden VM-based networking does not reliably
    expose a host NIC for IPVLAN/MACVLAN the way native Linux Docker Engine
    does.
    """
    if force in ("ipvlan", "bridge_ports"):
        return force
    return "bridge_ports" if is_windows() else "ipvlan"


def get_local_adapter_info(timeout: float = 5.0) -> dict:
    """Cross-platform port of Bash4Edge's setupDockerNetwork.sh "Get Local
    Adapter Settings": auto-detects the default-route network adapter,
    its gateway, and its subnet in CIDR notation.

    Returns a dict: {"interface": str|None, "gateway": str|None,
    "subnet": str|None, "error": str|None}. Never raises -- any failure is
    reported via the "error" key so callers can degrade gracefully.
    """
    result = {"interface": None, "gateway": None, "subnet": None, "error": None}
    try:
        if is_windows():
            _get_adapter_info_windows(result, timeout)
        else:
            _get_adapter_info_linux(result, timeout)
    except Exception as exc:  # noqa: BLE001 - this is a best-effort helper
        result["error"] = str(exc)
        logger.warning("Could not auto-detect local network adapter: %s", exc)
    return result


def _run(cmd, timeout):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def _get_adapter_info_linux(result: dict, timeout: float) -> None:
    # Mirrors: ip route get 8.8.8.8 | awk '{printf $5}'
    r = _run(["ip", "route", "get", "8.8.8.8"], timeout)
    if r.returncode != 0:
        result["error"] = r.stderr.strip() or "ip route get failed"
        return
    parts = r.stdout.split()
    if "dev" in parts:
        result["interface"] = parts[parts.index("dev") + 1]

    if result["interface"]:
        # Mirrors: ip route show dev $iface | awk '$1 == "default" {print $3}'
        r2 = _run(["ip", "route", "show", "dev", result["interface"]], timeout)
        for line in r2.stdout.splitlines():
            fields = line.split()
            if fields and fields[0] == "default" and "via" in fields:
                result["gateway"] = fields[fields.index("via") + 1]

        # Mirrors: ip addr show dev $iface | awk '$1 == "inet" {print $2}'
        r3 = _run(["ip", "addr", "show", "dev", result["interface"]], timeout)
        for line in r3.stdout.splitlines():
            fields = line.split()
            if fields and fields[0] == "inet":
                cidr = fields[1]  # e.g. "192.168.1.251/24"
                result["subnet"] = _cidr_to_network(cidr)


def _cidr_to_network(ip_cidr: str) -> Optional[str]:
    """Given 'ip/prefix' (e.g. '192.168.1.251/24'), return the NETWORK
    address in CIDR form (e.g. '192.168.1.0/24'), replicating what
    Bash4Edge's `ipcalc` call extracts, without depending on the external
    `ipcalc` binary being installed."""
    try:
        ip_str, prefix_str = ip_cidr.split("/")
        prefix = int(prefix_str)
        octets = [int(o) for o in ip_str.split(".")]
        ip_int = (octets[0] << 24) | (octets[1] << 16) | (octets[2] << 8) | octets[3]
        mask = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF
        net_int = ip_int & mask
        net_octets = [(net_int >> shift) & 0xFF for shift in (24, 16, 8, 0)]
        return f"{'.'.join(str(o) for o in net_octets)}/{prefix}"
    except (ValueError, IndexError):
        return None


def _get_adapter_info_windows(result: dict, timeout: float) -> None:
    # A single PowerShell call returns adapter alias, gateway, and
    # IP/prefix as pipe-separated text -- avoids parsing verbose default
    # PowerShell object output.
    ps_script = (
        "$r = Get-NetRoute -DestinationPrefix '0.0.0.0/0' | "
        "Sort-Object RouteMetric | Select-Object -First 1; "
        "$ifIndex = $r.InterfaceIndex; "
        "$ipcfg = Get-NetIPAddress -InterfaceIndex $ifIndex -AddressFamily IPv4 | "
        "Select-Object -First 1; "
        "$alias = (Get-NetAdapter -InterfaceIndex $ifIndex).Name; "
        "Write-Output (\"$alias|$($r.NextHop)|$($ipcfg.IPAddress)/$($ipcfg.PrefixLength)\")"
    )
    r = _run(["powershell", "-NoProfile", "-Command", ps_script], timeout)
    if r.returncode != 0 or "|" not in r.stdout:
        result["error"] = r.stderr.strip() or "PowerShell adapter query failed"
        return
    alias, gateway, ip_cidr = r.stdout.strip().split("|")
    result["interface"] = alias or None
    result["gateway"] = gateway or None
    result["subnet"] = _cidr_to_network(ip_cidr) if ip_cidr and "/" in ip_cidr else None
