"""
agent/yaml_mini.py
=====================
Purpose
-------
A tiny, dependency-free parser for the SPECIFIC, limited subset of YAML
used by servers.yml (both the Windows-side and Bash4Edge's own copies share
the same shape). This is what lets the agent read servers.yml DIRECTLY --
no PyYAML, no pip install -- fulfilling the explicit "servers.yml
Integration" requirement while keeping the project's zero-dependency
promise intact.

Why not just use PyYAML?
-------------------------
The whole project has deliberately avoided third-party dependencies from
the very first version (see agent/config.py's original docstring and
docs/SOURCE_FILES_REVIEW.md). Pulling in PyYAML now, just to read a file
whose structure never actually uses YAML's more exotic features (anchors,
multi-document streams, flow-style collections, etc.), would reintroduce
exactly the kind of "one more thing to pip install" friction this project
was built to avoid. Since servers.yml's real-world shape is small and
stable (two-space-indented block mappings, scalar values, '#' comments,
Yes/No booleans), a small hand-written parser can read it reliably without
that cost.

What this parser supports (confirmed against the real servers.yml)
----------------------------------------------------------------------
- Nested block mappings using consistent indentation (any fixed indent
  width; this file uses 2 spaces).
- Scalar values: plain strings, integers, and YAML 1.1-style booleans
  (Yes/No/True/False/yes/no/true/false), and an explicit empty value
  (nothing after the colon) which is parsed as None -- matching the
  `notes: B:` entry in the real file.
- End-of-line comments introduced by '#' (a '#' is only treated as a
  comment starter when preceded by start-of-line or whitespace, so values
  containing '#' are never silently truncated -- though none currently do).
- Commented-out lines (an entire line starting with '#', after stripping
  leading whitespace) are skipped entirely -- this is what makes the
  servers.yml convention of "commented-out optional per-server overrides"
  work exactly as intended: they are simply invisible to the parser, the
  same as they would be to a real YAML parser.
- Blank lines are ignored.

What this parser deliberately does NOT support
--------------------------------------------------
Flow-style collections (`{a: 1}`, `[1, 2]`), multi-line scalars (`|`, `>`),
anchors/aliases (`&foo`, `*foo`), multiple documents (`---`), and quoted
scalars containing escaped quotes. None of these appear in servers.yml; if
you add one to a *custom* servers.yml, parse_yaml() will raise a clear
YamlMiniError rather than silently misreading it.

Functionality
-------------
- parse_yaml(text) -> dict: parses the given YAML-subset text into nested
  Python dict/str/int/bool/None values.
- load_yaml_file(path) -> dict: reads and parses a file.
- update_scalar_in_file(path, key_path, new_value): a SURGICAL text editor
  (not a full re-serialiser) that finds one specific "key: value" line,
  addressed by a dotted key_path like "servers.Edge01.ip", and replaces
  just that line's value -- preserving every comment, blank line, and the
  formatting of every other line in the file untouched. This mirrors how
  Bash4Edge's own scripts use `yq -i eval '.servers.$server.ip = ...'` to
  make a targeted edit without reformatting the whole file, and is what
  powers this project's new IP-drift auto-sync feature (see discovery.py).

How it interacts with other modules
------------------------------------
- agent/config.py uses parse_yaml()/load_yaml_file() as its ONLY file
  format reader -- config/servers.yml is parsed with this module, not JSON.
- agent/discovery.py uses update_scalar_in_file() to write a corrected IP
  address back into config/servers.yml when it detects drift between the
  configured IP and the IP Docker actually assigned.

Configuration requirements
---------------------------
None -- this module has no configuration of its own; it is the engine
other modules use to read configuration.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple


class YamlMiniError(Exception):
    """Raised when the input uses a YAML feature this subset parser does
    not support, or is otherwise malformed."""


_BOOL_TRUE = {"yes", "true", "on"}
_BOOL_FALSE = {"no", "false", "off"}

_UNSUPPORTED_MARKERS = ("---", "...", "&", "*", "<<", "!!")


def _strip_comment(line: str) -> str:
    """Remove a trailing '#...' comment, but only when the '#' is preceded
    by whitespace or is at the start of the (already-indent-stripped)
    content -- avoids corrupting any future value that legitimately
    contains '#' (none currently do, but this is cheap safety)."""
    out = []
    i = 0
    n = len(line)
    while i < n:
        ch = line[i]
        if ch == "#" and (i == 0 or line[i - 1].isspace()):
            break
        out.append(ch)
        i += 1
    return "".join(out).rstrip()


def _coerce_scalar(raw: str) -> Any:
    raw = raw.strip()
    if raw == "":
        return None
    if (raw.startswith('"') and raw.endswith('"') and len(raw) >= 2) or (
        raw.startswith("'") and raw.endswith("'") and len(raw) >= 2
    ):
        return raw[1:-1]
    low = raw.lower()
    if low in _BOOL_TRUE:
        return True
    if low in _BOOL_FALSE:
        return False
    if low == "null" or low == "~":
        return None
    if re.fullmatch(r"-?\d+", raw):
        return int(raw)
    if re.fullmatch(r"-?\d+\.\d+", raw):
        return float(raw)
    return raw


def _indent_of(line: str) -> int:
    return len(line) - len(line.lstrip(" "))


def parse_yaml(text: str) -> Dict[str, Any]:
    """Parse the limited YAML subset described in this module's docstring."""
    raw_lines = text.replace("\r\n", "\n").split("\n")

    # Pre-filter: drop blank lines and fully-commented-out lines; keep
    # (original_indent, stripped_content) for the rest.
    lines: List[Tuple[int, str]] = []
    for line in raw_lines:
        stripped_leading = line.lstrip(" ")
        if stripped_leading.startswith("#"):
            continue  # whole-line comment -- invisible to the parser
        content = _strip_comment(line)
        if content.strip() == "":
            continue
        for marker in _UNSUPPORTED_MARKERS:
            if marker in content:
                raise YamlMiniError(
                    f"Unsupported YAML feature '{marker}' found in line: {line!r}. "
                    "yaml_mini.py only supports simple nested block mappings."
                )
        if "\t" in line:
            raise YamlMiniError(f"Tab characters are not supported in: {line!r} -- use spaces.")
        lines.append((_indent_of(line), content.strip()))

    root: Dict[str, Any] = {}
    # Stack of (indent, dict_reference) -- mirrors the "stack of currently
    # open mappings" approach any hand-written indentation parser needs.
    stack: List[Tuple[int, Dict[str, Any]]] = [(-1, root)]

    for indent, content in lines:
        if ":" not in content:
            raise YamlMiniError(f"Expected 'key: value' or 'key:' but got: {content!r}")
        key, _, value_part = content.partition(":")
        key = key.strip()
        value_raw = value_part.strip()

        # Pop back to the correct nesting level for this indent.
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]

        if value_raw == "":
            # Starts a nested mapping (or is a leaf with a null value if no
            # deeper-indented lines follow -- resolved naturally since we
            # only push a new dict lazily, replaced by None if nothing
            # nests under it).
            new_dict: Dict[str, Any] = {}
            parent[key] = new_dict
            stack.append((indent, new_dict))
        else:
            parent[key] = _coerce_scalar(value_raw)

    # Post-process: any dict that ended up with zero keys started out as a
    # "key:" line with nothing after the colon, optimistically treated as
    # "might become a nested mapping" while parsing. If nothing ever nested
    # under it, it was actually a null SCALAR (e.g. "ca_folder:",
    # "dns_ip:", "notes: \n  B:"), not an intentionally empty mapping --
    # this schema never uses genuinely empty mappings, so converting every
    # leftover {} to None is correct here and avoids a subtly wrong
    # `{}` (falsy-but-not-None) value leaking into callers that check
    # `is None`.
    def _collapse_empty_dicts(node):
        if isinstance(node, dict):
            if not node:
                return None
            return {k: _collapse_empty_dicts(v) for k, v in node.items()}
        return node

    return _collapse_empty_dicts(root)


def load_yaml_file(path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        return parse_yaml(fh.read())


def update_scalar_in_file(path, key_path: str, new_value: str) -> bool:
    """Surgically replace the VALUE of one scalar line addressed by a
    dotted key_path (e.g. "servers.Edge01.ip"), preserving every other line
    byte-for-byte. Returns True if a replacement was made, False if the
    target key path could not be located (file is left untouched in that
    case).

    Implementation note: this walks the file line-by-line, tracking
    nesting purely via indentation (same rule as parse_yaml), looking for
    each successive path segment as a key at the expected depth. When the
    final segment is found, only that line's text after ':' is replaced;
    the key, any inline comment, and all surrounding lines are left
    exactly as they were.
    """
    segments = key_path.split(".")
    with open(path, "r", encoding="utf-8") as fh:
        original_lines = fh.read().replace("\r\n", "\n").split("\n")

    # depth_stack[i] = the indent level at which segments[i]'s mapping body
    # lives (i.e. the indent its children must have).
    search_index = 0
    expected_indent_stack: List[int] = []
    target_line_no = None

    for line_no, line in enumerate(original_lines):
        stripped_leading = line.lstrip(" ")
        if stripped_leading.startswith("#") or stripped_leading.strip() == "":
            continue
        content = _strip_comment(line)
        if content.strip() == "" or ":" not in content:
            continue
        indent = _indent_of(line)
        key, _, value_part = content.partition(":")
        key = key.strip()

        # Pop back whenever indent decreases to/below a previously-recorded
        # level, mirroring parse_yaml's own stack logic.
        while expected_indent_stack and indent <= expected_indent_stack[-1]:
            expected_indent_stack.pop()
            search_index -= 1

        if search_index < len(segments) and key == segments[search_index]:
            if search_index == len(segments) - 1:
                target_line_no = line_no
                break
            expected_indent_stack.append(indent)
            search_index += 1

    if target_line_no is None:
        return False

    line = original_lines[target_line_no]
    # Preserve the key + leading indentation + any inline comment; replace
    # only the scalar value itself.
    m = re.match(r"^(\s*[^:#]+:\s*)([^#]*)(#.*)?$", line)
    if not m:
        return False
    prefix, _old_value, comment = m.group(1), m.group(2), m.group(3) or ""
    new_line = f"{prefix}{new_value}"
    if comment:
        # keep a single space before a preserved inline comment
        new_line = f"{new_line} {comment}" if not new_line.endswith(" ") else f"{new_line}{comment}"
    original_lines[target_line_no] = new_line

    with open(path, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(original_lines))
    return True
