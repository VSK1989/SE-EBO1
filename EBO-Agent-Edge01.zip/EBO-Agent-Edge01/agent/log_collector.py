"""
agent/log_collector.py
=========================
Purpose
-------
Implements automatic diagnostic log collection: for each managed
container, writes a timestamped snapshot (docker logs + docker inspect +
health report + trace files) into the Downloads folder, either on demand
(`collect-logs`) or continuously (`monitor`).

Cross-platform note
---------------------
The destination folder now defaults to THIS host's real Downloads folder
(via agent.platform_utils.default_downloads_dir()) instead of a hard-coded
Windows path, so the same config/servers.yml works correctly whether the
agent is launched from native Windows Python or from Python running inside
WSL -- no manual edit required (see docs/ASSUMPTIONS.md history for the
previous, manual-edit-required version of this behaviour).

Functionality
-------------
- collect_one(cfg, name_or_ip): gathers docker logs, docker inspect, a
  health report (via decision_engine), and a best-effort trace-log pull
  (via trace_tools, ported from get-trace.log) into
  <output_dir>/<name>/<timestamp>/.
- collect_all(cfg): runs collect_one() for every configured server.
- _prune_old_collections(): keeps only the most recent
  log_collection.keep_last_n_collections snapshots per container.

How it interacts with other modules
------------------------------------
- Uses agent.container_manager.resolve_target() for name/IP flexibility.
- Uses agent.docker_tools for log/inspect retrieval, agent.trace_tools for
  the trace-log pull, and agent.decision_engine for the health summary.

Configuration requirements
---------------------------
Reads the agentSettings.log_collection section of config/servers.yml.
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from . import container_manager as cm
from . import decision_engine as de
from . import docker_tools as dt
from . import trace_tools as tt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def collect_one(cfg: AgentConfig, name_or_ip: str, dry_run: bool = False) -> Optional[Path]:
    lc = cfg.log_collection
    if not lc.get("enabled", True):
        logger.debug("Log collection disabled in config; skipping '%s'.", name_or_ip)
        return None

    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name

    output_root = Path(lc.get("output_dir"))
    snapshot_dir = output_root / name / _timestamp()

    try:
        snapshot_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.warning(
            "Could not create log collection folder '%s' (%s). See README.md > Troubleshooting.",
            snapshot_dir, exc,
        )
        return None

    tail = lc.get("tail_lines", 500)
    logs_text = dt.get_logs(name, tail=tail, dry_run=dry_run)
    (snapshot_dir / f"{name}_docker.log").write_text(logs_text or "", encoding="utf-8")

    info = dt.inspect_container(name, dry_run=dry_run)
    (snapshot_dir / f"{name}_inspect.json").write_text(json.dumps(info or {}, indent=2), encoding="utf-8")

    decision = de.evaluate(cfg, name, dry_run=dry_run)
    (snapshot_dir / f"{name}_health_report.txt").write_text(
        f"Collected at: {datetime.now().isoformat()}\n\n{decision.summary()}\n", encoding="utf-8",
    )

    try:
        trace_dir = snapshot_dir / f"{name}_trace"
        tt.get_trace(cfg, name, str(trace_dir), dry_run=dry_run)
    except Exception as exc:  # noqa: BLE001 - must never break collect_one
        logger.warning("Trace log extraction skipped for '%s': %s", name, exc)

    logger.info("Collected diagnostics for '%s' -> %s", name, snapshot_dir)
    _prune_old_collections(output_root / name, keep=lc.get("keep_last_n_collections", 20))
    return snapshot_dir


def _prune_old_collections(container_dir: Path, keep: int) -> None:
    if not container_dir.exists():
        return
    try:
        snapshots = sorted([p for p in container_dir.iterdir() if p.is_dir()], key=lambda p: p.name)
    except OSError:
        return
    excess = len(snapshots) - keep
    if excess <= 0:
        return
    for old_dir in snapshots[:excess]:
        try:
            for f in old_dir.rglob("*"):
                if f.is_file():
                    f.unlink(missing_ok=True)
            for d in sorted(old_dir.rglob("*"), key=lambda p: len(p.parts), reverse=True):
                if d.is_dir():
                    d.rmdir()
            old_dir.rmdir()
            logger.debug("Pruned old log collection: %s", old_dir)
        except OSError as exc:
            logger.warning("Could not prune old collection '%s': %s", old_dir, exc)


def collect_all(cfg: AgentConfig, dry_run: bool = False) -> None:
    for name in cfg.list_server_names():
        collect_one(cfg, name, dry_run=dry_run)
