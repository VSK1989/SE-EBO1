"""
agent/log_collector.py
=========================
Purpose
-------
Implements the explicit requirement: "create auto logs collection in
Downloads path, folder name Container"
(C:\\Users\\SESA367373\\Downloads\\DOCKER\\CONTAINER1). This module is
responsible for automatically writing a timestamped diagnostic snapshot for
each managed container to that folder, either on demand (`collect-logs`
CLI command) or continuously while the agent is running in monitor mode.
This is new functionality -- neither the Windows/Python scripts nor
Bash4Edge automated log collection; they only provided manual tools
(readme.md's ad-hoc `docker logs cs1` commands, Bash4Edge's getLogs.sh,
and the verified get-trace.log script) which this module builds on top of
and automates.

Functionality
-------------
- collect_one(name): gathers, for a single container:
    1. `docker logs --tail N`      -> <name>_docker.log
    2. `docker inspect`  (pretty)  -> <name>_inspect.json
    3. decision engine findings    -> <name>_health_report.txt
    4. trace.log/trace.log.old,    -> <name>_trace/ subfolder, via the
       pulled via trace_tools.py      verified get-trace.log approach
                                      (works even if the container itself
                                      isn't running, as long as its -db
                                      volume still exists; failures here
                                      are logged as warnings, not fatal,
                                      since the volume may not exist yet on
                                      a brand-new/never-started server)
  and writes them into a timestamped sub-folder
  (<output_dir>/<name>/<YYYYMMDD_HHMMSS>/) so successive collections never
  overwrite each other.
- collect_all(cfg): runs collect_one() for every server defined in
  config/servers.json.
- _prune_old_collections(): keeps only the most recent
  log_collection.keep_last_n_collections snapshots per container, deleting
  older ones, so the Downloads folder does not grow without bound.
- Resilient by design: if the configured Windows path is not reachable from
  the environment the agent happens to run in (for example, if someone runs
  it inside a Linux/WSL shell where the Windows C:\\ drive is not the same
  filesystem), collection failures are caught and logged as warnings rather
  than crashing the whole agent.

How it interacts with other modules
------------------------------------
- Uses agent.docker_tools for read-only log/inspect retrieval.
- Uses agent.trace_tools.get_trace() for the additional, more robust
  trace-log pull (ported/verified from get-trace.log).
- Uses agent.decision_engine.evaluate() to embed a health summary in every
  snapshot (so opening the folder tells you not just the raw logs but also
  the agent's own assessment).
- Is invoked by agent.py for the `collect-logs` subcommand and
  automatically on every iteration of the `monitor` loop.

Configuration requirements
---------------------------
Reads the log_collection section of config/servers.json:
  - enabled (bool)
  - output_dir (str) -- defaults to
    C:\\Users\\SESA367373\\Downloads\\DOCKER\\CONTAINER1
  - tail_lines (int)
  - keep_last_n_collections (int)
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from . import decision_engine as de
from . import docker_tools as dt
from . import trace_tools as tt
from .config import AgentConfig

logger = logging.getLogger(__name__)


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def collect_one(cfg: AgentConfig, name: str, dry_run: bool = False) -> Optional[Path]:
    lc = cfg.log_collection
    if not lc.get("enabled", True):
        logger.debug("Log collection disabled in config; skipping '%s'.", name)
        return None

    output_root = Path(lc.get("output_dir"))
    snapshot_dir = output_root / name / _timestamp()

    try:
        snapshot_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.warning(
            "Could not create log collection folder '%s' (%s). "
            "If running under WSL/Linux, the Windows C:\\ path may not be reachable "
            "from this shell -- see README.md > Troubleshooting.",
            snapshot_dir, exc,
        )
        return None

    tail = lc.get("tail_lines", 500)
    logs_text = dt.get_logs(name, tail=tail, dry_run=dry_run)
    (snapshot_dir / f"{name}_docker.log").write_text(logs_text or "", encoding="utf-8")

    info = dt.inspect_container(name, dry_run=dry_run)
    (snapshot_dir / f"{name}_inspect.json").write_text(
        json.dumps(info or {}, indent=2), encoding="utf-8"
    )

    decision = de.evaluate(cfg, name, dry_run=dry_run)
    (snapshot_dir / f"{name}_health_report.txt").write_text(
        f"Collected at: {datetime.now().isoformat()}\n\n{decision.summary()}\n",
        encoding="utf-8",
    )

    # Best-effort: also pull trace.log/trace.log.old directly from the
    # server's database volume (ported from get-trace.log). This can
    # legitimately fail (e.g. volume doesn't exist yet on a never-started
    # server) -- that is logged as a warning, not treated as a collection
    # failure.
    try:
        trace_dir = snapshot_dir / f"{name}_trace"
        tt.get_trace(cfg, name, str(trace_dir), dry_run=dry_run)
    except Exception as exc:  # noqa: BLE001 - deliberately broad: must never break collect_one
        logger.warning("Trace log extraction skipped for '%s': %s", name, exc)

    logger.info("Collected diagnostics for '%s' -> %s", name, snapshot_dir)
    _prune_old_collections(output_root / name, keep=lc.get("keep_last_n_collections", 20))
    return snapshot_dir


def _prune_old_collections(container_dir: Path, keep: int) -> None:
    if not container_dir.exists():
        return
    try:
        snapshots = sorted(
            [p for p in container_dir.iterdir() if p.is_dir()],
            key=lambda p: p.name,
        )
    except OSError:
        return
    excess = len(snapshots) - keep
    if excess <= 0:
        return
    for old_dir in snapshots[:excess]:
        try:
            for f in old_dir.rglob("*"):
                if f.is_file():
                    f.unlink(missing_ok=True)
            for d in sorted(old_dir.rglob("*"), key=lambda p: len(p.parts), reverse=True):
                if d.is_dir():
                    d.rmdir()
            old_dir.rmdir()
            logger.debug("Pruned old log collection: %s", old_dir)
        except OSError as exc:
            logger.warning("Could not prune old collection '%s': %s", old_dir, exc)


def collect_all(cfg: AgentConfig, dry_run: bool = False) -> None:
    for name in cfg.list_server_names():
        collect_one(cfg, name, dry_run=dry_run)
