"""
agent package
==============
Purpose
-------
This package contains the complete implementation of the lightweight,
rule-based AI Agent used to manage the EcoStruxure Building Operation (EBO)
Docker container(s) running on Docker Desktop (e.g. container "Edge01").

It was built by directly reviewing and merging TWO independent sources you
supplied:

  1. The Windows/Python reference scripts and the OFFICIAL Docker image
     readme: start.py, teststart.py, upgrade.py, get-trace.log (an
     undocumented bash helper despite its .log extension), SECURITY.md,
     pr.yml, and readme.md (the "Schneider Electric EcoStruxure Building
     Operation" image readme covering Network/EULA/Start/Upgrade/Backup
     management/CA certificates/Proxy/Crash dumps/DNS/Password Reset
     Mode/GraphDB).
  2. The Bash4Edge toolkit: an independent, Python-free, menu-driven set of
     Bash scripts (functions.sh, manageOS.sh, setupDockerNetwork.sh,
     manageGraphDb.sh, manageServers.sh, getLogs.sh, manageBackups.sh,
     dockerCommands.sh) and its own servers.yml / readme.md, for managing
     the SAME containers from a separate Ubuntu/Linux host over SSH.

Both original sets are preserved byte-for-byte under
reference/original-uploaded-files/ (split into windows-python-agent/ and
bash4edge/ subfolders) for traceability. See docs/SOURCE_FILES_REVIEW.md
for the full, file-by-file account of what was ported verbatim, what was
reconstructed from documented-but-unseen behaviour, and what is genuinely
new. The Bash4Edge toolkit itself is also shipped unmodified in the
bash4edge/ folder at the project root, ready to copy to an Ubuntu machine
(Path B) -- this Python package (agent/) is Path A, for running directly
on the same Windows PC as Docker Desktop.

Functionality
-------------
The package is deliberately split into small, single-responsibility modules
so that each piece can be understood, tested, and extended independently:

    config.py             -> loads/validates config/servers.json (no YAML;
                              JSON re-expression of Bash4Edge's servers.yml)
    logging_setup.py       -> configures console + rotating file logging
    docker_tools.py         -> low-level, safe wrappers around the Docker CLI
                              (merges start.py's list-based, injection-safe
                              subprocess pattern; teststart.py's shlex/shell
                              string pattern was reviewed and intentionally
                              NOT reused, see docs/SOURCE_FILES_REVIEW.md)
    container_manager.py    -> high-level container lifecycle operations
                               (start/stop/restart/upgrade/status), a direct
                               Python re-implementation of start.py's
                               `docker run` construction and upgrade.py's
                               stop/prepare-upgrade/restart/get-upgrade-log
                               sequence, plus an optional --test-mode
                               port-forwarding start (from readme.md's
                               "useful docker commands" section)
    trace_tools.py          -> PORTED, verified, from get-trace.log: pulls
                               trace logs directly out of a server's named
                               Docker volume using a disposable ubuntu:focal
                               container -- works even if the EBO container
                               itself has been removed
    backup_tools.py         -> list-backups / copy-backups / restore-backup
                               equivalents, modelled on the usage contract
                               documented for those scripts in readme.md
    password_reset.py       -> password-reset-mode equivalent, modelled on
                               the same ephemeral-container pattern used by
                               upgrade.py's prepare-upgrade step
    graphdb_tools.py         -> start-graphdb equivalent (Semantics/GraphDB
                               companion container), modelled on readme.md's
                               GraphDB section and Bash4Edge's
                               manageGraphDb.sh menu
    decision_engine.py       -> the "AI" (rule-based expert system) that
                               inspects container state + logs and decides
                               what action, if any, should be taken
    log_collector.py          -> automatically collects container logs and
                               diagnostic snapshots into the configured
                               Downloads folder
    agent.py                  -> orchestrates all of the above and exposes the
                               command line interface (CLI)

How modules interact
---------------------
agent.py (the orchestrator) is the only module that imports all the others.
Every other module only depends on config.py and, where relevant,
docker_tools.py. This keeps the dependency graph flat and easy to reason
about:

    agent.py
      |-- config.py
      |-- logging_setup.py
      |-- container_manager.py --> docker_tools.py
      |-- trace_tools.py       --> docker_tools.py
      |-- backup_tools.py      --> docker_tools.py
      |-- password_reset.py    --> docker_tools.py
      |-- graphdb_tools.py     --> docker_tools.py
      |-- decision_engine.py   --> docker_tools.py
      `-- log_collector.py     --> docker_tools.py

Configuration requirements
---------------------------
All modules read their configuration from a single JSON file:
config/servers.json (see agent/config.py for the schema). No environment
variables are required, but proxy/DNS values will fall back to the host's
environment variables if not set explicitly in the JSON file (matching the
behaviour of the original start.py script).
"""

__version__ = "1.2.0"
