"""
agent/trace_tools.py
=======================
Purpose
-------
A direct, VERIFIED port of get-trace.log -- a file that, despite its .log
extension, is actually a small bash script:

    #!/bin/bash
    # arguments
    # $1 servername
    # $2 destination folder # needs to be writable by root (or other)
    image="ubuntu:focal"
    DB_VOLUME="$1-db"
    DB_FOLDER="/var/sbo"
    DEST_FOLDER=$2
    echo "Starting container..."
    docker run --rm --mount type=bind,source=$DEST_FOLDER,target=/mnt \
        --mount source=$DB_VOLUME,target=$DB_FOLDER \
        $image bash -c "cp /var/sbo/db/logs/trace* /mnt/"
    ls -l $DEST_FOLDER/trace*

Unlike Bash4Edge's getLogs.sh (which uses `docker cp` against a LIVE,
running container) or this project's own log_collector.py (which uses
`docker logs`), this approach mounts the server's named DATABASE VOLUME
directly into a brand-new, disposable `ubuntu:focal` container and copies
the trace files out of it. This means it works even if the actual EBO
server container has crashed, been stopped, or been removed entirely --
as long as the named volume (<name>-db) still exists on the Docker host.

This is marked PORTED / VERIFIED (not reconstructed) because the complete,
unambiguous source was supplied and reviewed line-by-line -- unlike
backup_tools.py/password_reset.py/graphdb_tools.py, which had to be
reconstructed from documented usage only.

Functionality
-------------
- get_trace(cfg, name, destination): reproduces the script exactly --
  runs `docker run --rm` with the two --mount flags shown above against
  `ubuntu:focal`, executing `cp /var/sbo/db/logs/trace* /mnt/` inside it,
  then lists the resulting files in the destination folder.

How it interacts with other modules
------------------------------------
- Uses agent.docker_tools.run_ephemeral_against_volume() (a generic,
  reusable version of the exact docker run invocation in the original
  script) to do the actual work -- never calls subprocess directly.
- Reads db_vol_suffix/db_folder from the server's configuration via
  agent.config, consistent with every other module.
- Exposed via agent.agent's `get-trace` CLI subcommand.

Configuration requirements
---------------------------
Uses the same defaults.db_folder / db_vol_suffix settings as
container_manager.py. The destination folder is supplied by the caller
(matching the original script's $2 argument) and must be writable; if it
does not exist, it is created automatically (a small, safe improvement
over the original script, which assumed the folder already existed and
was writable).
"""
from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import List, Optional

from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)

TRACE_IMAGE = "ubuntu:focal"


def get_trace(cfg: AgentConfig, name: str, destination: str, dry_run: bool = False) -> Optional[List[str]]:
    """Port of get-trace.log: copy /var/sbo/db/logs/trace* out of
    <name>-db into `destination` using a disposable ubuntu:focal container.
    Returns the list of files found in `destination` matching trace*, or
    None if the operation failed.
    """
    defaults = cfg.defaults
    db_vol_suffix = defaults.get("db_vol_suffix", "-db")
    db_folder = defaults.get("db_folder", "/var/sbo")
    db_vol = f"{name}{db_vol_suffix}"

    dest_path = Path(destination)
    if not dry_run:
        try:
            dest_path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.error("Could not create/access destination folder '%s': %s", destination, exc)
            return None

    logger.info("Starting container...")  # matches the original script's own log line
    rc, out, err = dt.run_ephemeral_against_volume(
        image=TRACE_IMAGE,
        volume=db_vol,
        volume_target=db_folder,
        bind_source=str(dest_path),
        bind_target="/mnt",
        shell_command=f"cp {db_folder}/db/logs/trace* /mnt/",
        dry_run=dry_run,
    )
    if rc != 0:
        logger.error("Failed to extract trace logs for '%s': %s", name, err)
        return None

    if dry_run:
        logger.info("[DRY-RUN] Would list trace* files in %s", destination)
        return []

    found = sorted(str(p) for p in dest_path.glob("trace*"))
    for f in found:
        logger.info("  %s", f)
    if not found:
        logger.warning("No trace* files found in %s after extraction.", destination)
    return found
