"""
agent/trace_tools.py
=======================
Purpose
-------
A direct, VERIFIED port of get-trace.log -- a file that, despite its .log
extension, is actually a small bash script that pulls a server's trace
logs directly out of its named database VOLUME using a disposable
`ubuntu:focal` container, bind-mounting a destination folder to /mnt. This
works even if the actual EBO server container has been stopped or removed,
since it only needs the volume to still exist.

Cross-platform note
---------------------
The destination folder you pass in may be a Windows-style path (e.g. from
config/servers.yml's agentSettings.log_collection.output_dir); it is
normalised for the current host automatically by
agent.docker_tools.run_ephemeral_against_volume() (via
agent.platform_utils.normalize_bind_source()), so this module itself needs
no OS-specific logic of its own.

Functionality
-------------
- get_trace(cfg, name_or_ip, destination): resolves `name_or_ip` to a
  configured server (by name OR by IP -- see container_manager.
  resolve_target()), then reproduces the original script exactly.

How it interacts with other modules
------------------------------------
- Uses agent.docker_tools.run_ephemeral_against_volume().
- Uses agent.container_manager.resolve_target() to accept either a
  server's configured name or its IP address.
- Exposed via agent.agent's `get-trace` CLI subcommand.

Configuration requirements
---------------------------
Uses the same defaults.db_folder / db_vol_suffix settings as
container_manager.py.
"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from . import container_manager as cm
from . import docker_tools as dt
from .config import AgentConfig

logger = logging.getLogger(__name__)

TRACE_IMAGE = "ubuntu:focal"


def get_trace(cfg: AgentConfig, name_or_ip: str, destination: str, dry_run: bool = False) -> Optional[List[str]]:
    """Port of get-trace.log: copy /var/sbo/db/logs/trace* out of
    <name>-db into `destination` using a disposable ubuntu:focal container.
    """
    server = cm.resolve_target(cfg, name_or_ip)
    name = server.name
    defaults = cfg.defaults
    db_vol_suffix = defaults.get("db_vol_suffix", "-db")
    db_folder = defaults.get("db_folder", "/var/sbo")
    db_vol = f"{name}{db_vol_suffix}"

    dest_path = Path(destination)
    if not dry_run:
        try:
            dest_path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            logger.error("Could not create/access destination folder '%s': %s", destination, exc)
            return None

    logger.info("Starting container...")  # matches the original script's own log line
    rc, out, err = dt.run_ephemeral_against_volume(
        image=TRACE_IMAGE,
        volume=db_vol,
        volume_target=db_folder,
        bind_source=str(dest_path),
        bind_target="/mnt",
        shell_command=f"cp {db_folder}/db/logs/trace* /mnt/",
        dry_run=dry_run,
    )
    if rc != 0:
        logger.error("Failed to extract trace logs for '%s': %s", name, err)
        return None

    if dry_run:
        logger.info("[DRY-RUN] Would list trace* files in %s", destination)
        return []

    found = sorted(str(p) for p in dest_path.glob("trace*"))
    for f in found:
        logger.info("  %s", f)
    if not found:
        logger.warning("No trace* files found in %s after extraction.", destination)
    return found
