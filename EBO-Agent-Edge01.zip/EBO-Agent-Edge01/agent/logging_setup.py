"""
agent/logging_setup.py
========================
Purpose
-------
Provides one function, configure_logging(), that sets up consistent logging
for the whole agent: human-readable output in the VS Code terminal plus a
rotating log file kept alongside the project (logs/agent.log). This
replaces the bare print() statements used in the original start.py/
teststart.py/upgrade.py (e.g. print('running:', cmd)) with structured,
leveled logging while preserving the same "show me the exact command"
transparency those print statements gave you.

Functionality
-------------
- Console handler: INFO and above, concise format.
- Rotating file handler: DEBUG and above, detailed format (timestamp,
  module, level, message). Rotates at 2 MB, keeps 5 backups, so the log
  folder never grows unbounded.
- Idempotent: calling configure_logging() more than once will not duplicate
  handlers (guards against double-configuration when both agent.py and a
  test import the module).

How it interacts with other modules
------------------------------------
agent.py calls configure_logging() exactly once, at start-up, before any
other module logs anything. Every other module simply does
`logger = logging.getLogger(__name__)` and logs normally; none of them
configure logging themselves.

Note: this is the agent's OWN operational log (its decisions, errors,
CLI activity). It is intentionally separate from the Docker CONTAINER
log collection performed by log_collector.py, which is written to the
user's Downloads folder as required by the project brief.

Configuration requirements
---------------------------
None required from config/servers.json. The log file location
(<project_root>/logs/agent.log) is fixed and created automatically if
missing.
"""
from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "agent.log"

_CONFIGURED = False


def configure_logging(verbose: bool = False) -> None:
    """Configure root logger with console + rotating file handlers."""
    global _CONFIGURED
    if _CONFIGURED:
        return

    LOG_DIR.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(logging.Formatter("%(levelname)-8s %(message)s"))
    root.addHandler(console)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=2 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(
        logging.Formatter("%(asctime)s %(name)-22s %(levelname)-8s %(message)s")
    )
    root.addHandler(file_handler)

    _CONFIGURED = True
