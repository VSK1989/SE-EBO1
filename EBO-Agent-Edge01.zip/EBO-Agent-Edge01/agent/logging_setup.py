"""
agent/logging_setup.py
========================
Purpose
-------
Provides configure_logging(): console + rotating file logging
(logs/agent.log) for the whole agent, replacing the bare print() statements
used in the original start.py/teststart.py/upgrade.py with structured,
leveled logging.

Functionality
-------------
- Console handler: INFO and above (DEBUG with --verbose).
- Rotating file handler: DEBUG and above, 2 MB per file, 5 backups.
- Idempotent: safe to call more than once.

How it interacts with other modules
------------------------------------
agent.py calls configure_logging() once at start-up. Every other module
just does `logging.getLogger(__name__)`.

Configuration requirements
---------------------------
None. Log file location is fixed at <project_root>/logs/agent.log.
"""
from __future__ import annotations

import logging
import logging.handlers
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
LOG_DIR = PROJECT_ROOT / "logs"
LOG_FILE = LOG_DIR / "agent.log"

_CONFIGURED = False


def configure_logging(verbose: bool = False) -> None:
    global _CONFIGURED
    if _CONFIGURED:
        return

    LOG_DIR.mkdir(parents=True, exist_ok=True)

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)

    console = logging.StreamHandler()
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(logging.Formatter("%(levelname)-8s %(message)s"))
    root.addHandler(console)

    file_handler = logging.handlers.RotatingFileHandler(
        LOG_FILE, maxBytes=2 * 1024 * 1024, backupCount=5, encoding="utf-8"
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter("%(asctime)s %(name)-22s %(levelname)-8s %(message)s"))
    root.addHandler(file_handler)

    _CONFIGURED = True
